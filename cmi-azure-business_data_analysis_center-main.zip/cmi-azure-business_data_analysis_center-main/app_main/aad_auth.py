from flask import url_for, session
import msal
from datetime import datetime as dt
import uuid


def _build_msal_app(config, cache=None, authority=None):
    # print(config)
    return msal.ConfidentialClientApplication(
        config['CLIENT_ID'], authority=authority or config['AD_AUTHORITY'],
        client_credential=config['CLIENT_SECRET'], token_cache=cache, verify=config['SSL_VERIFY'])


def _build_auth_url(config, authority=None, scopes=None, state=None):
    return _build_msal_app(config, authority=authority).get_authorization_request_url(
        scopes or [],
        state=state or str(uuid.uuid4()),
        redirect_uri=url_for("authorized", _external=True))


def _load_cache():
    cache = msal.SerializableTokenCache()
    if session.get("token_cache"):
        cache.deserialize(session["token_cache"])
    return cache


def _save_cache(cache):
    if cache.has_state_changed:
        session["token_cache"] = cache.serialize()


def _get_token_from_cache(config, scope):
    cache = _load_cache()  # This web app maintains one cache per session
    # print('cca')

    cca = _build_msal_app(config, cache=cache)
    # print(cca)
    # print('')
    accounts = cca.get_accounts()
    # print('account')
    # print(accounts)
    # print('')
    if accounts:  # So all account(s) belong to the current signed-in user
        # print('scope')
        # print(scope)
        # print('')
        result = cca.acquire_token_silent(scope, account=accounts[0])
        # print('result')
        # print(result)
        # print('')

        # result2 = cca.acquire_token_on_behalf_of(user_assertion , scope, claims_challenge )

        _save_cache(cache)
        return result


def _is_token_expired(token_exp):
    return dt.timestamp(dt.now()) >= int(token_exp)


def _get_id_token(config):
    # Acquire token OBO
    if 'id_token' in session and session['id_token'] and not _is_token_expired(session['user']['exp']):
        id_token = session['id_token']
    else:
        api_token = _get_token_from_cache(config, config['API_DELEGATED_PERMISSONS'])

        # Load cache
        cache = _load_cache()
        appx = msal.ConfidentialClientApplication(
            config['CLIENT_ID'], authority=config['AD_AUTHORITY'],
            client_credential=config['CLIENT_SECRET'], token_cache=cache,
            verify=config['SSL_VERIFY']
        ).acquire_token_on_behalf_of(api_token['access_token'], config['API_DELEGATED_PERMISSONS'])
        # print('appx')
        # print(appx)
        # print('')
        if not appx:
            session['id_token'] = None
            session['user'] = None
            id_token = None
        else:
            id_token = appx['id_token']
            session['id_token'] = id_token
            session['user'] = appx['id_token_claims']

    return id_token
