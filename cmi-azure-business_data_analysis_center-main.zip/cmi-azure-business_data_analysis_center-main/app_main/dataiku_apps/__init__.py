# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com
from flask import Blueprint, redirect, url_for
from dash import Dash
# from flask_login import login_required
from flask_dance.contrib.azure import azure

bp = Blueprint('dashapps', __name__, template_folder='templates')

