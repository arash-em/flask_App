# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from dash import html, dcc, callback_context, dash_table
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dash.dependencies import Input, Output, State
import pandas as pd
import numpy as np
from math import floor, log10
from dash.exceptions import PreventUpdate
from app_main.dataiku_apps.lib.main_lib import CACHE

app = CACHE.app

DROPDOWN_WIDTH = 350
PAGE_SIZE = 15
TAB_HEIGHT = '46px'
APPNAME = 'fet_brpp-sample_master'
SEARCH_WINDOW_WIDTH = 2

dict_content = {
    'search-tab': ['Execution'],
    'vis-tab': {'Execution': ['Display', 'Review'],},
}

IND_DISPLAY = '01'
DICT_TABLE_COLS = {
    'col1': ['BatchID', 'BatchDesc', 'MFGSite', 'MFGLine', 'GradeName', 'CampaignID', 'SampleSeq', 'LotID', 'SampleComment'],
    'col2': ['SampleLegend', 'Display']
}
COLS_NUMERIC = ['CampaignID', 'SampleSeq']
DICT_TABLE_OPTIONS = {
    'Display': ['Yes', 'No'],
    'SampleLegend': ['Control', 'Test'],
}
COLOR_RED = '#ff8000'
# ---------------------------------------------------------------------

tab_pad_top, tab_pad_bottom = 13, 13
tab_style = {'padding-top': f'{tab_pad_top}px', 'padding-bottom': f'{tab_pad_bottom}px'}
tab_classname_default = 'w3-bar-item w3-button w3-mobile'
tab_classname_highlight = 'w3-bar-item w3-button w3-red w3-mobile'

search_tabs = dict_content['search-tab']
div_search_tabs = html.Div(
    children=[
                 html.A(className=tab_classname_highlight, children=search_tabs[0], id=f'{APPNAME}-search-tab-0', style=tab_style),
             ] + [
                 html.A(className=tab_classname_default, children=search_tabs[i + 1], id=f'{APPNAME}-search-tab-{i + 1}', style=tab_style)
                 for i in range(len(search_tabs) - 1)
             ],
    id=f'{APPNAME}-search-tabs', className='w3-white',
    style={'margin-top': '0px', 'padding-left': '0px', 'margin-right': '10px', 'margin-left': '10px'}
)


search_tab_0 = dict_content['search-tab'][0]
vis_tabs = dict_content['vis-tab'][search_tab_0]
div_vis_tabs = html.Div(
    children=[
                 html.A(className=tab_classname_highlight, children=vis_tabs[0], id=f'{APPNAME}-vis-tab-0', style=tab_style),
             ] + [
                 html.A(className=tab_classname_default, children=vis_tabs[i + 1], id=f'{APPNAME}-vis-tab-{i + 1}', style=tab_style)
                 for i in range(len(vis_tabs) - 1)
             ],
    id=f'{APPNAME}-tab_vis', className='w3-bar w3-white',
    style={'margin-top': '0px', 'padding-left': '0px'}
)


div_search_buttons = html.Div(
    [
        html.Div(children=[
            html.Button(
                children=[html.H6(html.B('Review Modifications'))],
                id=f'{APPNAME}-search_buttons-review_change',
                style={'width': '125px', 'margin-bottom': '10px'}
            ),
            html.Div([
                html.Div('Page Size:', style={'width': '70', 'margin-top': '3px'}),
                dcc.Input(
                    id=f'{APPNAME}-search_buttons-table_display-page_size',
                    value=PAGE_SIZE,
                    type='number',
                    placeholder=PAGE_SIZE,
                    style={'width': '57px', 'margin-left': '5px', 'margin-bottom': '10px'},
                    debounce=True
                )],
                style={'display': 'flex'}
            ),
        ],
            id=f'{APPNAME}-div-search-buttons-0'
        ),
        html.Div(children=[
            html.Button(
                children=[html.H6(html.B('Submit Modifications'))],
                id=f'{APPNAME}-search_buttons-submit_change',
                style={'width': '125px', 'margin-bottom': '10px', 'background-color': COLOR_RED, 'color': 'white'}
            ),
            html.Div([
                html.Div('Page Size:', style={'width': '70', 'margin-top': '3px'}),
                dcc.Input(
                    id=f'{APPNAME}-search_buttons-table_review-page_size',
                    value=PAGE_SIZE,
                    type='number',
                    placeholder=PAGE_SIZE,
                    style={'width': '57px', 'margin-left': '5px', 'margin-bottom': '10px'},
                    debounce=True
                )],
                style={'display': 'flex'}
            ),
        ],
            id=f'{APPNAME}-div-search-buttons-1',
            style={'display': 'none'}
        )
    ],
    style={'padding-left': '15px', 'padding-right': '15px', 'margin-top': '10px'}
)


div_vis_buttons = dcc.Loading(children=html.Div(children=[

]))

div_query_display_switch = html.Button(
    children=[
        html.A(className='far fa-eye-slash', id=f'{APPNAME}-search-display_switch_icon'),
        html.A(' Hide queries', id=f'{APPNAME}-search-display_switch_text'),
    ],
    style={'width': '150px', 'height': TAB_HEIGHT, 'margin-right': '10px'},
    id=f'{APPNAME}-search-display_switch')


table_cols = DICT_TABLE_COLS['col1'] + DICT_TABLE_COLS['col2']
dict_table_prop = {
    'style_table': {'margin-bottom': '0px', 'margin-top': '10px', 'margin-left': '0px', 'width': '100%',
                    'height': 35.5 * (PAGE_SIZE + 2), 'minHeight': 35.5 * (PAGE_SIZE + 2), 'overflow-y': 'scroll', 'overflow-x': 'scroll'},
    'style_cell': {'whiteSpace': 'normal', 'fontSize': 13, 'height': '25px', 'minHeight': '25px',
                   'textOverflow': 'ellipsis', 'text-align': 'left',},
    'style_header': {'backgroundColor': 'rgb(210, 210, 210)', 'color': 'black', 'fontWeight': 'bold', 'border': '1px solid black',
                     'text-align': 'left',},
    'style_data': {'border': '1px solid black', 'overflowX': 'auto'},
    'fixed_rows': {'headers': True},
    'dropdown': {key: {'options': [{'label': i, 'value': i} for i in DICT_TABLE_OPTIONS[key]],
                       'clearable': False} for key in DICT_TABLE_OPTIONS},
    'style_cell_conditional': [
        {'if': {'column_id': 'BatchID'}, 'width': '120px', 'minWidth': '60px', 'maxWidth': '120px'},
        {'if': {'column_id': 'BatchDesc'}, 'width': 'auto', 'maxWidth': '200px'},
        {'if': {'column_id': 'MFGSite'}, 'width': '60px', 'minWidth': '40px', 'maxWidth': '60px'},
        {'if': {'column_id': 'MFGLine'}, 'width': '60px', 'minWidth': '40px', 'maxWidth': '60px'},
        {'if': {'column_id': 'GradeName'}, 'width': '80px', 'minWidth': '60px', 'maxWidth': '80px'},
        {'if': {'column_id': 'CampaignID'}, 'width': '80px', 'minWidth': '50px', 'maxWidth': '80px'},
        {'if': {'column_id': 'SampleSeq'}, 'width': '75px', 'minWidth': '50px', 'maxWidth': '75px'},
        {'if': {'column_id': 'LotID'}, 'width': '95px', 'minWidth': '55px', 'maxWidth': '95px'},
        {'if': {'column_id': 'SampleComment'}, 'width': 'auto', 'minWidth': '50px', 'maxWidth': '200px'},
        {'if': {'column_id': 'SampleLegend'}, 'width': '90px', 'minWidth': '50px', 'maxWidth': '90px'},
        {'if': {'column_id': 'Display'}, 'width': '65px', 'minWidth': '65px', 'maxWidth': '65px'},
        {'if': {'column_id': 'Comment'}, 'width': 'auto', 'minWidth': '40px', 'maxWidth': '200px'},
    ],
}

colmumns_display = [{'name': table_cols[i], 'id': table_cols[i], 'presentation': 'dropdown'}
                    if table_cols[i] in DICT_TABLE_OPTIONS else
                    ({'name': table_cols[i], 'id': table_cols[i], 'editable': False} if table_cols[i] in ['BatchID', 'BatchDesc'] else
                     {'name': table_cols[i], 'id': table_cols[i]})
                     for i in range(len(table_cols))]
colmumns_review = [{'name': table_cols[i], 'id': table_cols[i], 'editable': False} if table_cols[i] in ['BatchID', 'BatchDesc'] else
                   {'name': table_cols[i], 'id': table_cols[i]} for i in range(len(table_cols))]

for i in range(len(colmumns_display)):
    if colmumns_display[i]['name'] in COLS_NUMERIC:
        colmumns_display[i]['type'] = 'numeric'
        colmumns_review[i]['type'] = 'numeric'

div_main_display = html.Div(id=f'{APPNAME}-div_main_display', children=[
    html.Div(id=f'{APPNAME}-div_main_display-vis-display', children=dcc.Loading(
        dash_table.DataTable(
            id=f'{APPNAME}-search-table-sample_master-display',
            columns=colmumns_display,
            data=[],
            style_table=dict_table_prop['style_table'],
            style_cell=dict_table_prop['style_cell'],
            style_header=dict_table_prop['style_header'],
            style_data=dict_table_prop['style_data'],
            fixed_rows=dict_table_prop['fixed_rows'],
            editable=True,
            page_current=0,
            page_size=PAGE_SIZE,
            filter_action="native",
            sort_action="native",
            sort_mode="multi",
            dropdown={
                key: {'options': [{'label': i, 'value': i} for i in DICT_TABLE_OPTIONS[key]],
                      'clearable': False} for key in DICT_TABLE_OPTIONS
            },
            style_cell_conditional=dict_table_prop['style_cell_conditional'],
        )
    )),
    html.Div(id=f'{APPNAME}-div_main_display-vis-review', style={'display': 'none'}, children=dcc.Loading(
        dash_table.DataTable(
            id=f'{APPNAME}-search-table-sample_master-review',
            columns=[{'name': table_cols[i], 'id': table_cols[i]} for i in range(len(table_cols))],
            data=[],
            style_table=dict_table_prop['style_table'],
            style_cell=dict_table_prop['style_cell'],
            style_header=dict_table_prop['style_header'],
            style_data=dict_table_prop['style_data'],
            fixed_rows=dict_table_prop['fixed_rows'],
            editable=False,
            page_current=0,
            page_size=PAGE_SIZE,
            filter_action="native",
            sort_action="native",
            sort_mode="multi",
            style_cell_conditional=dict_table_prop['style_cell_conditional'],
        )
    ), )
])

div_sample_master = html.Div([
    dcc.Store(id=f'{APPNAME}_data_vis_memory_page', storage_type='memory', data={}),
    dcc.Store(id=f'{APPNAME}_data_vis_memory_data', storage_type='memory'),
    dcc.Store(f'{APPNAME}-Store-search_tab', storage_type='memory', data={'ind': 0}),
    dcc.Store(f'{APPNAME}-Store-vis_tab', storage_type='memory', data={'ind': 0}),
    dcc.Store(id=f'{APPNAME}_data_vis_memory_individual_selection', storage_type='memory'),
    dcc.Store(id=f'{APPNAME}_data_vis_memory_tabs_filter', storage_type='memory',
              data={'filter': 0, 'trigger': False}),
    dcc.Store(id=f'{APPNAME}_data_vis_memory_tabs_vis', storage_type='memory', data={'vis': 0}),
    dcc.ConfirmDialog(id=f'{APPNAME}-pop_up_window-user_not_admin', message=''),
    html.Div(id=f'{APPNAME}_data_vis_div_null'),
    html.Div([
        html.Div(
            id=f'{APPNAME}-query_filter',
            className=f'w3-col s{SEARCH_WINDOW_WIDTH}',
            children=[
                html.Div(children=[
                    div_search_tabs,
                    div_search_buttons,
                ]),
                dcc.Loading(
                    id=f'{APPNAME}_loading_main_data',
                    children=[
                        dcc.Store(id=f'{APPNAME}-memory-vis-display-data', storage_type='memory', data={}),
                        dcc.Store(id=f'{APPNAME}-memory-vis-review-data', storage_type='memory', data={}),
                        dcc.Store(id=f'{APPNAME}-memory-vis-compare-data', storage_type='memory', data={}),
                    ],
                ),
            ], style={'border-right': '8px solid #ffffff'}
        ),
        html.Div(
            id=f'{APPNAME}-main_display',
            className=f'w3-col s{12-SEARCH_WINDOW_WIDTH}',
            children=[
                html.Div([
                    div_query_display_switch,
                    div_vis_tabs,
                ], style={'display': 'flex'}),
                div_vis_buttons,
                div_main_display,
        ], style={'padding-left': '10px'}),

    ], className='w3-row'),
], style={'fontSize': 13})


@app.callback([Output(f'{APPNAME}-query_filter', 'style'), Output(f'{APPNAME}-main_display', 'className'),
               Output(f'{APPNAME}-search-display_switch_icon', 'className'), Output(f'{APPNAME}-search-display_switch_text', 'children')],
               Input(f'{APPNAME}-search-display_switch', 'n_clicks'))
def update_query_display_show_hide(_a):
    if _a is None:
        raise PreventUpdate
    if _a % 2 == 1:
        thisapp_search_display_switch_icon_classname = 'far fa-eye'
        thisapp_search_display_switch_text = ' Show queries'
        thisapp_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'none'}
        thisapp_main_display_classname = 'w3-col '
    else:
        thisapp_search_display_switch_icon_classname = 'far fa-eye-slash'
        thisapp_search_display_switch_text = ' Hide queries'
        thisapp_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'block'}
        thisapp_main_display_classname = f'w3-col s{12-SEARCH_WINDOW_WIDTH}'
    output = [thisapp_query_filter_style, thisapp_main_display_classname, thisapp_search_display_switch_icon_classname,
              thisapp_search_display_switch_text]
    return output


# Update display/review div show and hide
dict_tabs = {'search': search_tabs, 'vis': vis_tabs}
for tab in dict_tabs:
    _tabs = dict_tabs[tab]
    inputs_vis_tabs_ori = [Input(f'{APPNAME}-{tab}-tab-{i}', 'n_clicks') for i in range(len(_tabs))]
    if tab == 'vis':
        inputs_vis_tabs = [i for i in inputs_vis_tabs_ori] + [Input(f'{APPNAME}-search_buttons-submit_change', 'n_clicks'),
                                                              Input(f'{APPNAME}-search_buttons-review_change', 'n_clicks')]
    else:
        inputs_vis_tabs = [i for i in inputs_vis_tabs_ori]
    outputs_vis_tabs = [Output(f'{APPNAME}-Store-{tab}_tab', 'data')] + [Output(f'{APPNAME}-{tab}-tab-{i}', 'className') for i in range(len(_tabs))]
    states_vis_tabs = [Input(f'{APPNAME}-{tab}-tab-{i}', 'className') for i in range(len(_tabs))]

    @app.callback(outputs_vis_tabs, inputs_vis_tabs, states_vis_tabs)
    def update_vis_tab_classname(*args):
        trigger = callback_context.triggered[0]
        if len(args) == 6:
            n_tabs = 2
        else:
            n_tabs = 1
        if type(trigger) is dict:
            item_click = trigger['prop_id'].split('.')[0].split('.')[0]
            if len(trigger['prop_id']) <= 2:
                outputs_classname = [tab_classname_highlight] + [tab_classname_default] * (n_tabs - 1)
                data_output = {'ind': 0}
            elif '-tab-' in item_click:
                ind_click = int(item_click.split('-')[-1])
                n_clicks = args[:n_tabs]
                bool_not_init = any([i is not None for i in n_clicks])
                if bool_not_init:
                    outputs_classname = [tab_classname_default] * n_tabs
                    outputs_classname[ind_click] = tab_classname_highlight
                    data_output = {'ind': ind_click, 'position': 1}
                else:
                    outputs_classname = [tab_classname_highlight] + [tab_classname_default] * (n_tabs - 1)
                    data_output = {'ind': 0, 'position': 2}
            else:
                if 'submit_change' in item_click:
                    outputs_classname = [tab_classname_highlight, tab_classname_default] * (n_tabs - 1)
                    data_output = {'ind': 0, 'position': 3}
                else:

                    outputs_classname = [tab_classname_default, tab_classname_highlight]
                    data_output = {'ind': 1}
        else:
            raise PreventUpdate
        outputs = [data_output] + outputs_classname
        return outputs


for table in ['display', 'review']:
    @app.callback(Output(f'{APPNAME}-search-table-sample_master-{table}', 'page_size'),
                  Output(f'{APPNAME}-search-table-sample_master-{table}', 'style_table'),
                  Input(f'{APPNAME}-search_buttons-table_{table}-page_size', 'value'))
    def update_table_page(page_size):
        dict_template = dict_table_prop['style_table']
        dict_output = {i: dict_template[i] for i in dict_template}
        dict_output['height'] = 35.5 * (page_size + 2)
        dict_output['minHeight'] = 35.5 * (page_size + 2)
        return page_size, dict_output


@app.callback([Output(f'{APPNAME}-div-search-buttons-0', 'style'), Output(f'{APPNAME}-div_main_display-vis-display', 'style'),
               Output(f'{APPNAME}-div-search-buttons-1', 'style'), Output(f'{APPNAME}-div_main_display-vis-review', 'style')],
              Input(f'{APPNAME}-Store-vis_tab', 'data'))
def update_query_display_show_hide(data_input):
    if data_input is None:
        raise PreventUpdate
    style_show, style_hide = {'display': 'block'}, {'display': 'none'}
    if data_input['ind'] == 0:
        return [style_show, style_show, style_hide, style_hide]
    else:
        return [style_hide, style_hide, style_show, style_show]


@app.callback(Output(f'{APPNAME}-search-table-sample_master-display', 'data'),
              Output(f'{APPNAME}-memory-vis-display-data', 'data'),
              Output(f'{APPNAME}-pop_up_window-user_not_admin', 'displayed'),
              Output(f'{APPNAME}-pop_up_window-user_not_admin', 'message'),
              Input(f'{APPNAME}-search_buttons-submit_change', 'n_clicks'),
              State(f'{APPNAME}-search-table-sample_master-review', 'data'),
              State(f'{APPNAME}-memory-vis-compare-data', 'data'),

              State(f'{APPNAME}-search-table-sample_master-display', 'data'),
              State(f'{APPNAME}-memory-vis-display-data', 'data'),
              State('root_memory_global', 'data'))
def update_sample_master_table(_, dict_data_review, dict_data_memory_compare, dict_data_display, dict_data_memory_display, data_user):
    if len(dict_data_review) > 0:
        if _ > 0:
            # Make sure the users who are not admin can not make changes to the database itself
            user_email = data_user['userinfo']['email']
            command = """select email from AppRole where app='fet_brpp' and role like '%admin%'"""
            admin_emails = list(CACHE.exe_cloud_sql(command)['email'])
            if user_email not in admin_emails:
                return dict_data_display, dict_data_memory_display, True, 'Sorry, you do not have Admin authority to make changes to this table.'

        pd_data_review = pd.DataFrame(dict_data_review)
        pd_data_compare = pd.DataFrame(dict_data_memory_compare['data'])
        for i in range(len(pd_data_review)):
            pd_entry = pd_data_review.iloc[i]
            pd_entry_compare = pd_data_compare.iloc[i]
            cols_fix = {'BatchID', 'BatchDesc'}
            _batchid = pd_entry['BatchID']
            set_value_list = []
            cols_to_set = [i for i in pd_data_review.columns if i not in cols_fix]
            for col in cols_to_set:
                _value = pd_entry[col]
                _bool = pd_entry_compare[col]
                if _bool:
                    if col in COLS_NUMERIC:
                        if col in DICT_TABLE_COLS['col2']:
                            set_value_str = f"[{col}{IND_DISPLAY}]={_value}"
                        else:
                            set_value_str = f"[{col}]={_value}"
                    else:
                        if col in DICT_TABLE_COLS['col2']:
                            set_value_str = f"[{col}{IND_DISPLAY}]='{_value}'"
                        else:
                            set_value_str = f"[{col}]='{_value}'"
                    set_value_list.append(set_value_str)
            set_value_str_all = ','.join(set_value_list)
            command = f"""update FE_SampleDesc
            set {set_value_str_all}
            where [BatchID] = '{_batchid}'
            """
            CACHE.exe_cloud_sql(command)

    if 1 == 1:
        query_cols_str = ', '.join(DICT_TABLE_COLS['col1'] + [f'{i}{IND_DISPLAY}' for i in DICT_TABLE_COLS['col2']])
        command = f"""
                select {query_cols_str}  
                from FE_SampleDesc
                """
        pd_sample = CACHE.exe_cloud_sql(command)
        dict_rename = {f'{i}{IND_DISPLAY}': i for i in DICT_TABLE_COLS['col2']}
        pd_sample = pd_sample.rename(columns=dict_rename)
        pd_sample = pd_sample.fillna('')
    else:
        filename = f'{CACHE.DIR}/static_data/pd_sample.pkl'
        # pd_sample.to_pickle(filename)
        pd_sample = pd.read_pickle(filename)
        # print(pd_sample)
    return pd_sample.to_dict('record'), {'data': pd_sample.to_dict('record')}, False, ''


@app.callback(Output(f'{APPNAME}-search-table-sample_master-review', 'data'),
              Output(f'{APPNAME}-search-table-sample_master-review', 'style_cell_conditional'),
              Output(f'{APPNAME}-memory-vis-compare-data', 'data'),
              Input(f'{APPNAME}-search_buttons-review_change', 'n_clicks'),
              Input(f'{APPNAME}-search_buttons-submit_change', 'n_clicks'),
              State(f'{APPNAME}-search-table-sample_master-display', 'data'),
              State(f'{APPNAME}-memory-vis-display-data', 'data'), )
def update_review_table(_1, _2, data_display_table, data_store_input):
    style_output = [i for i in dict_table_prop['style_cell_conditional']]
    if (_1 is None) & (_2 is None):
         return [], style_output, {}
    elif 1 == 1:
        trigger = callback_context.triggered[0]
        item_click = trigger['prop_id'].split('.')[0].split('.')[0]
        if 'search_buttons-submit_change' in item_click:
            return [], style_output, {}
        else:
            pd_table = pd.DataFrame(data_display_table)
            pd_store = pd.DataFrame(data_store_input['data'])

            col_unique = 'BatchID'
            pd_combine = pd.concat([pd_table, pd_store]).drop_duplicates()
            pd_size = pd_combine.groupby(col_unique).size()
            pd_size_2 = pd_size.loc[pd_size > 1]
            batchid_list = list(pd_size_2.index)
            pd_new = pd_table.loc[pd_table[col_unique].isin(batchid_list)].sort_values(by=col_unique)
            pd_old = pd_store.loc[pd_store[col_unique].isin(batchid_list)].sort_values(by=col_unique)

            pd_compare = pd.DataFrame(data=pd_new.values != pd_old.values, columns=pd_old.columns)
            pd_compare[col_unique] = list(pd_old[col_unique])
            cols_could_change = [i for i in pd_compare.columns if i not in ['BatchID', 'BatchDesc']]
            for col in cols_could_change:
                if pd_compare[col].sum() > 0:
                    pd_compare_col = pd_compare.loc[pd_compare[col]]
                    _ind_list = list(pd_compare_col.index)
                    for _ind in _ind_list:
                        style_output.append(
                            {'if': {'column_id': col, 'row_index': _ind},
                             'backgroundColor': COLOR_RED, 'color': 'white'}
                        )
            return pd_new.to_dict('record'), style_output, {'data': pd_compare.to_dict('record')}
