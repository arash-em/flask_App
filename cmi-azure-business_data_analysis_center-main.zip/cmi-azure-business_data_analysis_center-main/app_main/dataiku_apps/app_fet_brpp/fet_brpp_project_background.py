# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from app_main.dataiku_apps.lib.main_lib import CACHE

from dash.dependencies import Input, Output
from dash import html
import base64


padding_paragraph = '5px'
dict_href_style = {}
dict_image = CACHE.dict_image
app = CACHE.app

div_project_background = html.Div(
    children=[
        html.Div(id='project_brpp_background_null'),
        html.Div(
            children=[
                html.Img(src=dict_image['fet-BRPO-L2'])
                #html.Video(controls=True, src='data:video/mp4;base64,{}'.format(encoded_video_1.decode()))
            ],
            style={'padding-top': padding_paragraph}
        ),
    ],
    style={'margin-top': '40px', 'margin-left': '60px', 'width': '750px', 'minWidth': '450px'}
)

