# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from dash import html, dcc, callback_context, dash_table
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dash.dependencies import Input, Output, State
import pandas as pd
import numpy as np
from math import floor, log10
from dash.exceptions import PreventUpdate
from app_main.dataiku_apps.lib.main_lib import CACHE

app = CACHE.app

DROPDOWN_WIDTH = 350
PAGE_SIZE = 15
TAB_HEIGHT = '46px'
SEARCH_WINDOW_WIDTH = 3
APPNAME = 'fet_brpp-data_vis'

COL_SORT = 'LotID'
DICT_HOVER_HEADER = {
    'BatchDesc': 'Batch Desc', 'BatchID': 'Batch ID', 'RequestID': 'Request ID', 'Value': 'Value',
    'SampleSeq': 'Sample Seq', 'MFGSite': 'MFG Site', 'MFGLine': 'MFG Line',
    'CampaignID': 'CampaignID', 'LotID': 'Lot ID', 'SampleComment': 'Comment',
    'CompleteTime': 'Complete Time',
}

def smart_round(sig):
    def rounder(x):
        if x == 0:
            return 0
        elif x < 0:
            x = abs(x)
            sign = -1
        else:
            sign = 1
        offset = sig - floor(log10(abs(x)))
        initial_result = round(x, offset)
        if str(initial_result)[-1] == '5' and initial_result == x:
            return round(x, offset - 2) * sign
        else:
            return round(x, offset - 1) * sign
    return rounder


CACHE.dict_activity_store['tab_main_material_visual'] = 'button_combined_spider_chart'
dict_vis_tabs = {
    'Results': ['Figure-Scalars', 'Figure-Arrays',  'Table (Scalars Only)', None, None, None, None, None, None],
    'Submissions': ['Request status', 'Num. of Submisison', 'Num. of Completion', 'Batch ID', 'Request ID', 'Request Item ID',
                    'Submit Time', 'Accept Time',
                    None]
}
LIST_SUBMISSIONS_COLS = ['Status', 'Num. of Submisison', 'Num. of Completion', 'BatchID', 'RequestID', 'RequestItemID', 'CreateTime', 'AcceptTime']

tab_pad_top, tab_pad_bottom = 13, 13
#tab_style = {'padding-top': f'{tab_pad_top}px', 'padding-bottom': f'{tab_pad_bottom}px'}
tab_style = {'padding-top': f'{tab_pad_top}px', 'padding-bottom': f'{tab_pad_bottom}px'}
tab_classname_default = 'w3-bar-item w3-button w3-mobile'
tab_classname_highlight = 'w3-bar-item w3-button w3-red w3-mobile'
div_data_tabs_visualization = html.Div(
    children=[
        html.A(className=tab_classname_highlight,
               children=dict_vis_tabs['Results'][0],
               id='fet_brpp_tab_vis_0',
               style=tab_style)] +
             [html.A(id=f'fet_brpp_tab_vis_{i + 1}', style=tab_style, className=tab_classname_default, children=dict_vis_tabs['Results'][i + 1])
              for i in range(len(dict_vis_tabs['Results']) - 1)]
    , id='fet_brpp_tab_vis', className='w3-bar w3-white',  style={'margin-top': '0px', 'padding-left': '0px'})

div_data_tabs_visualization_buttons = html.Div(
    id='fet_brpp_vis_button_sec',
    children=[
        html.Div(
            id='fet_brff_vis_button_figure_scalar',
            children=[],
            style={'display': 'block'}
        ),
        html.Div(
            id='fet_brff_vis_button_figure_array',
            children=[],
            style={'display': 'none'}
        ),
        html.Div(
            id='fet_brff_vis_button_table',
            children=[
                html.Button('Download', id='fet_brff_button_result_table_download'),
                dcc.Download(id="fet_brff_download_result_table_download")
            ],
            style={'display': 'none'}
        ),
    ],
    style={'margin-top': '10px'}
)

div_data_tabs_view = html.Div(
    children=[
        html.A(className=tab_classname_highlight,
               children=["Results"],
               id='fet_brpp_tab_view_0',
               style=tab_style),
        html.A(className=tab_classname_default,
               children=["Submissions"],
               id='fet_brpp_tab_view_1',
               style=tab_style),
    ],
    id='fet_brpp_tab_view', className='w3-white',
    style={'margin-top': '0px', 'padding-left': '0px', 'margin-right': '10px', 'margin-left': '10px'}
)

div_query_display_switch = html.Button(
    children=[
        html.A(className='far fa-eye-slash', id='fet_brpp_query_display_switch_icon'),
        html.A(' Hide queries', id='fet_brpp_query_display_switch_text'),
    ],
    style={'width': '150px', 'height': TAB_HEIGHT, 'margin-right': '10px'},
    id='fet_brpp_query_display_switch')

dict_div_filters = {}
dict_filters = {'Grade': 'single', 'Method': 'multi'}
dict_filters_options = {
    'Method': ['Additive Analysis', 'Charpy Notched_-20', 'Charpy Notched_-30', 'Charpy Notched_0', 'Charpy Notched_23', 'Color Hunter B',
               'Density', 'DMTA', 'DSC', 'Flex_ASTM_A', 'Flex_ASTM_B', 'Flex_ISO', 'FTIR', 'GPC', 'Hardness', 'HDT_ASTM_B_N', 'HDT_ASTM_B_Y',
               'HDT_ISO_A_N', 'HDT_ISO_B_N', 'IZOD_ASTM_-18', 'IZOD_ASTM_23', 'IZOD_ISO_-18', 'IZOD_ISO_-20', 'IZOD_ISO_-40', 'IZOD_ISO_23',
               'MFR', 'SAOS', 'Tensile_ASTM', 'Tensile_ISO'],
    'Grade': ['AP03B', 'AP0B3', 'AXO3BE3', 'PP7032E3', 'PP7032KN', 'PP7143KNE1', 'PP7414',  'PP7694E2']
}

for i_key, key_filter in enumerate(dict_filters):
    if dict_filters[key_filter] == 'single':
        dcc_container = dcc.RadioItems
    else:
        dcc_container = dcc.Checklist
    if dict_filters[key_filter] == 'single':
        pre_components = [html.Div(key_filter, style={'margin-top': '3px', 'margin-bottom': '3px'}),]
    else:
        pre_components = [
            html.Div(key_filter, style={'margin-top': '3px', 'margin-right': 'auto'}),
            html.Div([
                html.Button('Clear',
                            id=f'fet_button_clear_{key_filter}',
                            style={'margin-right': '15px'},
                            className='w3-right'),
                html.Button('All',
                            id=f'fet_button_all_{key_filter}',
                            style={'margin-right': '5px'},
                            className='w3-right')
            ]),
        ]

    dict_div_filters[key_filter] = html.Div([
        html.Div(pre_components, style={'width': '100%', 'display': 'flex'}),
        dcc.Loading(
            children=dcc_container(
                options=dict_filters_options[key_filter],
                labelStyle={'display': 'block', },
                inputStyle={"margin-right": "3px"},
                inline=False,
                labelClassName='Xchecklist',
                style={'height': '250px', 'width': '100%',
                       'overflow-y': 'scroll', 'background-color': 'white', 'hover-background-color': '#555555'},
                id=f'fet_brpp_filter_{i_key}'
            )
        )
    ], className='w3-col s6 w3-light-grey', style={'height': '150px', 'width': '50%', 'display': 'flex'}
    )

buttons_execution = html.Div([
    html.Div(
        children=[
            html.Div(
                children=[
                    html.Button('Refresh', id='fet_brpp_button_refresh_filters', style={'margin-right': '5px'}),
                    html.Button('Query Data', id='fet_brpp_button_query_data')
                ],
                style={'width': '100%'}
            ),
        ], style={'width': '50%', 'margin-bottom': '10px'}
    ),
    html.Div('Figure Mouser Hover Info Display'),
    dcc.Dropdown(
        options=sorted(DICT_HOVER_HEADER.keys()), value=['BatchDesc', 'BatchID', 'RequestID', 'MFGSite', 'MFGLine', 'LotID', 'Value'],
        id=f'{APPNAME}-search-dropdown-figure_hover_cols', style={'margin-bottom': '10px'}, multi=True
    ),
    html.Div('Figure Sample Sorted By'),
    dcc.Dropdown(
        options=sorted(DICT_HOVER_HEADER.keys()), value='LotID',
        id=f'{APPNAME}-search-dropdown-figure_sample_sort_col', style={'margin-bottom': '10px'}, multi=False
    )
])

n_col_filter = 2
n_row_filter = int(np.ceil(len(dict_div_filters) / n_col_filter))
dict_div_filters_keys = list(dict_div_filters.keys())
div_data_vis_filters_children = []

for row in range(n_row_filter):
    filters = dict_div_filters_keys[(row * n_col_filter): ((1 + row) * n_col_filter)]
    padding_top, padding_bottom = '5px', '5px'
    if row == 0:
        padding_top = '0px'
    if row == (n_row_filter - 1):
        padding_bottom = '0px'
    div_split = html.Div(
        children=[], className='w3-light-grey w3-row',
        style={'padding-left': '10px', 'padding-right': '10px', 'padding-top': padding_top, 'padding-bottom': padding_bottom})

    for col, filter in enumerate(filters):
        padding_left, padding_right = '5px', '5px'
        if col == 0:
            padding_left = '0px'
        if col == (n_col_filter - 1):
            padding_right = '0px'
        dict_div_filters[filter].style = {'padding-left': padding_left, 'padding-right': padding_right}
        div_split.children.append(dict_div_filters[filter])
    div_data_vis_filters_children.append(div_split)


div_data_visualization_filters = html.Div(
    children=[
        div_data_tabs_view,
        html.Div(
            id='fet_brpp_result_filters',
            children=div_data_vis_filters_children,
            className='w3-light-grey',
            style={'padding-left': '0px', 'padding-right': '5px', 'margin-top': '10px'}
        ),
        html.Div(
            children=buttons_execution,
            className='w3-light-grey',
            style={'padding-left': '15px', 'padding-right': '15px', 'margin-top': '10px'}
        )
    ]
)

@app.callback([Output('fet_brpp_filter_0', 'options'), Output('fet_brpp_filter_1', 'options')],
              [Input('fet_brpp_button_refresh_filters', 'n_clicks')])
def update_filter_options(_a):
    command = f"""
    select distinct t2.[gradename] as data, 'gradename' as datatype from 
    [dbo].[FE_BRPP_L2_request] t1 inner join [dbo].FE_SampleDesc t2 
    on t1.u_batchid = t2.BatchID
    where requestitemstatus = 'Completed'
    
    union
     
    select distinct [method] as data, 'method' as datatype from [dbo].[FE_BRPP_L2_request] where requestitemstatus = 'Completed'
            """
    pd_data_filter = CACHE.exe_cloud_sql(command)
    grade_list = sorted(pd_data_filter.loc[pd_data_filter['datatype'] == 'gradename']['data'])
    method_list = sorted(pd_data_filter.loc[pd_data_filter['datatype'] == 'method']['data'])
    return grade_list, method_list


div_main_display = html.Div(children=[
    html.Div(
        id='fet_brpp_result_vis_sec_figure_array_dropdown',
        children=[
            html.Div('Method'),
            dcc.Dropdown([], 'NYC', id='fet_brpp_result_vis_sec_figure_array_dropdown_method', style={'margin-bottom': '5px'}),
            html.Div('Measured Item'),
            dcc.Dropdown([], 'NYC', id='fet_brpp_result_vis_sec_figure_array_dropdown_measured_item', style={'margin-bottom': '5px'}, multi=True),
        ],
        style={'display': 'none'}
    ),
    html.Div(children=[
        dcc.Loading(
            style={'margin-top': '10px'},
            children=[html.Div(id='fet_brpp_div_main_display')
        ])
    ])
])

div_data_visualization = html.Div([
    dcc.Store(id='fet_brpp_data_vis_memory_page', storage_type='memory'),
    dcc.Store(id='fet_brpp_data_vis_memory_data', storage_type='memory'),
    dcc.Store(id='fet_brpp_data_vis_memory_tabs_filter', storage_type='memory',
              data={'filter': 0, 'trigger': False}),
    dcc.Store(id='fet_brpp_data_vis_memory_tabs_vis', storage_type='memory', data={'vis': 0}),
    dcc.ConfirmDialog(id='fet_brpp_pop_up_window_data_unavailable', message=''),
    html.Div(id='fet_brpp_data_vis_div_null'),
    html.Div([
        html.Div(
            id='fet_brpp_query_filter',
            className=f'w3-col s{SEARCH_WINDOW_WIDTH}',
            children=[
                div_data_visualization_filters,
                dcc.Loading(
                    id="fet_brpp_loading_main_data",
                    children=[
                        dcc.Store(id='fet_brpp_data_vis_memory_main_data_submissions', storage_type='memory', data={}),
                        dcc.Store(id='fet_brpp_data_vis_memory_main_data_results', storage_type='memory', data={})
                    ],
                ),
            ], style={'border-right': '8px solid #ffffff'}
        ),
        html.Div(
            id='fet_brpp_main_display',
            className=f'w3-col s{12 - SEARCH_WINDOW_WIDTH}',
            children=[
                html.Div([
                    div_query_display_switch,
                    div_data_tabs_visualization,

                ], style={'display': 'flex'}),

                div_data_tabs_visualization_buttons,
                div_main_display,

        ], style={'padding-left': '10px'}),

    ], className='w3-row'),
], style={'fontSize': 13})

for i_key, key_filter in enumerate(dict_filters):
    if dict_filters[key_filter] == 'multi':
        @app.callback(Output(f'fet_brpp_filter_{i_key}', 'value'),
                      [Input(f'fet_button_clear_{key_filter}', 'n_clicks'), Input(f'fet_button_all_{key_filter}', 'n_clicks')],
                      [State(f'fet_brpp_filter_{i_key}', 'options')])
        def define_filter_clear_all_buttons(_a, _b, options):
            trigger = callback_context.triggered[0]
            if (type(trigger) is dict) & ((_a is not None) | (_b is not None)):
                item_click = trigger['prop_id'].split('.')[0]
                if 'fet_button_clear' in item_click:
                    # clear button pressed
                    result = None if dict_filters[key_filter] == 'single' else []

                else:
                    # All button pressed
                    result = options[0] if dict_filters[key_filter] == 'single' else options

            else:
                result = None if dict_filters[key_filter] == 'single' else []
            return result

@app.callback([Output('fet_brpp_query_filter', 'style'), Output('fet_brpp_main_display', 'className'),
               Output('fet_brpp_query_display_switch_icon', 'className'), Output('fet_brpp_query_display_switch_text', 'children'),
               Input('fet_brpp_query_display_switch', 'n_clicks')])
def update_query_display_show_hide(_a):
    if _a is None:
        raise PreventUpdate
    if _a % 2 == 1:
        fet_brpp_query_display_switch_icon_classname = 'far fa-eye'
        fet_brpp_query_display_switch_text = ' Show queries'
        fet_brpp_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'none'}
        fet_brpp_main_display_classname = 'w3-col'
    else:
        fet_brpp_query_display_switch_icon_classname = 'far fa-eye-slash'
        fet_brpp_query_display_switch_text = ' Hide queries'
        fet_brpp_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'block'}
        fet_brpp_main_display_classname = f'w3-col s{12 - SEARCH_WINDOW_WIDTH}'
    output = [fet_brpp_query_filter_style, fet_brpp_main_display_classname, fet_brpp_query_display_switch_icon_classname,
              fet_brpp_query_display_switch_text]
    return output


@app.callback([Output(f'fet_brpp_tab_vis_{i}', 'children') for i in range(len(dict_vis_tabs['Results']))] +
              [Output('fet_brpp_data_vis_memory_tabs_filter', 'data'), Output('fet_brpp_result_filters', 'style')] +
              [Output('fet_brpp_tab_view_0', 'className'), Output('fet_brpp_tab_view_1', 'className')],
              [Input('fet_brpp_tab_view_0', 'n_clicks'), Input('fet_brpp_tab_view_1', 'n_clicks')],
              [State(f'fet_brpp_tab_vis_{i}', 'children') for i in range(len(dict_vis_tabs['Results']))] +
              [State('fet_brpp_data_vis_memory_tabs_filter', 'data'), State('fet_brpp_result_filters', 'style')])
def update_vis_tabs(_a, _b, _state_0, _state_1, _state_2, _state_3, _state_4, _state_5, _state_6, _state_7, _state_8,
                    _data_tab_filter, style_input):
    """
    Update
    1. The cache for what is the currently active data type, "Results" or "Submissions"
    2. Whether to put the selection of "Grade" and "Method" visible, they are only visible in the case of "Results" data type
    3. Visualization tabs update:
        Follow variable dict_vis_tabs
    """
    trigger = callback_context.triggered[0]
    filters_style = {i: style_input[i] for i in style_input}
    classname0, classname1 = tab_classname_highlight, tab_classname_default
    if (type(trigger) is dict) & ((_a is not None) | (_b is not None)):
        item_click = trigger['prop_id'].split('.')[0]

        if 'fet_brpp_tab_view_0' in item_click:
            filters_style['display'] = 'block'
            _state_0, _state_1, _state_2, _state_3, _state_4, _state_5, _state_6, _state_7, _state_8 = dict_vis_tabs['Results']
        else:
            filters_style['display'] = 'None'
            _state_0, _state_1, _state_2, _state_3, _state_4, _state_5, _state_6, _state_7, _state_8 = dict_vis_tabs['Submissions']
            classname0, classname1 = tab_classname_default, tab_classname_highlight

        if len(_data_tab_filter) == 0:
            _data_tab_filter = {'filter': int(item_click.split('_')[-1]), 'trigger': True}
        else:
            _data_tab_filter['trigger'] = int(item_click.split('_')[-1]) != _data_tab_filter['filter']
            _data_tab_filter['filter'] = int(item_click.split('_')[-1])

    return _state_0, _state_1, _state_2, _state_3, _state_4, _state_5, _state_6, _state_7, _state_8, _data_tab_filter, \
           filters_style, classname0, classname1


@app.callback([Output('fet_brpp_data_vis_memory_tabs_vis', 'data')] +
              [Output(f'fet_brpp_tab_vis_{i}', 'className') for i in range(len(dict_vis_tabs['Results']))],
              [Input(f'fet_brpp_tab_vis_{i}', 'n_clicks') for i in range(len(dict_vis_tabs['Results']))] +
              [Input('fet_brpp_data_vis_memory_tabs_filter', 'data')],
              [State(f'fet_brpp_tab_vis_{i}', 'className') for i in range(len(dict_vis_tabs['Results']))])
def update_main_display_data(_0, _1, _2, _3, _4, _5, _6, _7, _8, _data_tab_filter,
                             _classname_0, _classname_1, _classname_2, _classname_3, _classname_4, _classname_5, _classname_6,
                             _classname_7, _classname_8):
    """
    Update
    1. The cache for what is the currently active visible visualization tab
    2. The className for all the visible visualization tabs
    """
    trigger = callback_context.triggered[0]
    all_none = all([i is None for i in [_0, _1, _2, _3, _4, _5, _6, _7, _8]])
    classname_list = [tab_classname_default] * len(dict_vis_tabs['Submissions'])
    data_tabs_vis = {'vis': 0}

    if (type(trigger) is dict) & (not all_none):
        if 'prop_id' in trigger:
            item_click = trigger['prop_id'].split('.')[0]
            if 'fet_brpp_tab_vis' in item_click:
                ind_tab_active = int(item_click.split('_')[-1])
                n_valid = len([i for i in dict_vis_tabs[list(dict_vis_tabs.keys())[_data_tab_filter['filter']]] if i is not None])
                if ind_tab_active < n_valid:
                    # click the valid tab, update
                    classname_list[ind_tab_active] = tab_classname_highlight
                    data_tabs_vis = {'vis': ind_tab_active}
                else:
                    # click the invalid tab, maintain the current configurations
                    classname_list = [_classname_0, _classname_1, _classname_2, _classname_3, _classname_4, _classname_5, _classname_6,
                                      _classname_7, _classname_8]
                    data_tabs_vis = {'vis': [i for i in range(len(classname_list)) if classname_list[i] == tab_classname_highlight][0]}
            else:
                if _data_tab_filter['trigger']:
                    # filter tab changed, tab_vis to be 0
                    classname_list[0] = tab_classname_highlight
                    data_tabs_vis = {'vis': 0}
                else:
                    # filter tab not changed, maintain the current configurations
                    classname_list = [_classname_0, _classname_1, _classname_2, _classname_3, _classname_4, _classname_5, _classname_6,
                                      _classname_7, _classname_8]
                    data_tabs_vis = {'vis': [i for i in range(len(classname_list)) if classname_list[i] == tab_classname_highlight][0]}
        else:
            classname_list[0] = tab_classname_highlight
    else:
        classname_list[0] = tab_classname_highlight
    return [data_tabs_vis] + classname_list

@app.callback([Output('fet_brff_vis_button_figure_scalar', 'style'), Output('fet_brff_vis_button_figure_array', 'style'),
               Output('fet_brff_vis_button_table', 'style'), Output('fet_brpp_result_vis_sec_figure_array_dropdown', 'style')],
              [Input('fet_brpp_data_vis_memory_tabs_vis', 'data')],
              [State('fet_brpp_data_vis_memory_tabs_filter', 'data'), State('fet_brff_vis_button_figure_scalar', 'style'),
               State('fet_brff_vis_button_figure_array', 'style'),
               State('fet_brff_vis_button_table', 'style'), State('fet_brpp_result_vis_sec_figure_array_dropdown', 'style')])
def update_vis_button_sec(data_tabs_vis, data_tabs_filter, _a, _b, _c, _d):
    style_show = {'display': 'block'}
    style_hide = {'display': 'none'}
    if data_tabs_filter['filter'] == 0:
        tab_name = dict_vis_tabs['Results'][data_tabs_vis['vis']]
        if tab_name is None:
            return [_a, _b, _c, _d]
        elif ('Figure' in tab_name) & ('Scalar' in tab_name):
            return [style_show, style_hide, style_hide, style_hide]
        elif ('Figure' in tab_name) & ('Array' in tab_name):
            return [style_hide, style_show, style_hide, style_show]
        else:
            return [style_hide, style_hide, style_show, style_hide]
    else:
        return [style_hide, style_hide, style_show, style_hide]

@app.callback(Output('fet_brff_download_result_table_download', 'data'),
              [Input('fet_brff_button_result_table_download', 'n_clicks')],
              [State('fet_brpp_data_vis_memory_tabs_vis', 'data'), State('fet_brpp_data_vis_memory_tabs_filter', 'data'),
               State('fet_brpp_data_vis_memory_main_data_results', 'data'),
               State('fet_brpp_data_vis_memory_main_data_submissions', 'data')], prevent_initial_call=True)
def result_table_download(_a, data_tabs_vis, data_tabs_filter, dict_data_table_result, data_main_submissions):
    if data_tabs_filter['filter'] == 0:
        pd_data_table = pd.DataFrame(dict_data_table_result['scalar'])
        grade = pd_data_table.iloc[0]['GradeName']
        return dcc.send_data_frame(pd_data_table.to_csv, f'{grade}_scalar.csv')
    else:
        col_stack, pd_base = get_submission_result(data_tabs_vis, data_main_submissions)
        pd_base = pd_base.sort_values(by=['BatchDesc'])
        pd_result = pd_base[[i for i in pd_base.columns if i not in ['BatchDesc']]]
        return dcc.send_data_frame(pd_result.to_csv, f'Submission_{col_stack}.csv')


@app.callback([Output('fet_brpp_data_vis_memory_main_data_results', 'data'), Output('fet_brpp_data_vis_memory_main_data_submissions', 'data')],
              [Input('fet_brpp_button_query_data', 'n_clicks')],
              [State(f'fet_brpp_data_vis_memory_tabs_filter', 'data'), State(f'fet_brpp_data_vis_memory_tabs_vis', 'data'),
               State('fet_brpp_data_vis_memory_main_data_results', 'data'), State('fet_brpp_data_vis_memory_main_data_submissions', 'data'),
               State('fet_brpp_filter_0', 'value'), State('fet_brpp_filter_1', 'value')])
def get_main_data(_a, data_tab_filter, data_tab_vis, data_main_results, data_main_submissions, grade, method_list):
    trigger = callback_context.triggered[0]
    if (type(trigger) is dict) & (_a is not None):
        if 'prop_id' in trigger:
            tab_filter = list(dict_vis_tabs.keys())[data_tab_filter['filter']]
            tab_vis = dict_vis_tabs[tab_filter][data_tab_vis['vis']]

            dict_rename = {'method': 'Method', 'gradename': 'GradeName', 'sampleseq': 'SampleSeq',
                           'requestitemid': 'RequestItemID',
                           'requestid': 'RequestID', 'requestitemstatus': 'Status', 'batchdesc': 'RawSampleDesc',
                           'createdt': 'CreateTime', 'u_accepteddt': 'AcceptTime', 'moddt': 'CompleteTime',
                           'paramid': 'Item', 'displayvalue': 'Value', 'enteredunits': 'Unit', 'displayunits': 'Unit',
                           'attachmentclob': 'ArrayValue', 'u_batchid': 'BatchID'
                           }

            if tab_filter == 'Results':
                if (grade is None) | (method_list is None):
                    pd_data_scalar, pd_data_array = [pd.DataFrame({})] * 2
                elif len(method_list) == 0:
                    pd_data_scalar = pd.DataFrame({})
                    pd_data_array = pd.DataFrame({})
                else:
                    method_list_str = "('" + "', '".join(method_list) + "')"
                    command = f"""
                                with t1 as (
                                    select tt1.[method], tt2.[GradeName], tt2.[SampleLegend01] as SampleLegend, tt2.[SampleSeq], 
                                    tt2.[BatchDesc], tt2.[MFGSite], tt2.[MFGLine], tt2.[CampaignID], tt2.[LotID], tt2.[SampleComment], 
                                    tt1.[requestid], tt1.[u_batchid], tt1.[createdt], tt1.[u_accepteddt], tt1.[moddt], tt1.[datakeyid1]
                                    
                                    from [dbo].[FE_BRPP_L2_request] tt1 inner join [dbo].[FE_SampleDesc] tt2
                                    on tt1.u_batchid = tt2.BatchID
                                    where tt1.[method] in {method_list_str}
                                    and tt1.requestitemstatus = 'Completed'
                                    and tt2.gradename = '{grade}'
                                    and tt2.Display01 = 'Yes'
                                )
                                select t1.[method], t1.[GradeName], t1.[SampleLegend], t1.[SampleSeq], t1.[BatchDesc],
                                t1.[MFGSite], t1.[MFGLine], t1.[CampaignID], t1.[LotID], t1.[SampleComment], 
                                t1.[requestid], t1.[u_batchid], t1.[createdt], t1.[u_accepteddt], t1.[moddt], 
                                t2.[paramid], t2.[displayvalue], t2.[displayunits]
                                from [dbo].[FE_BRPP_L2_result_scalar] t2 inner join t1
                                on t2.[datakeyid1] = t1.[datakeyid1]
                                where t2.[displayvalue] != 'Y'
                            """
                    pd_data_scalar = CACHE.exe_cloud_sql(command)

                    command = f"""
                                with t1 as (
                                    select tt1.[method], tt2.[GradeName], tt2.[SampleLegend01] as SampleLegend, tt2.[SampleSeq], 
                                    tt2.[BatchDesc], tt2.[MFGSite], tt2.[MFGLine], tt2.[CampaignID], tt2.[LotID], tt2.[SampleComment],
                                    tt1.[requestitemid], tt1.[requestid], tt1.[u_batchid], tt1.[createdt], tt1.[u_accepteddt], tt1.[moddt],
                                    tt1.[datakeyid1]
                                    from [dbo].[FE_BRPP_L2_request] tt1 inner join [dbo].[FE_SampleDesc] tt2
                                    on tt1.u_batchid = tt2.BatchID
                                    where tt1.[method] in {method_list_str}
                                    and tt1.method in ('SAOS', 'DMTA')
                                    and tt1.requestitemstatus = 'Completed'
                                    and tt2.gradename = '{grade}'
                                    and tt2.Display01 = 'Yes'
                                )
                                select t1.[method], t1.[GradeName], t1.[SampleLegend], t1.[SampleSeq], t1.[BatchDesc], 
                                t1.[MFGSite], t1.[MFGLine], t1.[CampaignID], t1.[LotID], t1.[SampleComment], 
                                t1.[requestitemid], t1.[requestid], t1.[u_batchid], t1.[createdt], t1.[u_accepteddt], t1.[moddt],
                                t2.[paramid], t2.[enteredvalue], t2.[enteredunits], t2.[attachmentclob]
                                from [dbo].[FE_BRPP_L2_result_array] t2 inner join t1
                                on t2.[datakeyid1] = t1.[datakeyid1]
                                where t2.[paramid] in ('Angular Frequency', 'Loss Modulus', 'Storage Modulus', 'Complex Viscosity', 
                                'Temperature', 'Tan(delta)')
                            """
                    data_array_filter = [
                        ['DMTA', 'Loss Modulus', False, True],
                        ['DMTA', 'Storage Modulus', False, True],
                        ['DMTA', 'Tan(delta)', False, True],
                        ['DMTA', 'Temperature', True, False],
                        ['SAOS', 'Angular Frequency', True, True],
                        ['SAOS', 'Complex Viscosity', False, True],
                        ['SAOS', 'Loss Modulus', False, True],
                        ['SAOS', 'Storage Modulus', False, True],
                    ]
                    pd_data_array_filter = pd.DataFrame(data=data_array_filter, columns=['Method', 'Item', 'X_Axis', 'LogScale'])
                    pd_data_array = CACHE.exe_cloud_sql(command)
                    pd_data_scalar = pd_data_scalar.rename(columns=dict_rename)
                    pd_data_array = pd_data_array.rename(columns=dict_rename)
                    pd_data_array = pd_data_array.merge(pd_data_array_filter, on=['Method', 'Item'], how='inner')
                    pd_data_scalar['Value'] = pd_data_scalar['Value'].astype(float)
                    for col in ['CreateTime', 'AcceptTime']:
                        pd_data_scalar[col] = pd_data_scalar[col].astype(str).str[:10]
                        pd_data_array[col] = pd_data_array[col].astype(str).str[:10]
                    pd_data_scalar['SampleLegend'] = pd_data_scalar['SampleLegend'].fillna('TBD')
                    pd_data_array['SampleLegend'] = pd_data_array['SampleLegend'].fillna('TBD')
                data_main_results = {'scalar': pd_data_scalar.to_dict('list'), 'array': pd_data_array.to_dict('list')}
            else:
                command = f"""
                select tt1.[method], tt2.[GradeName], tt2.[SampleLegend01] as SampleLegend, tt2.[SampleSeq], 
                tt2.[BatchDesc], tt2.[MFGSite], tt2.[MFGLine], tt2.[CampaignID], tt2.[LotID], tt2.[SampleComment], 
                tt1.[requestitemstatus], tt1.[requestitemid], tt1.[requestid], tt1.[u_batchid], 
                tt1.[createdt], tt1.[u_accepteddt], tt1.[moddt], tt1.[datakeyid1]
                from [dbo].[FE_BRPP_L2_request] tt1 inner join [dbo].[FE_SampleDesc] tt2
                on tt1.u_batchid = tt2.BatchID
                
                """
                pd_data = CACHE.exe_cloud_sql(command)

                pd_data = pd_data.rename(columns=dict_rename)
                data_main_submissions = {'submission': pd_data.to_dict('list')}

    return data_main_results, data_main_submissions


@app.callback([Output('fet_brpp_result_vis_sec_figure_array_dropdown_method', 'options'),
               Output('fet_brpp_result_vis_sec_figure_array_dropdown_measured_item', 'options'),
               Output('fet_brpp_result_vis_sec_figure_array_dropdown_measured_item', 'value')],
              [Input('fet_brpp_data_vis_memory_main_data_results', 'data'), Input('fet_brpp_result_vis_sec_figure_array_dropdown_method', 'value'),],
              [State('fet_brpp_result_vis_sec_figure_array_dropdown_measured_item', 'options'),
               State('fet_brpp_result_vis_sec_figure_array_dropdown_measured_item', 'value')]
              )
def update_vis_figure_array_dropdown(data_main_results, value_method, options_measured_item, value_measured_item):
    if 'array' not in data_main_results:
        return [], [], None
    else:
        pd_array = pd.DataFrame(data_main_results['array'])
        options_method = sorted(pd_array['Method'].unique())
        if value_method is None:
            return options_method, [], None
        else:
            pd_select = pd_array.loc[(pd_array['Method'] == value_method) & (~pd_array['X_Axis'])]
            options_measured_item = sorted(list(pd_select['Item'].unique()) + ['ALL'])
            if value_measured_item in options_measured_item:
                return options_method, options_measured_item, value_measured_item
            else:
                return options_method, options_measured_item, None


def get_submission_result(data_tabs_vis, data_main_submissions):
    """
    This function takes the data from the submission table and convert to user friendly format to view the progress of each sample vs measurements
    Args:
        data_tabs_vis (dict): tab selection for the visualization section
        data_main_submissions (dict): Input data for the submission progress. Data directly pulled from database.

    Returns:
        col_stack (str) : the tab name of the tab selection for the visualization section
        pd_base (pandas.dataframe): output cleaned up dataframe for display

    """
    col_stack = LIST_SUBMISSIONS_COLS[data_tabs_vis['vis']]
    pd_submit = pd.DataFrame(pd.DataFrame(data_main_submissions['submission']))
    cols_keep = ['GradeName', 'SampleLegend', 'SampleSeq', 'BatchDesc']
    cols_group = ['Method', 'GradeName', 'SampleLegend', 'SampleSeq', 'BatchDesc']

    col_id = 'RequestItemID'
    cols_stack = [col_stack]
    if 'Time' in col_stack:
        pd_submit[col_stack] = pd_submit[col_stack].fillna('NaT')
        pd_submit[col_stack] = pd_submit[col_stack].astype(str).str[:10]

    if col_stack == 'Num. of Completion':
        pd_submit_complete = pd_submit.loc[pd_submit['Status'] == 'Completed']
        pd_submit_stack = pd_submit_complete.groupby(cols_group).size().rename(col_stack).reset_index()
    elif col_stack == 'Num. of Submisison':
        pd_submit_stack = pd_submit.groupby(cols_group).size().rename(col_stack).reset_index()
    else:
        pd_submit_stack = pd_submit.copy()
        pd_num = pd_submit.groupby(['Method', 'BatchDesc']).size().rename('num')
        pd_num_rep = pd_num.loc[pd_num > 1].reset_index()
        pd_submit_rep = pd_submit.merge(pd_num_rep[['Method', 'BatchDesc']], on=['Method', 'BatchDesc'], how='inner')
        pd_submit_stack_1 = pd_submit_stack.loc[~pd_submit_stack[col_id].isin(list(pd_submit_rep[col_id]))].copy()
        pd_submit_stack_2_ori = pd_submit_stack.loc[pd_submit_stack[col_id].isin(list(pd_submit_rep[col_id]))]
        pd_submit_stack_2_data_list = []
        for i in range(len(pd_num_rep)):
            method, batchdesc = pd_num_rep.iloc[i][['Method', 'BatchDesc']]
            pd_submit_select = pd_submit_stack_2_ori.loc[
                (pd_submit_stack_2_ori['Method'] == method) & (pd_submit_stack_2_ori['BatchDesc'] == batchdesc)]
            data_stack = [', '.join(pd_submit_select[col]) for col in cols_stack]
            data_keep = list(pd_submit_select.iloc[0][cols_group])
            data_entry = data_keep + data_stack
            pd_submit_stack_2_data_list.append(data_entry)
        pd_submit_stack_2 = pd.DataFrame(data=pd_submit_stack_2_data_list, columns=cols_group + cols_stack)
        pd_submit_stack = pd.concat([pd_submit_stack_1, pd_submit_stack_2])

    pd_base = pd_submit[cols_keep].drop_duplicates()
    method_list = sorted(pd_submit_stack['Method'].unique())
    for method in method_list:
        pd_add = pd_submit_stack.loc[pd_submit_stack['Method'] == method]
        pd_base = pd_base.merge(pd_add[['BatchDesc', col_stack]], on='BatchDesc', how='left').rename(columns={col_stack: method})
    if col_stack in ['Num. of Completion', 'Num. of Submisison']:
        pd_base = pd_base.fillna(0)
        cols_int = [i for i in pd_base.columns if i not in cols_keep]
        pd_base[cols_int] = pd_base[cols_int].astype(int)
    elif col_stack in [i for i in LIST_SUBMISSIONS_COLS if i not in ['Num. of Completion', 'Num. of Submisison']]:
        pd_base = pd_base.fillna('')
    return col_stack, pd_base


@app.callback([Output('fet_brpp_div_main_display', 'children'),
               Output('fet_brpp_pop_up_window_data_unavailable', 'displayed'), Output('fet_brpp_pop_up_window_data_unavailable', 'message')],
              [Input('fet_brpp_data_vis_memory_main_data_results', 'data'), Input('fet_brpp_data_vis_memory_main_data_submissions', 'data'),
               Input('fet_brpp_data_vis_memory_tabs_filter', 'data'), Input('fet_brpp_data_vis_memory_tabs_vis', 'data'),
               Input('fet_brpp_result_vis_sec_figure_array_dropdown_method', 'value'),
               Input('fet_brpp_result_vis_sec_figure_array_dropdown_measured_item', 'value'),
               Input(f'{APPNAME}-search-dropdown-figure_hover_cols', 'value'),
               Input(f'{APPNAME}-search-dropdown-figure_sample_sort_col', 'value'),
               ],
              [State('fet_brpp_div_main_display', 'children'),
               ])
def update_main_display(data_main_results, data_main_submissions, data_tabs_filter, data_tabs_vis,
                        value_figure_array_method, value_figure_array_measured_item, cols_hover, col_sort, main_display):
    if ((data_tabs_filter is None) & (data_tabs_vis is None)) | ((data_tabs_filter == {}) & (data_tabs_vis == {})) | \
            ((data_main_results == {}) & (data_main_submissions == {})):
        main_display = html.H5('Please press "Query Data" to continue')
        return main_display, False, ''

    #cols_hover = ['BatchDesc', 'BatchID', 'RequestID', 'MFGSite', 'MFGLine', 'Value']
    #col_sort = 'LotID'

    if data_tabs_filter['filter'] == 0:
        data_main_select = data_main_results
        plot_type = dict_vis_tabs['Results'][data_tabs_vis['vis']]
        if 'scalar' not in data_main_select:
            main_display = html.H5('Please press "Query Data" to continue...')
            return main_display, False, ''
        if plot_type == 'Table (Scalars Only)':
            # Display scalar table
            pd_result = pd.DataFrame(data_main_select['scalar'])
            columns = [i for i in list(pd_result.columns) if i not in ['BatchDesc']]
            style_cell_conditional = [
                {'if': {'column_id': 'Unit'}, 'width': '45px', 'minWidth': '45px', 'maxWidth': '45px'},
                {'if': {'column_id': 'SampleSeq'}, 'width': '75px', 'minWidth': '75px', 'maxWidth': '75px'},
                {'if': {'column_id': 'SampleLegend'}, 'width': '95px', 'minWidth': '95px', 'maxWidth': '95px'},
                {'if': {'column_id': 'MFGSite'}, 'width': '70px', 'minWidth': '70px', 'maxWidth': '70px'},
                {'if': {'column_id': 'MFGLine'}, 'width': '70px', 'minWidth': '70px', 'maxWidth': '70px'},
                {'if': {'column_id': 'LotID'}, 'width': '90px', 'minWidth': '90px', 'maxWidth': '90px'},
                {'if': {'column_id': 'CampaignID'}, 'width': '85px', 'minWidth': '85px', 'maxWidth': '85px'},
                {'if': {'column_id': 'CreateTime'}, 'width': '85px', 'minWidth': '85px', 'maxWidth': '85px'},
                {'if': {'column_id': 'AcceptTime'}, 'width': '85px', 'minWidth': '85px', 'maxWidth': '85px'},
                {'if': {'column_id': 'Method'}, 'width': '135px', 'minWidth': '135px', 'maxWidth': '135px'},
                {'if': {'column_id': 'GradeName'}, 'width': '75px', 'minWidth': '75px', 'maxWidth': '75px'},
                {'if': {'column_id': 'RequestID'}, 'width': '100px', 'minWidth': '100px', 'maxWidth': '100px'},
                {'if': {'column_id': 'BatchID'}, 'width': '125px', 'minWidth': '125px', 'maxWidth': '125px'},
                {'if': {'column_id': 'Item'}, 'width': 'auto', 'minWidth': '135px'},
                {'if': {'column_id': 'SampleComment'}, 'width': '100px', 'minWidth': '100px'},

            ]
            main_display = html.Div(children=[
                dash_table.DataTable(
                    id='fet_brpp_main_table_submission',
                    columns=[{'name': columns[i], 'id': columns[i]} for i in range(len(columns))],
                    data=pd_result.to_dict('record'),
                    style_table={'padding-right': '5px', 'padding-left': '5px', 'margin-bottom': '5px',
                                 'width': '100%', 'height': '100%', 'overflow-y': 'scroll', 'overflow-x': 'scroll'},
                    style_cell={'whiteSpace': 'normal'},
                    style_header={'backgroundColor': 'rgb(210, 210, 210)', 'color': 'black', 'fontWeight': 'bold',
                                  'border': '1px solid black'},
                    style_cell_conditional=style_cell_conditional,
                    style_data={'border': '1px solid black'},
                    editable=True,
                    sort_action="native", filter_action='native',
                    sort_mode='multi',
                    page_current=0,
                    page_size=PAGE_SIZE,

                ),
            ])
        elif plot_type == 'Figure-Scalars':
            pd_result = pd.DataFrame(data_main_select['scalar'])
            # Display Scalar figure
            main_display_children = []
            pd_group = pd_result[['Method', 'GradeName', 'Item', 'Unit']].drop_duplicates().sort_values(by=['Method', 'Item'])

            _cols = [i for i in pd_result.columns if i not in ['Value']]
            pd_result[_cols] = pd_result[_cols].fillna('')
            pd_result = pd_result.sort_values(by=col_sort)

            for i in range(len(pd_group)):
                method, gradename, item, unit = pd_group.iloc[i]
                pd_plot = pd_result.loc[(pd_result['Method'] == method) & (pd_result['Item'] == item)]

                n_row, n_col = 1, 1
                title, ylabel = f'{gradename} - {method} - {item}', f'{item} ({unit})'
                fig = make_subplots(rows=n_row, cols=n_col, vertical_spacing=0.035, horizontal_spacing=0.05,
                                    y_title=ylabel, subplot_titles=[f"<b>{title}</b>"])
                pd_plot_control = pd_plot.loc[pd_plot['SampleLegend'] == 'Control']
                pd_plot_control = pd_plot_control.loc[~pd_plot_control['Value'].isna()]
                if len(pd_plot_control) >= 3:
                    y_sigma_p = smart_round(5)(pd_plot_control['Value'].mean() + 3 * pd_plot_control['Value'].std())
                    y_sigma_n = smart_round(5)(pd_plot_control['Value'].mean() - 3 * pd_plot_control['Value'].std())
                else:
                    y_sigma_p, y_sigma_n = np.nan, np.nan
                symbols = ['circle', 'square', 'diamond', 'cross', 'x', 'triangle-up', 'triangle-down', 'triangle-left', 'triangle-right']
                symbols = symbols * 5
                legend_list = sorted(pd_plot['SampleLegend'].unique())
                i_start = 0
                for i_legend, legend in enumerate(legend_list):
                    pd_plot_entry = pd_plot.loc[pd_plot['SampleLegend'] == legend]
                    points = list(pd_plot_entry['Value'])
                    x = np.arange(len(points)) + i_start

                    if 1 == 0:
                        hovertext = generate_hover_template_scalar(pd_plot, cols_hover)
                        hovertext = [f"<br>Batch Desc: {pd_plot_entry.iloc[i]['BatchDesc']}" \
                                     f"<br>Batch ID: {pd_plot_entry.iloc[i]['BatchID']}" \
                                     f"<br>Request ID: {pd_plot_entry.iloc[i]['RequestID']}" \
                                     f"<br>{points[i]} {unit}"
                                     for i in range(len(x))]

                    hovertext = [''.join([f"""<br>{DICT_HOVER_HEADER[col]}: {pd_plot_entry.iloc[i][col]}"""
                                          if col != 'Value' else
                                          f"""<br>{DICT_HOVER_HEADER[col]}: {pd_plot_entry.iloc[i][col]} {unit}"""
                                          for col in cols_hover])
                                 for i in range(len(x))]

                    fig.add_scatter(x=x, y=points, name=legend, showlegend=True, mode='markers', hoverinfo="text",
                                    hovertext=hovertext,
                                    marker={'size': 15, 'line': {'width': 1, 'color': 'DarkSlateGrey'}, 'symbol': symbols[i_legend]})
                    i_start += len(points)

                x_range = i_start
                xlim = [-0.05 * x_range, (1.05 * x_range - 1)]
                fig.update_layout(xaxis=dict(range=xlim))
                fig.layout.xaxis2 = go.layout.XAxis(overlaying='x', showticklabels=False, range=xlim)

                x_line = np.arange(i_start + 2) - 1
                hovertext_3sigma_p = [f'+3σ: {y_sigma_p} {unit} - {x_line[i]}' for i in range(len(x_line))]

                fig.add_scatter(x=x_line, y=[y_sigma_p] * len(x_line), mode='lines', xaxis='x2', name=r'+3σ', hoverinfo="text",
                                hovertext=hovertext_3sigma_p,
                                showlegend=True, line=dict(dash='dash', color="#636EFA", width=2))
                hovertext_3sigma_n = [f'-3σ: {y_sigma_n} {unit}'] * len(x_line)
                fig.add_scatter(x=x_line, y=[y_sigma_n] * len(x_line), mode='lines', xaxis='x2', name=r'-3σ', hoverinfo="text",
                                hovertext=hovertext_3sigma_n,
                                showlegend=True, line=dict(dash='dash', color="#636EFA", width=2))

                fig.update_xaxes(showticklabels=False)
                fig.update_layout(margin={'l': 100, 'r': 20, 't': 35, 'b': 35})

                graph_legend = dcc.Graph(className='w3-light-grey', figure=fig, style={'margin-bottom': '5px', 'height': '300px'})
                main_display_children.append(graph_legend)
            main_display = html.Div(main_display_children)
        elif plot_type == 'Figure-Arrays':
            pd_result = pd.DataFrame(data_main_select['array'])
            if len(pd_result) == 0:
                return 'No array data available', False, ''
            if value_figure_array_method is None:
                main_display = html.H5('Please press select "Method" to continue...')
            elif value_figure_array_measured_item is None:
                main_display = html.H5('Please press select "Measured Item" to continue...')
            elif len(value_figure_array_measured_item) == 0:
                main_display = html.H5('Please press select "Measured Item" to continue...')
            else:
                pd_array = pd_result.loc[(pd_result['Method'] == value_figure_array_method) & (~pd_result['X_Axis'])]
                pd_array_x = pd_result.loc[pd_result['X_Axis']]
                if 'ALL' not in value_figure_array_measured_item:
                    if type(value_figure_array_measured_item) is str:
                        value_figure_array_measured_item = [value_figure_array_measured_item]
                    pd_array = pd_array.loc[pd_array['Item'].isin(value_figure_array_measured_item)]
                item_list = sorted(pd_array['Item'].unique())
                item_x, unit_x = pd_array_x.iloc[0][['Item', 'Unit']]
                xlabel = f'{item_x} ({unit_x})'

                main_display_children_figure_array = []
                for i_item, item in enumerate(item_list):
                    pd_plot = pd_array.loc[pd_array['Item'] == item]
                    method, gradename, item, unit = pd_plot.iloc[i_item][['Method', 'GradeName', 'Item', 'Unit']]
                    unit = '' if unit == '-' else unit

                    n_row, n_col = 1, 1
                    title, ylabel = f'{gradename} - {method} - {item}', f'{item} ({unit})',

                    fig = make_subplots(rows=n_row, cols=n_col, vertical_spacing=0.035, horizontal_spacing=0.05,
                                        y_title=ylabel, x_title=xlabel,
                                        subplot_titles=[f"<b>{title}</b>"])

                    pd_legend = pd_plot[['SampleLegend', 'SampleSeq', 'RequestItemID']].drop_duplicates()
                    pd_legend = pd_legend.sort_values(by=['SampleLegend', 'SampleSeq'])
                    bool_log_y = pd_plot.iloc[0]['LogScale']
                    bool_log_x = pd_array_x.loc[pd_array_x['Method'] == method].iloc[0]['LogScale']

                    for i_legend in range(len(pd_legend)):

                        samplelegend, sampleseq = pd_legend.iloc[i_legend][['SampleLegend', 'SampleSeq']]
                        legend = f'{samplelegend}-{sampleseq}'
                        pd_plot_select = pd_plot.loc[(pd_plot['SampleLegend'] == samplelegend) & (pd_plot['SampleSeq'] == sampleseq)]

                        for i_entry in range(len(pd_plot_select)):
                            legend_show = legend if i_entry == 0 else f"{legend}-{i_entry}"
                            data_plot_raw_y, requestitemid, bool_log_y = pd_plot_select.iloc[i_entry][["ArrayValue", "RequestItemID", 'LogScale']]
                            data_split_y_list = data_plot_raw_y.split('"')
                            if 'value' != data_split_y_list[1]:
                                print("""ArrayValue column in array data does not follow the template of {"value": "..."}""")
                                print(pd_plot_select.iloc[[i_entry]])
                                raise PreventUpdate
                            data_plot_y = [float(i) for i in data_split_y_list[3].split(',')]

                            data_plot_raw_x, bool_log_x = pd_array_x.loc[pd_array_x['RequestItemID'] == requestitemid].iloc[0][['ArrayValue', 'LogScale']]
                            data_plot_x = [float(i) for i in data_plot_raw_x.split('"')[3].split(',')]

                            n_points = min(len(data_plot_x), len(data_plot_y))
                            data_plot_x, data_plot_y = data_plot_x[:n_points], data_plot_y[:n_points]
                            if 1 == 0:
                                batchdesc, batchid, requestid = pd_plot_select.iloc[i_entry][['BatchDesc', 'BatchID', 'RequestID']]
                                hovertext = [f"<br>Batch Desc: {batchdesc}" \
                                             f"<br>Batch ID: {batchid}" \
                                             f"<br>Request ID: {requestid}" \
                                             f"<br>{data_plot_x[i]}" \
                                             f"<br>{data_plot_y[i]} {unit}"
                                             for i in range(n_points)]

                            hovertext = [''.join([f"""<br>{DICT_HOVER_HEADER[col]}: {pd_plot_select.iloc[i_entry][col]}"""
                                                  if col != 'Value' else
                                                  f"<br>X Value: {data_plot_x[i]}"
                                                  f"<br>Y Value: {data_plot_y[i]} {unit}"
                                                  for col in cols_hover])
                                         for i in range(n_points)]

                            fig.add_scatter(x=data_plot_x, y=data_plot_y, name=legend_show, showlegend=True, mode='lines', hoverinfo="text",
                                            hovertext=hovertext,
                                            line=dict(color="#636EFA", width=2))

                    # fig.update_xaxes(showticklabels=False)
                    if bool_log_x:
                        fig.update_xaxes(type="log")
                    if bool_log_y:
                        fig.update_yaxes(type="log")
                    fig.update_layout(margin={'l': 100, 'r': 20, 't': 35, 'b': 55})

                    graph_legend = dcc.Graph(className='w3-light-grey', figure=fig, style={'margin-bottom': '5px', 'height': '300px'})
                    main_display_children_figure_array.append(graph_legend)
                main_display = html.Div(main_display_children_figure_array)

                #main_display = html.H5('In progress')

        else:
            print(f'Can not find the plot_type: "{plot_type}"')
            raise PreventUpdate
    else:
        if 'submission' not in data_main_submissions:
            main_display = html.H5('Please press "Query Data" to continue...')
            return main_display, False, ''
        col_stack, pd_base = get_submission_result(data_tabs_vis, data_main_submissions)

        if len(pd_base) > 0:
            pd_base = pd_base.sort_values(by=['BatchDesc'])
            pd_result = pd_base[[i for i in pd_base.columns if i not in ['BatchDesc']]]
            columns = list(pd_result.columns)
            style_cell_conditional = [{'if': {'column_id': 'Method'}, 'width': '135px', 'minWidth': '135px', 'maxWidth': '140px'}]
            if 'Time' in col_stack:
                for i in pd_result.columns:
                    if i != 'Method':
                        dict_condition = {'if': {'column_id': i}, 'width': '90px', 'minWidth': '90px', 'maxWidth': '120px'}
                        style_cell_conditional.append(dict_condition)

            main_display = html.Div(children=[
                dash_table.DataTable(
                    id='fet_brpp_main_table_submission',
                    columns=[{'name': columns[i], 'id': columns[i]} for i in range(len(columns))],
                    data=pd_result.to_dict('record'),
                    style_table={'padding-right': '5px', 'padding-left': '5px', 'margin-bottom': '5px',
                                 'width': '100%', 'height': '100%', 'overflow-y': 'scroll', 'overflow-x': 'scroll'},
                    style_cell={'whiteSpace': 'normal'},
                    style_header={'backgroundColor': 'rgb(210, 210, 210)', 'color': 'black', 'fontWeight': 'bold',
                                  'border': '1px solid black'},
                    style_cell_conditional=style_cell_conditional,
                    style_data={'border': '1px solid black'},
                    editable=True,
                    sort_action="native", filter_action='native',
                    sort_mode='multi',
                    page_current=0,
                    page_size=PAGE_SIZE,

                ),
            ])

    return main_display, False, ''
