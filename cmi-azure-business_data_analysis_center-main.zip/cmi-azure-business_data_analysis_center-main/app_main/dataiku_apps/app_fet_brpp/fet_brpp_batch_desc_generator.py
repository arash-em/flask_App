# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from dash import html, dcc, callback_context, dash_table
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dash.dependencies import Input, Output, State
import pandas as pd
import numpy as np
from math import floor, log10
import datetime
from dash.exceptions import PreventUpdate
from app_main.dataiku_apps.lib.main_lib import CACHE

app = CACHE.app

DROPDOWN_WIDTH = 350
PAGE_SIZE = 15
TAB_HEIGHT = '46px'
APPNAME = 'fet_brpp-batch_desc_generator'
APPNAME_ROLE_DB = 'fet_brpp'
SEARCH_WINDOW_WIDTH = 4

dict_content = {
    'search-tab': ['Execution'],
    'vis-tab': {'Execution': ['Display', 'Review'],},
}

IND_DISPLAY = '01'
DICT_TABLE_COLS = {
    'col1': ['User Email', 'Role', 'Created Time', 'Modified Time', 'Modified By'],
    'col2': []
}
COLS_NUMERIC = []
COLS_UNEDITABLE = ['User Email', 'Created Time', 'Modified Time', 'Modified By']
DICT_TABLE_OPTIONS = {
    'Role': ['Admin, Owner', 'Admin', 'Remove'],
}
DICT_RENAME = {'email': 'User Email', 'role': 'Role', 'moddt': 'Modified Time', 'createdt': 'Created Time', 'modby': 'Modified By'}
DICT_RENAME_REVERSE = {DICT_RENAME[i]: i for i in DICT_RENAME}
COLOR_RED = '#ff8000'
# ---------------------------------------------------------------------

tab_pad_top, tab_pad_bottom = 13, 13
tab_style = {'padding-top': f'{tab_pad_top}px', 'padding-bottom': f'{tab_pad_bottom}px'}
tab_classname_default = 'w3-bar-item w3-button w3-mobile'
tab_classname_highlight = 'w3-bar-item w3-button w3-red w3-mobile'

search_tabs = dict_content['search-tab']
div_search_tabs = html.Div(
    children=[
                 html.A(className=tab_classname_highlight, children=search_tabs[0], id=f'{APPNAME}-search-tab-0', style=tab_style),
             ] + [
                 html.A(className=tab_classname_default, children=search_tabs[i + 1], id=f'{APPNAME}-search-tab-{i + 1}', style=tab_style)
                 for i in range(len(search_tabs) - 1)
             ],
    id=f'{APPNAME}-search-tabs', className='w3-white',
    style={'margin-top': '0px', 'padding-left': '0px', 'margin-right': '10px', 'margin-left': '10px'}
)


search_tab_0 = dict_content['search-tab'][0]
vis_tabs = dict_content['vis-tab'][search_tab_0]
div_vis_tabs = html.Div(
    children=[
                 html.A(className=tab_classname_highlight, children=vis_tabs[0], id=f'{APPNAME}-vis-tab-0', style=tab_style),
             ] + [
                 html.A(className=tab_classname_default, children=vis_tabs[i + 1], id=f'{APPNAME}-vis-tab-{i + 1}', style=tab_style)
                 for i in range(len(vis_tabs) - 1)
             ],
    id=f'{APPNAME}-tab_vis', className='w3-bar w3-white',
    style={'margin-top': '0px', 'padding-left': '0px'}
)

DICT_SETUP = {
    'Grade Name *': ['dropdown',
                   ['AP0B3', 'AXO3BE3', 'PP2252E1', 'PP7032E3', 'PP7032KN', 'PP7033E3', 'PP7143KNE1', 'PP7414', 'PP7684KNE1', 'PP7694E2']],
    'Batch Legend *': ['dropdown', ['Control', 'Test']],
    'MFG Site *': ['dropdown', ['Control', 'Test']],
    'MFG Line *': ['dropdown', ['L1', 'L4', 'L8']],
    'CampaignID': ['input', 'number'],
    'Sample sequence *': ['input', 'number'],
    'LotID *': ['input', 'text'],
    'Special Comment': ['input', 'text'],
    'Sample Sub-Sequence': ['input', 'number'],
}

div_search_buttons_list = []
width_component = '50%'
height_component = 34
for i_item, item in enumerate(DICT_SETUP):
    component_type = DICT_SETUP[item][0]
    if component_type == 'dropdown':
        component = html.Div([
            html.B(item),
            dcc.Dropdown(
                options=sorted(DICT_SETUP[item][1]),
                id=f'{APPNAME}-search_buttons-info-{i_item}',
                style={'margin-bottom': '10px', 'width': '100%', 'height': height_component}, multi=False
            )
        ], style={'width': width_component, 'margin-right': '5px'})
    else:
        if DICT_SETUP[item][1] == 'number':
            component = html.Div([
                html.B(item),
                html.Div(
                    dcc.Input(
                        id=f'{APPNAME}-search_buttons-info-{i_item}',
                        type=DICT_SETUP[item][1],
                        inputMode=DICT_SETUP[item][1],
                        style={'margin-bottom': '10px', 'height': height_component, 'width': '100%'},
                        debounce=False,
                        min=1,
                        step=1,
                    )
                )
            ], style={'width': width_component, 'margin-right': '5px'})
        else:
            component = html.Div([
                html.B(item),
                html.Div(
                    dcc.Input(
                        id=f'{APPNAME}-search_buttons-info-{i_item}',
                        type=DICT_SETUP[item][1],
                        inputMode=DICT_SETUP[item][1],
                        style={'margin-bottom': '10px', 'height': height_component, 'width': '100%'},
                        debounce=False
                    )
                )
            ], style={'width': width_component, 'margin-right': '5px'})
    div_search_buttons_list.append(component)

div_search_buttons_children, temp_list = [], []
for i, component in enumerate(div_search_buttons_list):
    if i % 2 == 0:
        temp_list = [component]
    else:
        temp_list.append(component)
        div_search_buttons_children.append(html.Div(temp_list, style={'display': 'flex', 'width': '100%'}))
if len(temp_list) > 0:
    div_search_buttons_children.append(html.Div(temp_list, style={'display': 'flex', 'width': '100%'}))

print()
div_search_buttons = html.Div(
    children=div_search_buttons_children,
    style={'padding-left': '15px', 'padding-right': '15px', 'margin-top': '10px', 'width': '100%'}
)


div_vis_buttons = dcc.Loading(children=html.Div(children=[]))

div_query_display_switch = html.Button(
    children=[
        html.A(className='far fa-eye-slash', id=f'{APPNAME}-search-display_switch_icon'),
        html.A(' Hide queries', id=f'{APPNAME}-search-display_switch_text'),
    ],
    style={'width': '150px', 'height': TAB_HEIGHT, 'margin-right': '10px'},
    id=f'{APPNAME}-search-display_switch')



div_main_display = html.Div(
    id=f'{APPNAME}-div_main_display',
    children=[
        html.B('Final Batch Description'),
        html.Div(
            dcc.Input(
                disabled=True,
                id=f'{APPNAME}-vis_content-final_batch_description',
                style={'height': height_component, 'margin-bottom': '10px', 'width': '70%'}
            )
        ),

        html.B('Copy to Clipboard'),
        dcc.Clipboard(id=f'{APPNAME}-vis_content-clipboard', style={"fontSize": 30}),
    ],
    style={'margin-top': '10px'}
)

div_main = html.Div([
    dcc.Store(id=f'{APPNAME}_data_vis_memory_page', storage_type='memory', data={}),
    dcc.Store(id=f'{APPNAME}_data_vis_memory_data', storage_type='memory'),
    dcc.Store(f'{APPNAME}-Store-search_tab', storage_type='memory', data={'ind': 0}),
    dcc.Store(f'{APPNAME}-Store-vis_tab', storage_type='memory', data={'ind': 0}),
    dcc.Store(id=f'{APPNAME}_data_vis_memory_individual_selection', storage_type='memory'),
    dcc.Store(id=f'{APPNAME}_data_vis_memory_tabs_filter', storage_type='memory',
              data={'filter': 0, 'trigger': False}),
    dcc.Store(id=f'{APPNAME}_data_vis_memory_tabs_vis', storage_type='memory', data={'vis': 0}),
    dcc.ConfirmDialog(id=f'{APPNAME}-pop_up_window-user_not_admin', message=''),
    html.Div(id=f'{APPNAME}_data_vis_div_null'),
    html.Div([
        html.Div(
            id=f'{APPNAME}-query_filter',
            className=f'w3-col s{SEARCH_WINDOW_WIDTH}',
            children=[
                html.Div(children=[
                    div_search_tabs,
                    div_search_buttons,
                ]),
                dcc.Loading(
                    id=f'{APPNAME}_loading_main_data',
                    children=[
                        dcc.Store(id=f'{APPNAME}-memory-vis-display-data', storage_type='memory', data={}),
                        dcc.Store(id=f'{APPNAME}-memory-vis-review-data', storage_type='memory', data={}),
                        dcc.Store(id=f'{APPNAME}-memory-vis-compare-data', storage_type='memory', data={}),
                    ],
                ),
            ], style={'border-right': '8px solid #ffffff'}
        ),
        html.Div(
            id=f'{APPNAME}-main_display',
            className=f'w3-col s{12-SEARCH_WINDOW_WIDTH}',
            children=[
                html.Div([
                    div_query_display_switch,
                    div_vis_tabs,
                ], style={'display': 'flex'}),
                div_vis_buttons,
                div_main_display,
        ], style={'padding-left': '10px'}),

    ], className='w3-row'),
], style={'fontSize': 13})

input_list = [Input(f'{APPNAME}-search_buttons-info-{i_item}', 'value') for i_item in range(len(DICT_SETUP))]
@app.callback(Output(f'{APPNAME}-vis_content-final_batch_description', 'value'), input_list)
def update_final_batch_desc(*args):
    value_list = [str(i) if i is not None else '' for i in args]
    key_list = list(DICT_SETUP.keys())
    output = '-'.join(value_list)
    return output


@app.callback(Output(f'{APPNAME}-vis_content-clipboard', 'content'),
              Input(f'{APPNAME}-vis_content-clipboard', 'n_clicks'),
              State(f'{APPNAME}-vis_content-final_batch_description', 'value'),)
def copy_to_clipboard(_1, batch_desc):
    print(_1, batch_desc)
    if _1 is not None:
        return batch_desc, 1
    else:
        raise PreventUpdate