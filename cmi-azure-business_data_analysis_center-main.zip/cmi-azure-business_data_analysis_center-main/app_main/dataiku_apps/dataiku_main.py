# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

import dash
from dash import html, dcc
from dash.dependencies import Input, Output, State
import plotly.graph_objects as go
import pandas as pd
import sqlite3, time, base64, datetime
from plotly.subplots import make_subplots

from .lib.main_lib import CACHE, LABEL_SYSTEM
from .app_shared import main_shared

app_dash = CACHE.app
DIR = CACHE.DIR
BGCOLOR = '#f2f2f2'
APPNAME = 'bizcenter'
dict_image = CACHE.dict_image

dict_page_display_bool_table = {
    '3d_print': True,
    'fet': False,
    'fet_brpp': True,
    'sales_vis': False,
    'cadi': True,
    'mat_db': True,

}

dict_page_display = {
    '3d_print':
        html.Div(id='dataiku_main-link-3d_print', className='w3-quarter', children=[
            html.Div(className='w3-card-2', children=[
                dcc.Link(id='link_to_3d_printing', href='page-3d_printing', children=[
                    html.H3('3D Printing Hub', className='main-page-item-title'),
                    html.Div(className='center-content main-page-item-content w3-white', children=[
                        html.Img(src=dict_image['main_page-Axiom_3d_printing'], style={'width': '100%'})
                    ]),
                ])
            ])
        ]),
    'fet':
        html.Div(className='w3-quarter', children=[
            html.Div(id='dataiku_main-link-fet', className='w3-card-2', children=[
                dcc.Link(id='link_to_fet', href='page-fet', children=[
                    html.H3('Function Eq. Tool', className='main-page-item-title'),
                    html.Div(className='center-content main-page-item-content w3-white', children=[
                        html.Img(src=dict_image['main_page-fet'], style={'width': '100%'})
                    ]),
                ])
            ])
        ]),
    'fet_brpp':
        html.Div(className='w3-quarter', children=[
            html.Div(id='dataiku_main-link-fet_brpp', className='w3-card-2', children=[
                dcc.Link(id='link_to_fet_brpp', href='page-fet-brpp', children=[
                    html.H3('Function Eq. Tool-BRPO', className='main-page-item-title'),
                    html.Div(className='center-content main-page-item-content w3-white', children=[
                        html.Img(src=dict_image['main_page-fet'], style={'width': '100%'})
                    ]),
                ])
            ])
        ]),
    'sales_vis':
        html.Div(className='w3-quarter', children=[
            html.Div(id='dataiku_main-link-sales_vis', className='w3-card-2', children=[
                dcc.Link(id='link_to_sales_vis', href='page-sales_vis', children=[
                    html.H3('Chemical Sales Vis', className='main-page-item-title'),
                    html.Div(className='center-content main-page-item-content w3-white', children=[
                        html.Img(src=dict_image['main_page-sales_vis'], style={'width': '100%'})
                    ]),
                ])
            ])
        ]),
    'cadi':
        html.Div(className='w3-quarter', children=[
            html.Div(id='dataiku_main-link-cadi', className='w3-card-2', children=[
                dcc.Link(id='link_to_cadi', href='page-cadi', children=[
                    html.H3('CAD Information', className='main-page-item-title'),
                    html.Div(className='center-content main-page-item-content w3-white', children=[
                        html.Img(src=dict_image['main_page-cadi'], style={'width': '65%'})
                    ]),
                ])
            ])
        ]),
    'mat_db':
        html.Div(className='w3-quarter main-page-item', children=[
            html.Div(id='dataiku_main-link-matdb', className='w3-card-2', children=[
                html.A(href='https://goto/matdb', target='_blank', children=[
                    html.H3('MatDB', className='main-page-item-title'),
                    html.Div(className='center-content main-page-item-content w3-white', children=[
                        html.Img(src=dict_image['main_page-matdb'], style={'width': '100%'})
                    ]),
                ])
            ])
        ]),
}

page_table_list = [dict_page_display[i] for i in dict_page_display_bool_table if dict_page_display_bool_table[i]]



main_page = html.Div([
    html.Div([
        html.Div(id='dataiku_main_div_null')
    ]),
    html.Div(className="w3-bar w3-top w3-black w3-large", style={'z-index': '6'}, children=[
        html.Div(className='w3-bar-item', children=[
            html.Div([html.I(className='fas fa-home '), ' Main page'], style={'font-family': CACHE.font})
        ]),
        html.Div(children=f'', id='visitor_count',
                 className='w3-bar-item w3-right', style={'font-family': CACHE.font})
    ]),
    html.Div([
        html.Header(children=[
            html.H5(id='page_content_title', style={'text-align': 'left'}),
        html.Header(children=[
            html.B('Business Data Analysis Center',
                   style={'margin-left': '5px', 'font-size': '20px', 'border-right': '1px solid #939596',
                          'padding-right': '10px', 'margin-right': '10px', 'padding-top': '10px',
                          'padding-bottom': '10px'}),
            html.A(
                [
                    html.Img(src=dict_image['matdb-logo-1x'],
                         style={'text-align': 'right', 'margin-right': '5px', 'height': '50px'}),
                    html.B('MATDB', style={'font-size': '20px', 'color': '#f45721'})
                ],
                href="http://goto/matdb", target="_blank",
            ),

            ], style={'flex-grow': '3', 'text-align': 'right'}),
        ], style={'padding-top': '5px', 'padding-bottom': '5px',
                  'display': 'flex', 'justify-content': 'space-between'}),
    ], className='w3-container w3-bar', style={'margin-top': '43px', 'padding-left': '295px', 'background-color': BGCOLOR}),

    html.Div(
        children=[
            html.Div(style={'background-image': f"url({dict_image['main_page-chemical_site']})", 'height': 'auto',  'background-size': '100% 100%',
                            'object-fit': 'scale-down', 'aspect-ratio': "19/4"},
                     children=[
                         html.H1(html.B('Accelerating Data Analysis for Business', style={'color': 'white', 'font-size': '150%'}),
                                 style={"position": "absolute", "top": "30%", "left": "0%", "transform": "translate(10%, -50%)"},
                                 ),

                         dcc.Link(
                             id='link_to_fet', href='https://goto/matdb', target='_blank',
                             children=html.H5(html.B('-- Powered by MatDB',
                                                     style={'color': 'white', 'font-size': '100%'})),
                             style={"position": "absolute", "top": "60%", "left": "7%"}),
                         dcc.Link(
                             id='link_to_fet', href='https://goto/matdb', target='_blank',
                             children=html.H5(html.B('-- Funded by Foundation for Global Data Integration (FGDI) Project',
                                                     style={'color': 'white', 'font-size': '100%'})),
                             style={"position": "absolute", "top": "70%", "left": "7%"}),

                         dcc.Link(
                             id='link_to_fet', href='https://goto/cmi', target='_blank',
                             children=html.H5(html.B('-- Created by Chemical Modeling and Informatics (CMI) Team ',
                                        style={'color': 'white', 'font-size': '100%'})),
                             style={"position": "absolute", "top": "80%", "left": "7%"}),
                     ]),
        ], className='content-wrapper w3-container w3-center'),
    html.Div(children=[
        html.Div(className='w3-row-padding w3-margin-top', children=page_table_list),
        html.Div(className='w3-row-padding w3-margin-top', style={'margin-left': '8px', 'margin-right': '8px'}, children=[
            dcc.Graph(id='main_user_activity_viewer', style={'height': '300px'}),
        ]),
    ], className='content-wrapper w3-container w3-center'),

    html.Footer(f'Copyright © ExxonMobil Chemical Company {str(datetime.datetime.now())[:4]}', className='sticky-footer')

],
    style={'font-family': CACHE.font, 'background-color': BGCOLOR, 'height': '100%', 'width': '100%', 'background-size': 'cover',
           'background-position': 'center', 'background-repeat': 'no-repeat', 'padding-bottom': '10px'},
    className='w3-light-grey',
)

@app_dash.callback(Output('main_user_activity_viewer', 'figure'),
              Input('dataiku_main_div_null', 'n_clicks'),
              State('root_memory_global', 'data')
              )
def update_graph_main_vis(_a, data_input):

    if data_input is None:
        pd_visit = CACHE.get_visit_info()
    else:
        pd_visit = pd.DataFrame(data_input['pd_visit'])

    fig = make_subplots(rows=1, cols=1, vertical_spacing=0.075, horizontal_spacing=0.125,
                        subplot_titles=["User Visitor Trend"])
    pd_visit['date'] = pd.to_datetime(pd_visit['time'].str[:11])

    pd_visit_show = pd_visit.groupby('date').size().rename('num').reset_index()
    pd_values = pd_visit_show.values
    hovertext = [f"Date: {str(pd_values[i][0])[:11]}<br>Count: {str(pd_values[i][1])}" for i in range(len(pd_visit_show))]
    fig.add_trace(
        go.Bar(x=pd_visit_show['date'], y=pd_visit_show['num'], name=r'Visitor Count', hoverinfo="text",
               hovertext=hovertext)
    )
    fig.update_layout(xaxis_title='Date')
    fig.update_layout(yaxis_title='Vistors / Day')
    fig.update_layout(margin={'l': 40, 'r': 40, 't': 30, 'b': 20})
    return fig
