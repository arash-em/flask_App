# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

import datetime
from dash import html, dcc, callback_context, dash_table
from dash.exceptions import PreventUpdate
import plotly.graph_objects as go
from dash.dependencies import Input, Output, State
import pandas as pd
import numpy as np
import plotly.express as px
from math import floor, log10

from app_main.dataiku_apps.lib.main_lib import CACHE, get_date
#from dataiku_apps.lib.main_lib import CACHE

app = CACHE.app

DROPDOWN_WIDTH = 350
PAGE_SIZE = 25
GRAPHS_PER_ROW = 2
MAX_GRAPHS = 12
MAX_COLOR_GROUPS = 5
METRIC_VALUE = 'Volume'
GROUP_GRAPH_COL, GROUP_COLOR_COL, GROUP_X_COL = 'Business unit', 'Customer segment', 'Month'
CONTROL_ITEM_SEP = '15px'
GRAPH_HEIGHT = '450'
QUERY_LIMIT = 65000
TAB_HEIGHT = '46px'
UNITFY_COLOR_THRESHOLD = len(px.colors.qualitative.Plotly)

bool_test = False
bool_test_data = False
if bool_test_data:
    pd_sa_agg = pd.read_csv('pd_sa_agg.csv')
    pd_sa_agg['AgiMonth'] = pd.to_datetime(pd_sa_agg['AgiMonth'])

def smart_round(sig):
    def rounder(x):
        offset = sig - floor(log10(abs(x)))
        initial_result = round(x, offset)
        if str(initial_result)[-1] == '5' and initial_result == x:
            return round(x, offset - 2)
        else:
            return round(x, offset - 1)
    return rounder


def get_month_start_end(_date_start, _date_end, _format='datetime'):
    def check_day(date_input):
        return date_input if len(date_input) < 10 else f'{date_input}-15'

    def check_month(date_input):
        info_list = date_input.split('-')
        info_list[1] = info_list[1] if len(info_list[1]) == 2 else f'0{info_list[1]}'
        return '-'.join(info_list)

    _date_start = check_day(check_month(_date_start))
    _date_end = check_day(check_month(_date_end))

    _date_month_end = datetime.datetime.fromisoformat(_date_end).replace(day=1) + datetime.timedelta(days=45)
    _date_month_end = _date_month_end.replace(day=1) - datetime.timedelta(days=1)
    _date_month_start = datetime.datetime.fromisoformat(_date_start).replace(day=1)
    if _format == 'str':
        return str(_date_month_start)[:10], str(_date_month_end)[:10]
    else:
        return _date_month_start, _date_month_end


CACHE.dict_activity_store['tab_main_material_visual'] = 'button_combined_spider_chart'

dict_filters_1 = {'Business unit': 'BusinessUnit', 'Region': 'ShipToRegion', 'Country': 'ShipToCountry',  'City': 'ShipToCity',
                  'Customer segment': 'CustomerSegment', 'Customer': 'Customer', 'Product': 'FinishedProduct',
                  'Industry': 'Industry', 'Market segment': 'MarketSegment'}

tab_pad_top, tab_pad_bottom = 14, 0
tab_style = {'padding-top': f'{tab_pad_top}px', 'padding-bottom': f'{tab_pad_bottom}px', 'height': TAB_HEIGHT}
tab_classname_default = 'w3-bar-item w3-button w3-mobile'
tab_classname_highlight = 'w3-bar-item w3-button w3-red w3-mobile'
div_data_visualization_tabs = html.Div(
    children=[
        html.A(id='sales_vis_tab_vis_0', children=["Data table"], style=tab_style, className=tab_classname_highlight),
        html.A(id='sales_vis_tab_vis_1', children=['visualization'], style=tab_style, className=tab_classname_default),
        html.A(id='sales_vis_tab_vis_2', children=['TBD'], style=tab_style, className=tab_classname_default),
    ],
    className='w3-bar w3-white',
    style={'margin-top': '0px', 'padding-left': '0px', 'margin-bottom': '5px'}
)

dict_div_filters = {}
for key_filter in dict_filters_1:
    dict_div_filters[key_filter] = html.Div([
        html.Div([
            key_filter,
            html.Button('Clear',
                        id=f'sales_vis_button_clear_{dict_filters_1[key_filter]}',
                        style={'margin-right': '15px'},
                        className='w3-right')
        ], style={'width': '100%'}),
        dcc.Checklist(
            options=[],
            labelStyle={'display': 'block', },
            inputStyle={"margin-right": "3px"},
            inline=False,
            labelClassName='Xchecklist',
            style={'height': '150px', 'width': '100%',
                   'overflow-y': 'scroll', 'background-color': 'white', 'hover-background-color': '#555555'},
            id=f'sales_vis_filter_{dict_filters_1[key_filter]}'
        )
    ], className='w3-col s6 w3-light-grey', style={'height': '150px', 'width': '50%', 'display': 'flex'}
    )

dict_div_filters_front = html.Div([
    html.Div(children=[
        html.Div(children=[
            html.Div([
                html.A('Start month', style={'padding-right': '5px'}),
                dcc.Input(placeholder='2021-05', id='sales_vis_date_start',
                          style={'width': '75px', 'height': '25px'}),
            ]),
            html.Div([
                html.A('End month', style={'padding-right': '9px'}),
                dcc.Input(placeholder='2022-04', id='sales_vis_date_end',
                          style={'width': '75px', 'height': '25px'})
            ]),
            ], className='w3-col s6 w3-light-grey', style={'width': '40%', 'display': 'block'}),

        html.Div(children=[
            html.Div(children=[
                html.Button('Refresh filters', id='sales_vis_button_refresh',
                            style={'height': TAB_HEIGHT, 'width': '70px'}),
                html.Button('Query data', id='sales_vis_button_query_data',
                            style={'height': TAB_HEIGHT, 'margin-left': '5px', 'width': '70px'}),
            #    html.Button('Save search', id='sales_vis_button_bookmark_search',
            #                style={'height': TAB_HEIGHT, 'margin-left': '5px', 'width': '70px'})

            ],
                style={'padding-left': '20px'}
            ),
        ], className='w3-col s6 w3-light-grey', style={'width': '60%', })
    ], className='w3-light-grey w3-row'),

    #html.Div(
    #    children=[
    #        html.A(id='sales_vis_tab_filter_1', children=["Basic"], style=tab_style, className=tab_classname_highlight),
    #        html.A(id='sales_vis_tab_filter_2', children=['Advanced'], style=tab_style, className=tab_classname_default),
    #        html.A(id='sales_vis_tab_filter_3', children=['Saved'], style=tab_style, className=tab_classname_default),
    #    ],
    #    className='w3-bar w3-white',
    #    style={'margin-top': '5px', 'padding-left': '0px', 'margin-bottom': '5px'})

], style={'margin-bottom': '10px', 'padding-left': '12px', 'margin-right': '12px'})

n_col_filter = 2
n_row_filter = int(np.ceil(len(dict_div_filters) / n_col_filter))
dict_div_filters_keys = list(dict_div_filters.keys())
div_data_vis_filters_children = [
    dict_div_filters_front
]

for row in range(n_row_filter):
    filters = dict_div_filters_keys[(row * n_col_filter): ((1 + row) * n_col_filter)]

    padding_top, padding_bottom = '5px', '5px'
    if row == 0:
        padding_top = '0px'
    if row == (n_row_filter - 1):
        padding_bottom = '0px'
    div_split = html.Div(
        children=[], className='w3-light-grey w3-row',
        style={'padding-left': '15px', 'padding-right': '15px', 'padding-top': padding_top, 'padding-bottom': padding_bottom})

    for col, filter in enumerate(filters):
        padding_left, padding_right = '5px', '5px'
        if col == 0:
            padding_left = '0px'
        if col == (n_col_filter - 1):
            padding_right = '0px'
        dict_div_filters[filter].style = {'padding-left': padding_left, 'padding-right': padding_right}
        div_split.children.append(dict_div_filters[filter])
    div_data_vis_filters_children.append(div_split)

div_data_visualization_filters = html.Div(
    children=[
        html.Div(children=div_data_vis_filters_children,
                 className='w3-light-grey',
                 style={'padding-left': '0px', 'padding-right': '5px'}),
    ])

_column_names = ['Business unit', 'Region', 'Country', 'City', 'Customer segment', 'Customer', 'Product', 'Industry', 'Market segment',
                 'End use', 'Volume', 'Sales', 'Month'
                 ]
_column_ids = ['businessunit', 'region', 'country', 'city', 'customersegment', 'customer', 'product',
               'industry', 'marketsegment', 'enduse', 'volume', 'sales', 'month']
_column_ids_query = ['BusinessUnit', 'ShipToRegion', 'ShipToCountry', 'ShipToCity', 'CustomerSegment', 'Customer',
                     'FinishedProduct', 'Industry', 'MarketSegment', 'EndUse', 'Volume', 'Sales', 'AgiMonth', 'CustomerCode']

div_query_display_switch = html.Button(
    children=[
        html.A(className='far fa-eye-slash', id='sales_vis_query_display_switch_icon'),
        html.A(' Hide queries', id='sales_vis_query_display_switch_text'),
    ],
    style={'width': '125px', 'height': TAB_HEIGHT, 'margin-right': '5px'},
    id='sales_vis_query_display_switch')

div_main_vis = html.Div(id='sales_vis_main_vis', children=[
    html.Div([
        html.Div(children=[
            html.Div('Graphs per row'),
            dcc.Input(placeholder=str(GRAPHS_PER_ROW), id='sales_vis_vis_graphs_per_row', style={'width': '75px', 'height': '35px'})
        ], style={'margin-left': '5px'}),

        html.Div(children=[
            html.Div('Max graphs'),
            dcc.Input(placeholder=str(MAX_GRAPHS), id='sales_vis_vis_max_graphs', style={'width': '75px', 'height': '35px'})
        ], style={'margin-left': CONTROL_ITEM_SEP}),

        html.Div(children=[
            html.Div('Graph height'),
            dcc.Input(placeholder=str(GRAPH_HEIGHT), id='sales_vis_vis_graph_height', style={'width': '75px', 'height': '35px'})
        ], style={'margin-left': CONTROL_ITEM_SEP}),

        html.Div(children=[
            html.Div('Max colors'),
            dcc.Input(placeholder=str(MAX_COLOR_GROUPS), id='sales_vis_vis_max_color_groups', style={'width': '75px', 'height': '35px'})
        ], style={'margin-left': CONTROL_ITEM_SEP}),

        html.Div(children=[
            html.Div('Plot type'),
            dcc.Dropdown(['Scatter', 'Stacked bar'], 'Scatter', id='sales_vis_vis_plot_type', clearable=False, style={'width': '130px'})
        ], style={'margin-left': CONTROL_ITEM_SEP}),

    ], className='w3-row w3-light-grey', style={'display': 'flex', 'margin-bottom': '5px'}),

    html.Div([
        html.Div(children=[
            html.Div('Metric value'),
            dcc.Dropdown(['Volume', 'Sales'], 'Volume', id='sales_vis_vis_metric', clearable=False, style={'width': '85px'})
        ], style={'margin-left': '5px'}),

        html.Div(children=[
            html.Div('Figure grouped column'),
            dcc.Dropdown(_column_names, GROUP_GRAPH_COL, id='sales_vis_vis_figure_group_col', clearable=False, style={'width': '165px'})
        ], style={'margin-left': CONTROL_ITEM_SEP}),

        html.Div(children=[
            html.Div('Color grouped column'),
            dcc.Dropdown(['None'] + _column_names, GROUP_COLOR_COL, id='sales_vis_vis_color_group_col', clearable=False,
                         style={'width': '165px'})
        ], style={'margin-left': CONTROL_ITEM_SEP}),

        html.Div(children=[
            html.Div('X grouped column'),
            dcc.Dropdown(_column_names, GROUP_X_COL, id='sales_vis_vis_x_group_col', clearable=False, style={'width': '165px'})
        ], style={'margin-left': CONTROL_ITEM_SEP}),


        html.Div(children=[
            html.Br(),
            html.Button('Draw', id='sales_vis_vis_button_draw_graph', style={'height': '35px'})
        ], style={'margin-left': CONTROL_ITEM_SEP}),
    ], className='w3-row w3-light-grey', style={'display': 'flex', 'margin-bottom': '5px'}),

    html.Div(id='sales_vis_main_vis_content', style={'width': '100%'})
], style={'display': 'block' if bool_test else 'none'})


@app.callback([Output('sales_vis_query_filter', 'style'), Output('sales_vis_main_display', 'className'),
               Output('sales_vis_query_display_switch_icon', 'className'), Output('sales_vis_query_display_switch_text', 'children'),
               Input('sales_vis_query_display_switch', 'n_clicks')])
def update_query_display_show_hide(_a):
    if _a is None:
        raise PreventUpdate
    if _a % 2 == 1:
        sales_vis_query_display_switch_icon_classname = 'far fa-eye'
        sales_vis_query_display_switch_text = ' Hide queries'
        sales_vis_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'none'}
        sales_vis_main_display_classname = 'w3-col'
    else:
        sales_vis_query_display_switch_icon_classname = 'far fa-eye-slash'
        sales_vis_query_display_switch_text = ' Hide queries'
        sales_vis_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'block'}
        sales_vis_main_display_classname = 'w3-col s8'
    output = [sales_vis_query_filter_style, sales_vis_main_display_classname, sales_vis_query_display_switch_icon_classname,
              sales_vis_query_display_switch_text]
    return output


@app.callback([Output('sales_vis_main_vis_content', 'children'),
               Input('sales_vis_tab_vis_1', 'n_clicks'), Input('sales_vis_vis_button_draw_graph', 'n_clicks'),
               Input('sales_vis_main_table_content', 'derived_virtual_data'),
               State('sales_vis_vis_graphs_per_row', 'value'), State('sales_vis_vis_max_graphs', 'value'),
               State('sales_vis_vis_graph_height', 'value'),
               State('sales_vis_vis_max_color_groups', 'value'), State('sales_vis_vis_plot_type', 'value'),
               State('sales_vis_vis_metric', 'value'), State('sales_vis_vis_figure_group_col', 'value'),
               State('sales_vis_vis_color_group_col', 'value'), State('sales_vis_vis_x_group_col', 'value'),])
def draw_main_graph_content(_a, _b, data, n_graph_x, n_graph_max, graph_height, n_color_max, graph_type, col_metric, group_col_graph,
                            group_col_color, group_col_x):
    n_graph_x = GRAPHS_PER_ROW if n_graph_x is None else int(n_graph_x)
    n_graph_max = MAX_GRAPHS if n_graph_max is None else int(n_graph_max)
    n_color_max = MAX_COLOR_GROUPS if n_color_max is None else int(n_color_max)
    graph_height = GRAPH_HEIGHT if graph_height is None else int(graph_height)
    if (_a is None) & (_b is None) & (data is None):
        raise PreventUpdate
    elif (_a is None) & (_b is None) & (len(data) == 0):
        raise PreventUpdate

    if bool_test_data & (len(data) == 0):
        pd_data = pd.read_pickle('pd_output.pkl')
    else:
        if len(data) == 0:
            raise PreventUpdate
        pd_data = pd.DataFrame(data)

    group_col_graph_ori, group_col_color_ori, group_col_x_ori, col_metric_ori = group_col_graph, group_col_color, group_col_x, col_metric

    col_metric = col_metric.lower()
    group_col_graph = ''.join(group_col_graph.split(' ')).lower()
    group_col_color = ''.join(group_col_color.split(' ')).lower()
    group_col_x = ''.join(group_col_x.split(' ')).lower()
    graph_groups = list(pd_data.groupby(group_col_graph)[col_metric].sum().sort_values(ascending=False).iloc[:n_graph_max].index)
    dict_pd_data = {i: pd_data.loc[pd_data[group_col_graph] == i] for i in graph_groups}
    graph_width = f'{int(100 / n_graph_x)}%'
    dict_yaxis_label = {'Volume': 'Volume (Ton)', 'Sales': 'Sales (USD)'}

    graph_outputs = []
    graph_row = []
    if len(pd_data[group_col_color].unique()) <= UNITFY_COLOR_THRESHOLD:
        col_color_values = pd_data.groupby(group_col_color)[col_metric].sum().sort_values(ascending=False).index
        colors = px.colors.qualitative.Plotly
        dict_color = {col_color_values[i]: colors[i] for i in range(len(col_color_values))}
    else:
        dict_color = None

    for i_graph in range(len(graph_groups)):
        pd_graph = dict_pd_data[graph_groups[i_graph]]

        fig = go.Figure()
        graph = dcc.Graph(style={'width': graph_width, 'height': graph_height, 'margin': '5px'}, figure=fig)

        pd_agg = pd_graph.groupby([group_col_color, group_col_x])[col_metric].sum().reset_index().fillna(0).sort_values(by=group_col_x)
        if group_col_x == 'month':
            if len(pd_agg['month'].unique()) <= 3:
                pd_agg['month'] = pd_agg['month'] + '-15'
        groups_color = pd_graph.groupby([group_col_color], observed=True)[col_metric].sum().sort_values(ascending=False).iloc[:n_color_max].index
        if dict_color is not None:
            groups_color_final = [i for i in dict_color if i in groups_color]
        else:
            groups_color_final = groups_color
        for group_color in groups_color_final:
            pd_agg_color = pd_agg.loc[pd_agg[group_col_color] == group_color]
            color_plot = None if dict_color is None else dict_color[group_color]
            if graph_type == 'Scatter':
                fig.add_trace(
                    go.Scatter(x=pd_agg_color[group_col_x], y=pd_agg_color[col_metric], mode='lines+markers', name=group_color,
                               marker_line_color=color_plot, marker_color=color_plot))
            elif graph_type == 'Stacked bar':
                fig.add_trace(
                    go.Bar(x=pd_agg_color[group_col_x], y=pd_agg_color[col_metric], name=group_color,
                           marker_line_color=color_plot, marker_color=color_plot))

        title = f'<b>{col_metric_ori} vs. {group_col_x_ori} - {graph_groups[i_graph]}</b>'
        xlabel, ylabel = group_col_x_ori, dict_yaxis_label[col_metric_ori]
        if group_col_x_ori == 'Month':
            xaxis_tickformatstops = [{'dtickrange': [None, None], 'value': "%y-%b"}]
        else:
            xaxis_tickformatstops = []
        if graph_type == 'Scatter':
            fig.update_layout(title=title, xaxis_title=xlabel, yaxis_title=ylabel, showlegend=True,
                              xaxis_tickformatstops=xaxis_tickformatstops)
        elif graph_type == 'Stacked bar':
            fig.update_layout(title=title, xaxis_title=xlabel, yaxis_title=ylabel, showlegend=True,
                              barmode='stack', xaxis={'categoryorder': 'total descending'},
                              xaxis_tickformatstops=xaxis_tickformatstops)
        if len(graph_row) < n_graph_x:
            graph_row.append(graph)
        else:
            graph_outputs.append(html.Div(graph_row, style={'width': '100%', 'display': 'flex'}))
            graph_row = []
            graph_row.append(graph)
    graph_outputs.append(html.Div(graph_row, style={'display': 'flex'}))

    return [graph_outputs]


div_main_table = html.Div(id='sales_vis_main_table', children=[
    html.Div([
        html.Div(children=[
            html.Div('Items per page'),
            dcc.Input(placeholder=str(PAGE_SIZE), id='sales_vis_table_items_per_page', style={'width': '75px', 'height': '35px'})
        ], style={'margin-left': '5px'}),

        html.Div(children=[
            html.Br(),
            html.Button('Prev', id='sales_vis_table_button_previous_page', style={'height': '35px'}),
        ], style={'margin-left': '30px'}),

        html.Div(children=[
            html.Div('Current page'),
            dcc.Input(placeholder='1', id='sales_vis_table_current_page', style={'width': '75px', 'height': '35px'}),
            html.A(' / 1', id='sales_vis_table_number_of_pages')
        ], style={'margin-left': '10px'}),

        html.Div(children=[
            html.Br(),
            html.Button('Next', id='sales_vis_table_button_next_page', style={'height': '35px'}),
        ], style={'margin-left': '10px'}),

    html.Div(children=[
            html.Br(),
            html.A('Note: Filtering applied in this table will be used in data visualization',),
        ], style={'margin-left': '10px'}),

    ], className='w3-row w3-light-grey', style={'display': 'flex', 'margin-bottom': '5px'}),
    html.Div([
        dash_table.DataTable(
            id='sales_vis_main_table_content',
            columns=[{'name': _column_names[i], 'id': _column_ids[i]} for i in range(len(_column_names))],
            data=[],
            style_table={'padding-right': '5px', 'padding-left': '5px', 'margin-bottom': '5px', 'width': '1500px'},
            style_cell={'whiteSpace': 'normal'},
            style_header={'backgroundColor': 'rgb(210, 210, 210)', 'color': 'black', 'fontWeight': 'bold',
                          'border': '1px solid black'},
            style_cell_conditional=[
                {'if': {'column_id': 'product_family'}, 'width': '70px', 'minWidth': '70px', 'maxWidth': '70px'},
                {'if': {'column_id': 'grade'}, 'width': '135px', 'minWidth': '135px', 'maxWidth': '135px'},
                {'if': {'column_id': 'test_method'}, 'width': '120px', 'minWidth': '120px', 'maxWidth': '120px'},
                {'if': {'column_id': 'mfg_site'}, 'width': '50px', 'minWidth': '50px', 'maxWidth': '50px'},
                {'if': {'column_id': 'mfg_line'}, 'width': '50px', 'minWidth': '50px', 'maxWidth': '50px'},
                {'if': {'column_id': 'test_facility'}, 'width': '70px', 'minWidth': '70px', 'maxWidth': '70px'},
                {'if': {'column_id': 'test_standard'}, 'width': '70px', 'minWidth': '70px', 'maxWidth': '70px'},
                {'if': {'column_id': 'avg'}, 'width': '90px', 'minWidth': '90px', 'maxWidth': '90px'},
                {'if': {'column_id': 'std'}, 'width': '90px', 'minWidth': '90px', 'maxWidth': '90px'},
                {'if': {'column_id': 'num'}, 'width': '60px', 'minWidth': '60px', 'maxWidth': '60px'},
                {'if': {'column_id': 'data_type'}, 'width': '100px', 'minWidth': '100px', 'maxWidth': '100px', },
            ],
            style_data={'border': '1px solid black'},
            editable=True,
            sort_action="native", filter_action='native',
            sort_mode='multi',
            page_current=0,
            page_size=PAGE_SIZE,
        )], style={'overflow-x': 'scroll'}
    ),

], style={'display': 'none' if bool_test else 'block'})


div_data_visualization = html.Div([
    dcc.Store(id='sales_vis_data_vis_memory_page', storage_type='memory'),
    dcc.Store(id='sales_vis_data_vis_memory_data', storage_type='memory'),
    dcc.Store(id='sales_vis_data_vis_memory_data_filter', storage_type='memory', data={}),
    dcc.Store(id='sales_vis_data_vis_memory_figure', storage_type='memory', data={'plot_type': 'scatter'}),
    dcc.ConfirmDialog(id='sales_vis_pop_up_window', message=''), dcc.ConfirmDialog(id='sales_vis_pop_up_window_time_range', message=''),
    html.Div(id='sales_vis_data_vis_div_null'),
    html.Div([
        html.Div(
            id='sales_vis_query_filter', className='w3-col s4',
            children=[
                div_data_visualization_filters
            ], style={'border-right': '8px solid #ffffff'}
        ),
        html.Div(
            id='sales_vis_main_display',
            className='w3-col s8',
            children=[
                html.Div([
                    div_query_display_switch,
                    div_data_visualization_tabs
                ], style={'display': 'flex'}),
                html.Div(
                    children=[
                        div_main_table,
                        div_main_vis
                    ]
                ),
        ], style={'padding-left': '10px'}),

    ], className='w3-row')
], style={'fontSize': 13})


@app.callback([Output('sales_vis_date_start', 'value'), Output('sales_vis_date_end', 'value'),
              Output('sales_vis_pop_up_window_time_range', 'displayed'), Output('sales_vis_pop_up_window_time_range', 'message'),
              Input('sales_vis_data_vis_div_null', 'n_clicks'),
              Input('sales_vis_date_start', 'value'), Input('sales_vis_date_end', 'value')])
def check_input_date_range(_a, date_start, date_end):
    date_start_default = get_date(-180)
    date_end_default = get_date(0)

    trigger = callback_context.triggered[0]
    if type(trigger) is dict:
        if 'prop_id' in trigger:
            if 'sales_vis_date_' not in trigger['prop_id']:
                date_start = date_start_default
                date_end = date_end_default
    try:
        date_month_start, date_month_end = get_month_start_end(date_start, date_end)
    except:
        raise PreventUpdate

    if (date_month_end - date_month_start).days < 0:
        date_start_output, date_end_output = get_month_start_end(date_start_default, date_end_default, 'str')
        bool_display, message = True, 'Ending month has to be later then starting month'
    elif (date_month_end - date_month_start).days > 18 * 31:
        date_start_output, date_end_output = get_month_start_end(date_start_default, date_end_default, 'str')
        bool_display, message = True, 'Searching time range has be less than 18 months'
    else:
        date_start_output, date_end_output = get_month_start_end(date_start, date_end, 'str')
        bool_display, message = False, ''
    date_start_output, date_end_output = date_start_output[:7], date_end_output[:7]
    return date_start_output, date_end_output, bool_display, message


@app.callback([Output('sales_vis_filter_BusinessUnit', 'options'), Output('sales_vis_filter_ShipToRegion', 'options'),
              Output('sales_vis_filter_ShipToCountry', 'options'), Output('sales_vis_filter_ShipToCity', 'options'),
              Output('sales_vis_filter_CustomerSegment', 'options'), Output('sales_vis_filter_Customer', 'options'),
              Output('sales_vis_filter_FinishedProduct', 'options'), Output('sales_vis_filter_Industry', 'options'),
              Output('sales_vis_filter_MarketSegment', 'options'),
              Input('sales_vis_button_refresh', 'n_clicks'),
              State('sales_vis_date_start', 'value'), State('sales_vis_date_end', 'value')])
def update_filters(_a, date_start, date_end):
    if _a is None:
        raise PreventUpdate
    date_start, date_end = get_month_start_end(date_start+'-01', date_end + '-15', 'str')
    year_start, year_end = date_start[:4], date_end[:4]
    query = f"""
    select distinct columnname, value
    from SalesMonthAggDistinct
    where year >= {year_start} and year <= {year_end}
    """
    pd_filter = CACHE.exe_cloud_sql('CMIDataikuYunsongTest', query)
    output_keys = ['businessunit', 'region', 'country', 'city', 'customersegment', 'customer', 'product', 'industry', 'marketsegment']
    data_output = [sorted(pd_filter.loc[pd_filter['columnname'] == key]['value']) for key in output_keys]
    return data_output


def update_filter_values(_a, options, values, output_type='list'):
    trigger = callback_context.triggered[0]
    if type(trigger) is dict:
        if 'prop_id' in trigger:
            if 'sales_vis_button_clear' in trigger['prop_id']:
                return [] if output_type == 'list' else None
    if (options is None) | (values is None):
        return [] if output_type == 'list' else None
    # values_option = [i['value'] for i in options]
    values_option = options
    if output_type == 'list':
        values_output = [i for i in values if i in values_option]
        return values_output
    else:
        values_output = values if values in values_option else None
        return values_output


for key_name in dict_filters_1:
    key = dict_filters_1[key_name]

    @app.callback(Output(f'sales_vis_filter_{key}', 'value'),
                  Input(f'sales_vis_button_clear_{key}', 'n_clicks'),
                  Input(f'sales_vis_filter_{key}', 'options'),
                  State(f'sales_vis_filter_{key}', 'value'))
    def clear_filter(_a, options, values):
        result = update_filter_values(_a, options, values, 'list')
        return result

dict_filters_1 = {'Business unit': 'BusinessUnit', 'Region': 'ShipToRegion', 'Country': 'ShipToCountry',  'City': 'ShipToCity',
                  'Customer segment': 'CustomerSegment', 'Customer': 'Customer', 'Product': 'FinishedProduct',
                  'Industry': 'Industry', 'Market segment': 'MarketSegment'}


@app.callback([Output('sales_vis_main_table_content', 'data'),
              Output('sales_vis_pop_up_window', 'displayed'),
              Output('sales_vis_pop_up_window', 'message'),
              Input('sales_vis_button_query_data', 'n_clicks'),
              State('sales_vis_filter_BusinessUnit', 'value'),
              State('sales_vis_filter_ShipToRegion', 'value'),
              State('sales_vis_filter_ShipToCountry', 'value'),
              State('sales_vis_filter_ShipToCity', 'value'),
              State('sales_vis_filter_CustomerSegment', 'value'),
              State('sales_vis_filter_Customer', 'value'),
              State('sales_vis_filter_FinishedProduct', 'value'),
              State('sales_vis_filter_Industry', 'value'),
              State('sales_vis_filter_MarketSegment', 'value'),
              State('sales_vis_date_start', 'value'), State('sales_vis_date_end', 'value')])
def query_plot_data_basic(_a, businessunits, regions, countries, cities, customersegments, customers, products,
                          industries, marketsegments, date_start, date_end):
    if _a is None:
        raise PreventUpdate

    date_start, date_end = get_month_start_end(date_start + '-15', date_end + '-15', 'str')
    dict_filters_query = {
        'BusinessUnit': businessunits, 'ShipToRegion': regions, 'ShipToCountry': countries, 'ShipToCity': cities,
        'CustomerSegment': customersegments, 'Customer': customers, 'FinishedProduct': products, 'Industry': industries,
        'MarketSegment': marketsegments
    }
    if not bool_test_data:

        test_query = f"""
        select count(*) as num from SalesMonthAgg
        where AgiMonth >= Cast('{date_start}' as date) and AgiMonth <= Cast('{date_end}' as date)
        """
        query_filters = ''
        for filter_col in dict_filters_query:
            if dict_filters_query[filter_col] is not None:
                if len(dict_filters_query[filter_col]) > 0:
                    _options = "', '".join([i.replace("'", "''") for i in dict_filters_query[filter_col]])
                    _options = "'" + _options + "'"
                    query_filters += f'and {filter_col} in ({_options})\n'
        test_query += query_filters

        pd_query_count = CACHE.exe_cloud_sql('CMIDataikuYunsongTest', test_query)
        query_num = pd_query_count.iloc[0]['num']
        if query_num >= QUERY_LIMIT:
            return [], True, f'This data pull includes {query_num} data entries, which is great than limit of {QUERY_LIMIT}. \n' \
                             f'Please reduce the size of this query by carefully selecting filters'
        columns_query = ', '.join(_column_ids_query)
        query = f"""
        select {columns_query} from SalesMonthAgg
        where AgiMonth >= Cast('{date_start}' as date) and AgiMonth <= Cast('{date_end}' as date)
        {query_filters}"""

        pd_output = CACHE.exe_cloud_sql('CMIDataikuYunsongTest', query)
    else:
        pd_output = pd_sa_agg[_column_ids_query]
        pd_output = pd_output.loc[(pd_output['AgiMonth'] >= pd.to_datetime(date_start)) & (pd_output['AgiMonth'] <= pd.to_datetime(date_end))]
        for filter_col in dict_filters_query:
            if dict_filters_query[filter_col] is not None:
                if len(dict_filters_query[filter_col]) > 0:
                    pd_output = pd_output.loc[pd_output[filter_col].isin(dict_filters_query[filter_col])]

    pd_output.columns = _column_ids + ['customercode']
    pd_output['month'] = pd_output['month'].astype(str).str[:7]
    pd_output['sales'] = pd_output['sales'].round().astype(int)
    pd_output['volume'] = pd_output['volume'].round(3)
    # pd_output.to_pickle('pd_output.pkl')
    dict_output = pd_output.to_dict('record')
    return dict_output, False, ''


@app.callback([Output('sales_vis_main_table_content', 'page_size'),
               Output('sales_vis_table_items_per_page', 'value'),
               Input('sales_vis_table_items_per_page', 'value')])
def update_table(page_size):
    if page_size is None:
        raise PreventUpdate
    page_size = int(page_size)
    if page_size <= 0:
        page_size = PAGE_SIZE
    elif page_size > 100:
        page_size = 100
    return page_size, page_size


@app.callback([Output('sales_vis_main_table_content', 'page_current'),
               Output('sales_vis_table_current_page', 'value'),
               Output('sales_vis_table_number_of_pages', 'children'),
               Input('sales_vis_table_button_next_page', 'n_clicks'),
               Input('sales_vis_table_button_previous_page', 'n_clicks'),
               Input('sales_vis_table_current_page', 'value'),
               Input('sales_vis_main_table_content', 'page_current'),
               Input('sales_vis_main_table_content', 'data'),
               State('sales_vis_main_table_content', 'page_size')])
def update_table_page(_a, _b, current_page_display, current_page_table, data, page_size):
    if data is None:
        raise PreventUpdate
    elif len(data) == 0:
        raise PreventUpdate

    current_page_table = int(current_page_table)
    page_count = int(np.ceil(len(data) / int(page_size)))

    trigger = callback_context.triggered[0]
    if type(trigger) is dict:
        if 'prop_id' in trigger:
            if 'sales_vis_main_table_content' in trigger['prop_id']:
                current_page_display = current_page_table + 1
            else:
                if current_page_display is None:
                    current_page_display = 1
                if 'sales_vis_table_button_previous_page' in trigger['prop_id']:
                    current_page_display = int(current_page_display) - 1
                elif 'sales_vis_table_button_next_page' in trigger['prop_id']:
                    current_page_display = int(current_page_display) + 1
                else:
                    current_page_display = int(current_page_display)
    if current_page_display >= page_count:
        current_page_display = page_count
    elif current_page_display <= 0:
        current_page_display = 1
    return current_page_display - 1, str(current_page_display), f' / {page_count}'


@app.callback([Output('sales_vis_tab_vis_0', 'className'), Output('sales_vis_tab_vis_1', 'className'),
               Output('sales_vis_tab_vis_2', 'className'),
               Input('sales_vis_tab_vis_0', 'n_clicks'), Input('sales_vis_tab_vis_1', 'n_clicks'),
               Input('sales_vis_tab_vis_2', 'n_clicks')])
def update_tab_vis_classname(_0, _1, _2):
    if (_0 is None) & (_1 is None) & (_2 is None):
        raise PreventUpdate
    classnames = [tab_classname_default] * 3
    index_pressed = 0

    trigger = callback_context.triggered[0]
    if type(trigger) is dict:
        if 'prop_id' in trigger:
            if 'sales_vis_tab_vis' in trigger['prop_id']:
                index_pressed = int(trigger['prop_id'].split('.')[0][-1])
    classnames[index_pressed] = 'w3-bar-item w3-button w3-red w3-mobile'
    output = classnames
    return output


@app.callback(Output('sales_vis_main_table', 'style'), Output('sales_vis_main_vis', 'style'),
              Input('sales_vis_tab_vis_0', 'n_clicks'), Input('sales_vis_tab_vis_1', 'n_clicks'))
def update_main_content(_0, _1):
    if (_0 is None) & (_1 is None):
        raise PreventUpdate
    index_pressed = 0
    styles = [{'display': 'none'}] * 2
    trigger = callback_context.triggered[0]
    if type(trigger) is dict:
        if 'prop_id' in trigger:
            if 'sales_vis_tab_vis' in trigger['prop_id']:
                index_pressed = int(trigger['prop_id'].split('.')[0][-1])
    styles[index_pressed] = {'style': 'block'}
    return styles
