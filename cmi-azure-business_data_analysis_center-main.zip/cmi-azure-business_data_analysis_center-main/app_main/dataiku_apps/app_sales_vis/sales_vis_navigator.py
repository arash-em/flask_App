# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

import dash
from dash import html
from dash.dependencies import Input, Output, State
from dash.exceptions import PreventUpdate

from app_main.dataiku_apps.lib.main_lib import CACHE
from . import sales_vis_data_visualizaiton, sales_vis_project_background

app = CACHE.app



BUTTON_SEQ = [
    'sales_vis_button_data_visualization',
    'sales_vis_button_project_background',
    'sales_vis_button_about_us'
]

BUTTON_DEFAULT = BUTTON_SEQ[0]

DICT_BUTTON_PARENT = {}

for parent_button_id in DICT_BUTTON_PARENT:
    CACHE.dict_state[parent_button_id] = False

BUTTON_FUNC_LIST = []
for button in BUTTON_SEQ:
    if button not in DICT_BUTTON_PARENT:
        BUTTON_FUNC_LIST.append(button)
    else:
        BUTTON_FUNC_LIST += DICT_BUTTON_PARENT[button]


DICT_BUTTON_HTML = {
    'sales_vis_button_project_background': {'icon': 'fab fa-readme', 'text': '  Project Background'},
    'sales_vis_button_data_visualization': {'icon': 'fas fa-chart-bar', 'text': '  Data Analysis'},
    'sales_vis_button_about_us': {'icon': 'fas fa-smile-wink', 'text': '  About Us'},
}

DICT_DIRECTORY = {
    'sales_vis_button_project_background': sales_vis_project_background.div_project_background,
    'sales_vis_button_data_visualization': sales_vis_data_visualizaiton.div_data_visualization,
}

DICT_HREF = {'sales_vis_button_about_us': 'https://goto/cmi'}

MAIN_DISPLAY_CONTENT = html.Div(id='sales_vis_main_display_content', children=DICT_DIRECTORY[BUTTON_DEFAULT])

CACHE.dict_activity_store['main_page'] = BUTTON_DEFAULT

user_info_window = html.Div([
    html.A(children=[
        html.Img(src='https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png',
                 className='w3-circle w3-margin-right', style={'width': '35px'})
    ], className='w3-col s4'),
    html.Div(
        [
            f"Welcome, ",
            html.Strong(children='...', id='sales_vis_user_firstname')
        ], className='w3-col s8 w3-bar'
    ),
], className='w3-container w3-row')

navitagor_buttons = [
    html.A(className='w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black')
]
for index_button, button_id in enumerate(BUTTON_SEQ):
    section_name = '_'.join(button_id.split('_')[1:])
    if index_button == 0:
        classname = 'w3-bar-item w3-button w3-padding w3-blue'
    else:
        classname = 'w3-bar-item w3-button w3-padding'

    if button_id not in DICT_BUTTON_PARENT:
        component_caret_down = html.Div()
    else:
        component_caret_down = html.I(className='fa fa-caret-down', id=f'caret_icon_{section_name}',
                                      style={'margin-left': '10px'})
    href_link_1 = None
    _target_1 = None
    if button_id in DICT_HREF:
        href_link_1 = DICT_HREF[button_id]
        _target_1 = '_blank'
    navitagor_buttons.append(
        html.A(id=button_id, className=classname, href=href_link_1, target=_target_1, children=[
            html.I(className=DICT_BUTTON_HTML[button_id]['icon']),
            html.A(DICT_BUTTON_HTML[button_id]['text'], style={'margin-left': '5px'}),
            component_caret_down,
        ]),
    )

    if button_id in DICT_BUTTON_PARENT:
        container_list = []
        for button_id_child in DICT_BUTTON_PARENT[button_id]:
            # Loop through all the child buttons
            if button_id_child in DICT_HREF:
                href_link = DICT_HREF[button_id_child]
                _target = '_blank'
            else:
                href_link = None
                _target = None
            container_list.append(
                html.A(
                    id=button_id_child, className='w3-bar-item w3-button w3-padding',
                    children=[
                        html.I(className=DICT_BUTTON_HTML[button_id_child]['icon']),
                        html.A(DICT_BUTTON_HTML[button_id_child]['text'], style={'margin-left': '5px'})
                    ],
                    style={'margin-left': '15px'}, href=href_link, target=_target,
                )
            )

        # Add the contains that includes the child buttons
        navitagor_buttons.append(
            html.Div(
                id=f'section_{section_name}', className="w3-bar-block w3-hide w3-medium w3-show",
                style={'padding-bottom': '5px', 'padding-top': '5px', 'transition': 'height 1s'},
                children=container_list
            )
        )


navigator = html.Nav([
    html.Div(style={'height': '10px'}),
    user_info_window,
    html.Hr(style={'margin-top': '10px', 'margin-bottom': '5px'}),
    html.Div(className='w3-bar-block', children=navitagor_buttons),
],
    className='w3-sidebar w3-collapse w3-white w3-animate-left',
    style={'width': CACHE.sidebar_width, }
)


@app.callback(
    [Output(i, 'className') for i in BUTTON_FUNC_LIST] + [Output('sales_vis_page_content_title', 'children')],
    [Input(i, 'n_clicks') for i in BUTTON_FUNC_LIST])
def update_buttons_format(*args):
    ctx = dash.callback_context
    _button_id_detected = ctx.triggered[0]['prop_id'].split('.')[0]
    nav_class_list = ['w3-bar-item w3-button w3-padding'] * len(BUTTON_FUNC_LIST)
    if _button_id_detected in BUTTON_FUNC_LIST:
        index = BUTTON_FUNC_LIST.index(_button_id_detected)
    else:
        index = 0
        _button_id_detected = BUTTON_FUNC_LIST[index]
    nav_class_list[index] = 'w3-bar-item w3-button w3-padding w3-blue'
    page_content_title_output = [
        html.I(className=DICT_BUTTON_HTML[_button_id_detected]['icon']),
        html.B(DICT_BUTTON_HTML[_button_id_detected]['text'], style={'margin-left': '5px'})
    ]
    output = nav_class_list + [page_content_title_output]
    return output


@app.callback(
    Output('sales_vis_main_display_content', 'children'),
    State('root_memory_global', 'data'),
    [Input(i, 'n_clicks') for i in BUTTON_FUNC_LIST if i not in DICT_HREF],
)
def update_fet_main_display_content(*args):
    if args[0] is None:
        raise PreventUpdate
    ctx = dash.callback_context
    _button_id_detected = ctx.triggered[0]['prop_id'].split('.')[0]
    _button_id_detected_ori = _button_id_detected
    if _button_id_detected not in DICT_DIRECTORY:
        index = 0
        _button_id_detected = BUTTON_FUNC_LIST[index]
        if (_button_id_detected_ori is not None) & (_button_id_detected_ori != ''):
            print(f'Page for {_button_id_detected} is not ready')
    else:
        index = BUTTON_FUNC_LIST.index(_button_id_detected)
        _button_id_detected = BUTTON_FUNC_LIST[index]

    memory_data = args[0]
    if memory_data is None:
        dict_info = CACHE.get_user_info()
    else:
        dict_info = memory_data['userinfo']
    CACHE.exe_log_activity(dict_info['username'], webapp='sales_vis', item='navigator', subitem='', value=_button_id_detected)
    output = DICT_DIRECTORY[_button_id_detected]
    return output


parent_button_id_list = sorted(DICT_BUTTON_PARENT.keys())
section_id_list = ['section_' + '_'.join(parent_button_id.split('_')[1:]) for parent_button_id in parent_button_id_list]
caret_icon_id = ['caret_icon_' + '_'.join(parent_button_id.split('_')[1:]) for parent_button_id in parent_button_id_list]
output_list_1 = [Output(i, 'className') for i in section_id_list + caret_icon_id]
input_list_1 = [Input(i, 'n_clicks') for i in parent_button_id_list]

if len(input_list_1) > 0:
    @app.callback(
        output_list_1, input_list_1
    )
    def update_tabulated_buttons(*args):
        clicks = [i if i is not None else 0 for i in args]

        output_1 = ['w3-bar-block w3-hide w3-medium'] * len(parent_button_id_list)
        output_2 = ['fas fa-caret-down'] * len(parent_button_id_list)
        for ind, _button_id in enumerate(parent_button_id_list):
            if (clicks[ind] % 2) == 1:
                output_1[ind] = 'w3-bar-block w3-hide w3-medium w3-show'
                output_2[ind] = 'fas fa-caret-up'
        return output_1 + output_2
