# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from dash import html, dcc
from dash.dependencies import Input, Output, State
import base64
from app_main.dataiku_apps.lib.main_lib import CACHE, LABEL_SYSTEM
from app_main.dataiku_apps.app_sales_vis import sales_vis_navigator

app_dash = CACHE.app
DIR = CACHE.DIR
dict_image = CACHE.dict_image
BGCOLOR = '#f2f2f2'

CACHE.count_link_to_root += 1
main_page = html.Div([
    html.Div([
        html.Div(id='sales_vis_div_null')
    ]),
    html.Div(className="w3-bar w3-top w3-black w3-large", style={'z-index': '6'}, children=[
        dcc.Link(className='w3-bar-item', id=f'link_to_root-{CACHE.count_link_to_root}', href='', children=[
            html.I(className='fas fa-arrow-circle-left'),
            html.A(' Go back', style={'font-family': 'Raleway'})
        ]),
        html.Div(children=f'', id='sales_vis_visitor_count',
                 className='w3-bar-item w3-right', style={'font-family': 'Raleway'})
    ]),
    sales_vis_navigator.navigator,
    html.Div([
        html.Header(children=[
            html.H5(id='sales_vis_page_content_title', style={'text-align': 'left'}),
        html.Header(children=[
            html.B('Chemical Sales Visualization Dashbard',
                   style={'margin-left': '5px', 'font-size': '20px', 'border-right': '1px solid #939596',
                          'padding-right': '10px', 'margin-right': '10px', 'padding-top': '10px',
                          'padding-bottom': '10px'}),
            html.A(
                [
                    html.Img(src=dict_image['matdb-logo-1x'],
                             style={'text-align': 'right', 'margin-right': '5px', 'height': '50px'}),
                    html.B('MATDB', style={'font-size': '20px', 'color': '#f45721'})
                ],
                href="http://goto/matdb", target="_blank",
            ),
            ], style={'flex-grow': '3', 'text-align': 'right'}),
        ], style={'padding-top': '5px', 'padding-bottom': '5px',
                  'display': 'flex', 'justify-content': 'space-between'}),
    ], className='w3-container w3-bar', style={'margin-top': '43px', 'padding-left': CACHE.sidebar_width + 10,
                                               'background-color': BGCOLOR}),

    html.Div([
        #html.Div(style={'padding-top': '48px'}),

        ####################
        sales_vis_navigator.MAIN_DISPLAY_CONTENT
        ####################

    ], className='w3-main', style={'margin-left': CACHE.sidebar_width, 'margin-top': '0px'}),
    html.Div(style={'width': '100%', 'height': '100%', 'padding-top': '50px', 'background-color': BGCOLOR})
],
    style={'font-family': 'Raleway', 'background-color': BGCOLOR, 'height': '100%', 'width': '100%', 'background-size': 'cover',
           'background-position': 'center', 'background-repeat': 'no-repeat'},
    className='w3-light-grey',
)


@app_dash.callback(
    Output('sales_vis_visitor_count', 'children'),
    Output('sales_vis_user_firstname', 'children'),
    Input('sales_vis_div_null', 'n_clicks'),
    State('root_memory_global', 'data')
)
def upload_db(_, data):
    if data is None:
        str_output = data['visit_count']
        first_name = data['userinfo']['first_name']
    else:
        first_name = CACHE.get_user_info()['first_name']
        pd_visit = CACHE.get_visit_info()
        str_output = f'Visitor count: {len(pd_visit)}'

    return str_output, first_name
