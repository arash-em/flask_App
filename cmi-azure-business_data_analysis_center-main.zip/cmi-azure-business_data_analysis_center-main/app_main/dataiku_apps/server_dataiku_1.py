import datetime
from dash import html, dcc
import os
import pandas as pd
from dash.dependencies import Input, Output, State
from dash.exceptions import PreventUpdate
from flask import redirect, url_for
import flask
import dash
from flask_dance.contrib.azure import azure
from app_main.dataiku_apps.lib.main_lib import CACHE


pd.set_option('display.max_column', 75)
pd.set_option('display.max_colwidth', 2400)
pd.set_option('display.width', 25000)

DIR_ROOT = CACHE.DIR_ROOT
APP_ID = 'bizcenter'
URL_BASE = '/bizcenter/'
MIN_HEIGHT = 200
BOOL_TEST = False

LABEL_SYSTEM = 'WINDOWS'

BOOL_protect = True


def login_required(func):
    """Require a login for the given view function."""
    def check_authorization(*args, **kwargs):
        if not azure.authorized or azure.token.get("expires_in") < 3600:
            return redirect(url_for("azure.login"))
        else:
            return func(*args, **kwargs)
    return check_authorization


def _protect_dashviews(dashapp):
    for view_func in dashapp.server.view_functions:
        if 'bizcenter' in view_func:
            dashapp.server.view_functions[view_func] = login_required(dashapp.server.view_functions[view_func])


def add_dash_bizcenter(server):

    external_stylesheets = ['https://www.w3schools.com/w3css/4/w3.css',
                            'https://fonts.googleapis.com/css?family=Raleway',
                            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.css',
                            # f'{DIR_ROOT}/static/css/YX_pre_style.css'
                            ]

    app_dash = dash.Dash(
        __name__,
        server=server,
        suppress_callback_exceptions=True,
        external_stylesheets=external_stylesheets,
    )

    CACHE.app = app_dash
    appname = 'bizcenter'
    CACHE.appname = appname

    from app_main.dataiku_apps import dataiku_main as root_page
    from app_main.dataiku_apps.app_3d_printing import main_3d_printing as page_3d_printing
    from app_main.dataiku_apps.app_fet import main_fet as page_fet
    from app_main.dataiku_apps.app_fet_brpp import main_fet_brpp as page_fet_brpp
    from app_main.dataiku_apps.app_sales_vis import main_sales_vis as page_sales_vis

    url_bar_and_content_div = html.Div([
        dcc.Store(id='root_memory_global', storage_type='session'),
        # dcc.Interval(id='root_interval', interval=600000),
        dcc.Location(id='dash-url', refresh=False),
        html.Div(id='root-url', style={'display': 'none'}),
        html.Div(id='root-first-loading', style={'display': 'none'}),
        html.Div(id='root-page-content')
    ])

    @app_dash.callback(
        Output('root_memory_global', 'data'),
        Input('root-page-content', 'n_clicks'),
        State('root_memory_global', 'data'),
    )
    def upload_db(_, data_input):
        bool_reload = False
        if data_input is None:
            bool_reload = True
        else:
            time_last = datetime.datetime.strptime(data_input['time_last'][:19], '%Y-%m-%dT%H:%M:%S')
            time_now = datetime.datetime.now()
            time_span_hour = (time_now - time_last).seconds // 60
            if time_span_hour >= 30:
                bool_reload = True

        dict_info = CACHE.get_user_info()
        if bool_reload:
            dict_info = CACHE.get_user_info()
            CACHE.exe_log_activity(dict_info['username'], webapp='Dataiku Root', item='Enter app', subitem='', value='')
            pd_visit = CACHE.get_visit_info()
            str_output = f'Visitor count: {len(pd_visit)}'

            data = {'userinfo': dict_info, 'visit_count': str_output, 'time_last': datetime.datetime.now(),
                    'pd_visit': pd_visit.to_dict('list')}
            data_output = data
        else:
            data_output = data_input
            data_output['userinfo'] = dict_info
        return data_output

    # The following callback is used to dynamically instantiate the root-url
    @app_dash.callback(Output('root-url', 'children'),
                  Output('root-first-loading', 'children'),
                  Input('dash-url', 'pathname'),
                  State('root-first-loading', 'children')
                  )
    def update_root_url(pathname, first_loading):
        if first_loading is None:
            return pathname, True
        else:
            raise PreventUpdate

    for i in range(CACHE.count_link_to_root):
        @app_dash.callback(Output(f'link_to_root-{i+1}', 'href'),
                      Input('root-url', 'children'))
        def update_root_link(root_url):
            return URL_BASE


    @app_dash.callback(Output('root-page-content', 'children'),
                  Input('root-url', 'children'),
                  Input('dash-url', 'pathname'),
                  State('root_memory_global', 'data')
                  )
    def display_page(_root_url, pathname, data):

        if data is None:
            dict_info = CACHE.get_user_info()
        else:
            dict_info = data['userinfo']

        if f"{URL_BASE}page-3d_printing" == pathname:
            CACHE.exe_log_activity(dict_info['username'], webapp='3d_printing', item='Enter app', subitem='', value='')
            return page_3d_printing.main_page
        elif f"{URL_BASE}page-fet" == pathname:
            CACHE.exe_log_activity(dict_info['username'], webapp='fet', item='Enter app', subitem='', value='')
            return page_fet.main_page
        elif f"{URL_BASE}page-fet-brpp" == pathname:
            CACHE.exe_log_activity(dict_info['username'], webapp='fet_brpp', item='Enter app', subitem='', value='')
            return page_fet_brpp.main_page
        elif f"{URL_BASE}page-sales_vis" == pathname:
            CACHE.exe_log_activity(dict_info['username'], webapp='sales_vis', item='Enter app', subitem='', value='')
            return page_sales_vis.main_page
        else:
            CACHE.exe_log_activity(dict_info['username'], webapp='Portal page', item='Enter app', subitem='', value='')
            return root_page.main_page


    # index layout
    app_dash.layout = url_bar_and_content_div
    app_dash.validation_layout = [
        url_bar_and_content_div,
        root_page.main_page,
        page_3d_printing.main_page,
        page_fet.main_page,
        page_fet_brpp.main_page
    ]

    return server

