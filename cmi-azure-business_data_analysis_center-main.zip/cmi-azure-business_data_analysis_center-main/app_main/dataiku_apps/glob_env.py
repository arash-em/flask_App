# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

import os

# Get data from Excel
# if os.path.realpath('')[0] == '/':
LABEL_SYSTEM = 'WINDOWS'
if LABEL_SYSTEM == 'WINDOWS':
    DIR = os.path.dirname(os.path.realpath(__file__))
    DIR_ROOT = os.path.dirname(os.path.dirname(DIR))
    DIR_DOWNLOAD = f'{DIR_ROOT}/downloads'
    if not os.path.isdir(DIR_DOWNLOAD):
        os.mkdir(DIR_DOWNLOAD)
    DIR = DIR.replace('\\', '/')
    DIR_DATA = f'{DIR}/static_data'
    DICT_PATH_EXCEL = {
        '3d_printing': f'{DIR}/static_data/3d printing data modified.xls',
        'fet': f'{DIR}/static_data/FET data compiled.xls'
    }
    DICT_PATH_DB = {
        '3d_printing': f'{DIR}/static_data/3d_printing_data.db',
        'fet': f'{DIR}/static_data/fet_data.db',
        'admin': f'{DIR}/static_data/user_activity.db',
    }
else:
    # linux system
    LABEL_SYSTEM = 'LINUX'
    import dataiku
    DIR = dataiku.Folder('CAD_transformation_3d_printing').get_path()
    DIR_DATA = f'{DIR}'
    DICT_PATH_EXCEL = {
        '3d_printing':  f'{DIR}/3d printing data modified.xls',
        'fet': f'{DIR}/FET data compiled.xls'
    }
    DICT_PATH_DB = {
        '3d_printing': f'{DIR}/3d_printing_data.db',
        'fet': f'{DIR}/fet_data.db',
        'admin': f'{DIR}/user_activity.db',
    }
