# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com
import os.path

import pandas as pd

from app_main.dataiku_apps.lib.main_lib import CACHE
from dash.dependencies import Input, Output, State
from dash import html, dcc, callback_context, dash_table
from datetime import datetime, timedelta
import time, glob
import requests
from dash.exceptions import PreventUpdate

DROPDOWN_WIDTH = 350
PAGE_SIZE = 15
TAB_HEIGHT = '46px'

SEARCH_WINDOW_WIDTH = 4


padding_paragraph = '5px'
dict_href_style = {}

app = CACHE.app
APPNAME = 'CADI'

dict_table_columns = {'batch': ['Sales Order', 'Language', 'Document Time'],
                      'sales_order': ['Batch No.', 'Material Desc.', 'Language', 'Document Time'], }

table_columns = ['Sales Order', 'Language', 'Ship No.', 'Document Time']


tab_pad_top, tab_pad_bottom = 13, 13
#tab_style = {'padding-top': f'{tab_pad_top}px', 'padding-bottom': f'{tab_pad_bottom}px'}
tab_style = {'padding-top': f'{tab_pad_top}px', 'padding-bottom': f'{tab_pad_bottom}px'}
tab_classname_default = 'w3-bar-item w3-button w3-mobile'
tab_classname_highlight = 'w3-bar-item w3-button w3-red w3-mobile'
div_tabs_search = html.Div(
    children=[
        html.A(className=tab_classname_highlight,
               children='COA PDF',
               id='cadi_tab_vis_0',
               style=tab_style)],
    id='cadi_tab_vis', className='w3-bar w3-white',  style={'margin-top': '0px', 'padding-left': '0px'})


div_data_tabs_visualization_buttons = html.Div(
    id='cadi_vis_button_sec',
    children=[
        html.Div(
            id='cadi_search_button_table',
            children=[
                html.Button('Download', id='cadi_button_pdf_download'),
                dcc.Download(id="cadi_download_pdf_download")
            ],
            style={'display': 'none'}
        ),
    ],
    style={'margin-top': '10px', 'margin-bottom': '10px'}
)


# search_tabs = ["Batch/Lot ID", "Sales Order No."]
search_tabs = ["Batch/Lot ID"]
div_search_tabs = html.Div(
    children=[
                 html.A(className=tab_classname_highlight, children=search_tabs[0], id=f'{APPNAME}-search-tab-0', style=tab_style),
             ] + [
                 html.A(className=tab_classname_default, children=search_tabs[i + 1], id=f'{APPNAME}-search-tab-{i + 1}', style=tab_style)
                 for i in range(len(search_tabs) - 1)
             ],
    id=f'{APPNAME}-search-tabs', className='w3-white',
    style={'margin-top': '0px', 'padding-left': '0px', 'margin-right': '10px', 'margin-left': '10px'}
)

DICT_TABS_VISUALIZATION = {'Individual Lot': ['PDF']}


div_data_tabs_visualization = html.Div(
    children=[
        html.A(className=tab_classname_highlight,
               children=DICT_TABS_VISUALIZATION['Individual Lot'][0],
               id='cadi_tab_vis_0',
               style=tab_style)] +
             [
                 html.A(
                     id=f'cadi_tab_vis_{i + 1}',
                     style=tab_style,
                     className=tab_classname_default,
                     children=DICT_TABS_VISUALIZATION['Individual Lot'][i + 1]
                 )
              for i in range(len(DICT_TABS_VISUALIZATION['Individual Lot']) - 1)
             ]
    , id='cadi_tab_vis', className='w3-bar w3-white',  style={'margin-top': '0px', 'padding-left': '0px'})

div_query_display_switch = html.Button(
    children=[
        html.A(className='far fa-eye-slash', id='cadi_query_display_switch_icon'),
        html.A(' Hide queries', id='cadi_query_display_switch_text'),
    ],
    style={'width': '150px', 'height': TAB_HEIGHT, 'margin-right': '10px'},
    id='cadi_query_display_switch')


temp = [{'Ship No.': '0012102492', 'Sales Order': '0012549304', 'Language': 'E', 'Document Time': '2022-05-31'}, {'Ship No.': '0012091867', 'Sales Order': '0012549299', 'Language': 'E', 'Document Time': '2022-06-03'}]
pd_data_show = pd.DataFrame(temp)
buttons_execution = html.Div([
    html.Div(id=f'{APPNAME}-search-div-material_display', style={'display': 'none'}),
    html.Div(
        children=html.Button('Query Data', id='cadi_button_query_data', style={'width': '100px'}),
        className='w3-light-grey', style={'height': '45px', 'width': '50%'}
        ),
    dcc.Loading([
        dash_table.DataTable(
            id=f'{APPNAME}-search-div-table-batch',
            columns=[{'name': table_columns[i], 'id': table_columns[i]} for i in range(len(table_columns))],
            data=pd_data_show.to_dict('record'),
            style_table={'margin-bottom': '15px',
                         'width': '100%', 'height': '100%', 'overflow-y': 'scroll'},
            style_cell={'whiteSpace': 'normal', 'fontSize': 13},
            style_header={'backgroundColor': 'rgb(210, 210, 210)', 'color': 'black', 'fontWeight': 'bold',
                          'border': '1px solid black'},
            style_data={'border': '1px solid black', 'overflowX': 'auto'},
            editable=True,
            page_current=0,
            page_size=PAGE_SIZE,
            row_selectable='single'
        ),
        html.Button('Get PDF', id=f'{APPNAME}-button-get_pdf', style={'width': '100px'})
    ])
],style={'width': '100%'})

div_data_vis_filters_children = html.Div([
    html.Div(
        children=[
            html.Div('Batch/Lot No.', style={'width': '80px', 'min-width': '80px', 'margin-top': '3px', 'margin-right': '10px'}),
            dcc.Input(id='cadi_input_batch_no', style={'width': '100%', 'margin-right': '10px'}),
        ],
        id='cadi_div_input_sec_batch',
        style={'display': 'flex', 'margin-bottom': '10px'}),
    # html.Div(
    #     children=[
    #         html.Div('Sales Order No.', style={'width': '100px', 'margin-top': '3px'}),
    #         dcc.Input(id='cadi_input_sales_no'),
    #     ],
    #     id='cadi_div_input_sec_sales',
    #     style={'display': 'flex', })
])

div_data_visualization_filters = html.Div(
    children=[
        div_search_tabs,
        html.Div(
            id='cadi_result_filters',
            children=div_data_vis_filters_children,
            className='w3-light-grey',
            style={'padding-left': '15px', 'padding-right': '15px', 'margin-top': '10px'}
        ),
        html.Div(
            children=buttons_execution,
            className='w3-light-grey',
            style={'padding-left': '15px', 'padding-right': '15px', 'margin-top': '10px'}
        )
    ]
)

div_main_display = html.Div(
    id='cadi_div_main_display',
    children=[dcc.Loading(children=[
        html.Iframe(
            id="cadi_frame_pdf",
            src=f"",
            style={'display': 'block', 'width': '100%', 'height': '650px', 'margin-right': '5px', 'padding-right': '5px'})
    ],
    )]
)


div_data_visualization = html.Div([
    dcc.Store(id='cadi_data_vis_memory_page', storage_type='memory', data={}),
    dcc.Store(id='cadi_data_vis_memory_data', storage_type='memory'),
    dcc.Store(f'{APPNAME}-Store-search_tab', storage_type='memory', data={'ind': 0}),
    dcc.Store(id='cadi_data_vis_memory_individual_selection', storage_type='memory'),
    dcc.Store(id='cadi_data_vis_memory_tabs_filter', storage_type='memory',
              data={'filter': 0, 'trigger': False}),
    dcc.Store(id='cadi_data_vis_memory_tabs_vis', storage_type='memory', data={'vis': 0}),
    dcc.ConfirmDialog(id='cadi_pop_up_window_data_unavailable', message=''),
    html.Div(id='cadi_data_vis_div_null'),
    html.Div([
        html.Div(
            id='cadi_query_filter',
            className=f'w3-col s{SEARCH_WINDOW_WIDTH}',
            children=[
                div_data_visualization_filters,
                dcc.Loading(
                    id="cadi_loading_main_data",
                    children=[
                        dcc.Store(id='cadi_data_vis_memory_main_data_pdf', storage_type='memory', data={}),
                        dcc.Store(id='cadi_data_vis_memory_main_data_results', storage_type='memory', data={})
                    ],
                ),
            ], style={'border-right': '8px solid #ffffff'}
        ),
        html.Div(
            id='cadi_main_display',
            className=f'w3-col s{12-SEARCH_WINDOW_WIDTH}',
            children=[
                html.Div([
                    div_query_display_switch,
                    div_data_tabs_visualization,
                ], style={'display': 'flex'}),
                div_data_tabs_visualization_buttons,
                div_main_display,
        ], style={'padding-left': '10px'}),

    ], className='w3-row'),
], style={'fontSize': 13})


@app.callback([Output('cadi_input_batch_no', 'disabled'),
               Output('cadi_data_vis_memory_individual_selection', 'data')],
              [Input('cadi_div_input_sec_batch', 'n_clicks')]
              )
def update_main_display(_a):
    trigger = callback_context.triggered[0]
    if (type(trigger) is dict) & ((_a is not None)):
        item_click = trigger['prop_id'].split('.')[0]
        if 'batch' in item_click:
            return False, {'type': 'batch'}
        else:
            return True, {'type': 'sales'}
    else:
        return False, {}


@app.callback([Output('cadi_query_filter', 'style'), Output('cadi_main_display', 'className'),
               Output('cadi_query_display_switch_icon', 'className'), Output('cadi_query_display_switch_text', 'children')],
               Input('cadi_query_display_switch', 'n_clicks'))
def update_query_display_show_hide(_a):
    if _a is None:
        raise PreventUpdate
    if _a % 2 == 1:
        fet_brpp_query_display_switch_icon_classname = 'far fa-eye'
        fet_brpp_query_display_switch_text = ' Show queries'
        fet_brpp_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'none'}
        fet_brpp_main_display_classname = 'w3-col '
    else:
        fet_brpp_query_display_switch_icon_classname = 'far fa-eye-slash'
        fet_brpp_query_display_switch_text = ' Hide queries'
        fet_brpp_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'block'}
        fet_brpp_main_display_classname = 'w3-col s8'
    output = [fet_brpp_query_filter_style, fet_brpp_main_display_classname, fet_brpp_query_display_switch_icon_classname,
              fet_brpp_query_display_switch_text]
    return output



if len(search_tabs) > 1:
    inputs_vis_tabs = [Input(f'{APPNAME}-search-tab-{i}', 'n_clicks') for i in range(len(search_tabs))]
    outputs_vis_tabs = [Output(f'{APPNAME}-Store-search_tab', 'data')] + [Output(f'{APPNAME}-search-tab-{i}', 'className') for i in range(len(search_tabs))]
    states_vis_tabs = [Input(f'{APPNAME}-search-tab-{i}', 'className') for i in range(len(search_tabs))]

    @app.callback(outputs_vis_tabs, inputs_vis_tabs, states_vis_tabs)
    def update_vis_tab_classname(*args):
        trigger = callback_context.triggered[0]
        n_tabs = int(len(args) / 2)
        n_clicks = args[:n_tabs]
        bool_not_init = any([i is not None for i in n_clicks])
        if (type(trigger) is dict) & bool_not_init:
            item_click = trigger['prop_id'].split('.')[0].split('.')[0]
            ind_click = int(item_click.split('-')[-1])
            outputs_classname = [tab_classname_default] * n_tabs
            outputs_classname[ind_click] = tab_classname_highlight
            data_output = {'ind': ind_click}
        else:
            outputs_classname = [tab_classname_highlight] + [tab_classname_default] * (n_tabs - 1)
            data_output = {'ind': 0}

        outputs = [data_output] + outputs_classname
        return outputs


@app.callback(Output('cadi_data_vis_memory_page', 'data'),
              [Input('cadi_data_vis_div_null', 'n_clicks'), Input('cadi_button_query_data', 'n_clicks')],
              State('cadi_data_vis_memory_page', 'data'))
def refresh_token(_a, _b, dict_data):
    bool_get_token = False
    time_now = str(datetime.now())[:19]
    if dict_data is None:
        bool_get_token = True
    elif len(dict_data) == 0:
        bool_get_token = True
    elif time_now > dict_data['expire']:
        bool_get_token = True

    if not bool_get_token:
        dict_data_output = dict_data
    else:
        dict_chemidp_info = CACHE.app_flask.config['DICT_CHEMIDP_INFO']
        # apim, subscription_key = dict_chemidp_info['apim'], dict_chemidp_info['subscription_key']
        dict_scope = {'odata': dict_chemidp_info['scope_odata'], 'blob': dict_chemidp_info['scope_blob']}

        client_id, client_secret = CACHE.app_flask.config['CLIENT_ID'], CACHE.app_flask.config['CLIENT_SECRET']

        dict_data_output = {}

        url_auth = "https://login.microsoftonline.com/d1ee1acd-bc7a-4bc4-a787-938c49a83906/oauth2/v2.0/token"
        headersList = {"Content-Type": "application/x-www-form-urlencoded"}

        for table in ['odata', 'blob']:
            scope = dict_scope[table]
            payload = f"grant_type=client_credentials&client_id={client_id}&client_secret={client_secret}&scope={scope}"
            response = requests.request("POST", url_auth, data=payload, headers=headersList)
            dict_response = response.json()
            time_now = datetime.now()
            time_expire = time_now + timedelta(seconds=dict_response['expires_in'] - 2)
            dict_data_output[table] = dict_response['access_token']
            dict_data_output['expire'] = time_expire
    return dict_data_output


@app.callback([Output(f'{APPNAME}-search-div-table-batch', 'data'), Output(f'{APPNAME}-search-div-material_display', 'children'),
               Output(f'{APPNAME}-search-div-material_display', 'style'),
               Output('cadi_pop_up_window_data_unavailable', 'displayed'), Output('cadi_pop_up_window_data_unavailable', 'message')],
              [Input('cadi_button_query_data', 'n_clicks')],
              State('cadi_data_vis_memory_page', 'data'), State('cadi_input_batch_no', 'value'))
def refresh_token(_a, dict_data_token, batch_no_input):
    style_hide = {'display': 'none'}
    style_show = {'display': 'block', 'margin-top': '5px', 'margin-bottom': '15px'}
    if 'blob' not in dict_data_token:
        return [], '', style_hide, False, ''
    else:
        token_odata = dict_data_token['odata']

    batch_no = batch_no_input.lstrip('0')

    # Get authentications and headers ready
    dict_chemidp_info = CACHE.app_flask.config['DICT_CHEMIDP_INFO']
    apim, subscription_key = dict_chemidp_info['apim'], dict_chemidp_info['subscription_key']
    payload, token = "", token_odata
    headers = {'Ocp-Apim-Subscription-Key': subscription_key, 'Authorization': f'{token}'}

    # construct command for api request
    requrl = f"{apim}/OData/Generic_Delivery_Header?$top=99&$filter=Batch_Number in ('{batch_no}','{batch_no_input}')&$select=Batch_Number,Reference_Document,Material_Number"
    # print(requrl)
    time_start = time.time()

    # API request for sales order vs. batch
    response = requests.request("GET", requrl, data=payload, headers=headers)
    dict_result_invoice = response.json()
    print(f'Step 1: {round(time.time() - time_start, 1)} s - Qury sales order information')

    pd_invoice = pd.DataFrame(dict_result_invoice['value']).rename(columns={'Reference_Document': 'Sales_Document'})
    if len(pd_invoice) == 0:
        return [], '', style_hide, True, f'No COA file was found for batch {batch_no}'
    pd_invoice = pd_invoice.loc[pd_invoice['Sales_Document'].str[0] == '0']
    if len(pd_invoice) == 0:
        return [], '', style_hide, True, f'No COA file was found for batch {batch_no}'

    # API request for material description
    material_numbers_str = "','".join(list(pd_invoice['Material_Number'].unique()))
    requrl = f"{apim}/OData/ProductFamilyHierarchyMaterial?$top=99&$select=Product_Number,Material_Description&$filter=Product_Number in ('{material_numbers_str}')"
    # print(requrl)

    response = requests.request("GET", requrl, data=payload, headers=headers)
    dict_result_material = response.json()
    print(f'Step 2: {round(time.time() - time_start, 1)} s - query product description')
    pd_material_info = pd.DataFrame(dict_result_material['value']).rename(columns={'Product_Number': 'Material_Number'})

    # Merge dataframes
    pd_invoice_complete = pd_invoice.merge(pd_material_info, on='Material_Number', how='inner')
    pd_invoice_complete = pd_invoice_complete[[i for i in pd_invoice_complete.columns if i not in ['Material_Number']]].drop_duplicates()
    pd_invoice_complete = pd_invoice_complete.rename(columns={
        'Sales_Document': 'SALES_DOCUMENT',
        'Batch_Number': 'BATCH_NUMBER',
        'Material_Description': 'MATERIAL_DESCRIPTION'
    })

    if len(pd_invoice_complete) == 0:
        return [], '', style_hide, True, f'No COA file was found for batch {batch_no}'
    if 1 == 0:
        batch_no_complete = batch_no.rjust(10, '0')
        command = f"""
        select distinct [MATERIAL_DESCRIPTION], [SALES_DOCUMENT] 
        from ChemIDPInvoice 
        where [batch_number] in ('{batch_no_complete}', '{batch_no}')
        
        """
        pd_invoice_complete = CACHE.exe_cloud_sql(command)
    if len(pd_invoice) == 0:
        return [], '', style_hide, True, f'No COA file was found for batch {batch_no}'
    else:
        material_name = pd_invoice_complete.iloc[0]['MATERIAL_DESCRIPTION']
        sales_numbers = list(pd_invoice_complete['SALES_DOCUMENT'].unique())
        sales_document_str = "', '".join(sales_numbers)
        requrl = f"{apim}/OData/ECOMM_DOCU?$filter=ECOMMDOCU_OrderNumber in ('{sales_document_str}') and ECOMMDOCU_DocumentType eq 'COA'&$top=90&" \
                 f"$select=ECOMMDOCU_DocumentNumber,ECOMMDOCU_OrderNumber,ECOMMDOCU_Language,ECOMMDOCU_OutputDateTime"
        # print(requrl)
        payload, token = "", token_odata
        headers = {'Ocp-Apim-Subscription-Key': subscription_key, 'Authorization': f'{token}'}
        response = requests.request("GET", requrl, data=payload, headers=headers)
        dict_result = response.json()
        print(f'Step 3: {round(time.time() - time_start, 1)} s - Query Shipment and language information')
        if 'value' not in dict_result:
            return [], '', style_hide, True, f'No COA file was found for batch {batch_no}'
        elif len(dict_result['value']) == 0:
            return [], '', style_hide, True, f'No COA file was found for batch {batch_no}'
        else:
            dict_rename = {'ECOMMDOCU_OrderNumber': 'Sales Order',
                           'ECOMMDOCU_Language': 'Language',
                           'ECOMMDOCU_OutputDateTime': 'Document Time',
                           'ECOMMDOCU_DocumentNumber': 'Ship No.'}
            pd_api = pd.DataFrame(dict_result['value']).rename(columns=dict_rename)
            pd_api['Document Time'] = pd_api['Document Time'].astype(str).str[:10]
            pd_api = pd_api.sort_values(by='Document Time')
            # pd_api = pd_api[list(dict_rename.values())]
            show_div = html.Div([
                html.Div('Material:', style={'width': '80px', 'min-width': '80px', 'margin-top': '3px', 'margin-right': '10px'}),
                dcc.Input(value=material_name, disabled=True, style={'width': '100%', 'margin-right': '10px'})
            ],
                style={'display': 'flex'}
            )
            # print(pd_api.to_dict('record'))
            return pd_api.to_dict('record'), show_div, style_show, False, ''


@app.callback(Output(f'cadi_frame_pdf', 'src'),
              Input(f'{APPNAME}-button-get_pdf', 'n_clicks'),
              State(f'{APPNAME}-search-div-table-batch', 'data'), State(f'{APPNAME}-search-div-table-batch', 'selected_rows'),
              State('cadi_data_vis_memory_page', 'data'))
def refresh_token(_a, data_input, row_ids, dict_data_token):

    if _a is None:
        return ''
    elif _a == 0:
        return ''
    elif row_ids is None:
        return ''
    elif len(row_ids) == 0:
        return ''
    else:
        pd_data = pd.DataFrame(data_input)
        pd_entry = pd_data.iloc[row_ids[0]]
        shipment_num = pd_entry['Ship No.']
        language = pd_entry['Language']

        token_odata = dict_data_token['blob']
        dict_chemidp_info = CACHE.app_flask.config['DICT_CHEMIDP_INFO']
        apim, subscription_key = dict_chemidp_info['apim'], dict_chemidp_info['subscription_key']

        requrl = f"{apim}/PDF/eCOMM?DOC_NUMBER={shipment_num}&TYPE=COA&LANGUAGE={language}"
        payload, token = "", token_odata
        headers = {'Ocp-Apim-Subscription-Key': subscription_key, 'Authorization': f'{token}'}
        response = requests.request("GET", requrl, data=payload, headers=headers)
        if response.text[:20] == '{ "statusCode": 401,':
            return ''
        else:
            time_now = datetime.utcnow()
            time_now_str = str(time_now).replace('-', '').replace(':', '').replace(' ', '_')[:19]
            time_remove = datetime.utcnow() - timedelta(seconds=3600)
            time_remove_str = str(time_remove).replace('-', '').replace(':', '').replace(' ', '_')[:19]
            files = glob.glob(f'{CACHE.DIR}/assets/CADI-COA-OUTPUT-*.pdf')
            files_remove_str = f'CADI-COA-OUTPUT-{time_remove_str}.pdf'
            files_remove = [i for i in files if os.path.basename(i) <= files_remove_str]
            if len(files_remove) > 0:
                for file_revmoe in files_remove:
                    os.remove(file_revmoe)

            filepath = f'{CACHE.DIR}/assets/CADI-COA-OUTPUT-{time_now_str}.pdf'
            with open(filepath, 'wb') as f:
                f.write(response.content)
            return f'assets/CADI-COA-OUTPUT-{time_now_str}.pdf'
