# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from app_main.dataiku_apps.lib.main_lib import CACHE

from dash.dependencies import Input, Output
from dash import html
import base64


padding_paragraph = '5px'
dict_href_style = {}

app = CACHE.app

div_project_background = html.Div(
    children=[
        html.Div(id='lot_record_project_background_null'),
        html.Div(
            children=[
                # html.Img(src='', id='lot_record_image_project_background')
                #html.Video(controls=True, src='data:video/mp4;base64,{}'.format(encoded_video_1.decode()))
            ],
            style={'padding-top': padding_paragraph}
        ),
    ],
    style={'margin-top': '40px', 'margin-left': '60px', 'width': '750px', 'minWidth': '450px'}
)

if 1 == 0:
    @app.callback(Output('fet_brpp_image_project_background', 'src'),
                  Input('project_brpp_background_null', 'n_clicks'))
    def update_image(_a):
        path_image = f'{CACHE.DIR_DATA}/image/BRPO-L2.PNG'
        encoded_image = base64.b64encode(open(path_image, 'rb').read())
        return 'data:image/png;base64,{}'.format(encoded_image.decode())
