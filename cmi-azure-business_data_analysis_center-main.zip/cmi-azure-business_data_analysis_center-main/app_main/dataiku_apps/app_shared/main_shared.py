# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from app_main.dataiku_apps.lib.main_lib import CACHE

app = CACHE.app

