# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com
from app_main.dataiku_apps.lib.main_lib import CACHE, ProcessStl
from dash.dependencies import Input, Output, State
from dash import html, dcc, callback_context
from dash.exceptions import PreventUpdate
import base64, io
import pandas as pd
import numpy as np
from stl import mesh
import plotly.graph_objects as go


app = CACHE.app

APPNAME = '3d_print-model_design'

DROPDOWN_WIDTH = 350
PAGE_SIZE = 15
TAB_HEIGHT = '46px'
stl_handle = ProcessStl()

padding_paragraph = '5px'
dict_href_style = {}
MIN_THICKNESS = 0.3


def stl2mesh3d(stl_mesh):
    # stl_mesh is read by nympy-stl from a stl file; it is  an array of faces/triangles (i.e. three 3d points)
    # this function extracts the unique vertices and the lists I, J, K to define a Plotly mesh3d
    p, q, r = stl_mesh.vectors.shape #(p, 3, 3)
    # the array stl_mesh.vectors.reshape(p*q, r) can contain multiple copies of the same vertex;
    # extract unique vertices from all mesh triangles
    vertices, ixr = np.unique(stl_mesh.vectors.reshape(p*q, r), return_inverse=True, axis=0)
    I = np.take(ixr, [3*k for k in range(p)])
    J = np.take(ixr, [3*k+1 for k in range(p)])
    K = np.take(ixr, [3*k+2 for k in range(p)])
    return vertices, I, J, K
# ---------------------------------------------------------------------------------------------------------------

dict_content = {
    'search-tab': ['Operation', 'Introduction'],
    'search-button': [
        ['This functionality converts surface information in XYZ format into printable STL model:', 'Text'],
        ['Upload Data File', 'Upload'],
        ['Minimum Height (mm): ', 'Input', {'placeholder': str(MIN_THICKNESS), 'type': 'number'}],
        ['Download Example Data File', 'Download'],
        ['Download Example STL File', 'Download'],
        ['Download STL File', 'Download'],
    ],
    'vis-button': [],
    'vis-tab': {'Operation': ['STL 3D'],
                'Introduction': ['Introduction']},
}


tab_pad_top, tab_pad_bottom = 13, 13
tab_style = {'padding-top': f'{tab_pad_top}px', 'padding-bottom': f'{tab_pad_bottom}px'}
tab_classname_default = 'w3-bar-item w3-button w3-mobile'
tab_classname_highlight = 'w3-bar-item w3-button w3-red w3-mobile'

search_tabs = dict_content['search-tab']
div_search_tabs = html.Div(
    children=[
                 html.A(className=tab_classname_highlight, children=search_tabs[0], id=f'{APPNAME}-search-tab-0', style=tab_style),
             ] + [
                 html.A(className=tab_classname_default, children=search_tabs[i + 1], id=f'{APPNAME}-search-tab-{i + 1}', style=tab_style)
                 for i in range(len(search_tabs) - 1)
             ],
    id=f'{APPNAME}-search-tabs', className='w3-white',
    style={'margin-top': '0px', 'padding-left': '0px', 'margin-right': '10px', 'margin-left': '10px'}
)


search_tab_0 = dict_content['search-tab'][0]
vis_tabs = dict_content['vis-tab'][search_tab_0]
div_vis_tabs = html.Div(
    children=[
                 html.A(className=tab_classname_highlight, children=vis_tabs[0], id=f'{APPNAME}-vis-tab-0', style=tab_style),
             ] + [
                 html.A(className=tab_classname_default, children=vis_tabs[i + 1], id=f'{APPNAME}-vis-tab-{i + 1}', style=tab_style)
                 for i in range(len(vis_tabs) - 1)
             ],
    id=f'{APPNAME}-tab_vis', className='w3-bar w3-white',
    style={'margin-top': '0px', 'padding-left': '0px'}
)


def generate_button_sections(id_pre, button_info_list):
    button_sec_children = []
    for i_button, button_info in enumerate(button_info_list):
        if type(button_info) is str:
            button_sec = html.Div(html.Button(button_info, id=f'{id_pre}-{i_button}'))
        elif type(button_info) is list:
            if button_info[1] == 'Upload':
                button_sec = html.Div(dcc.Upload(
                    id=f'{id_pre}-Upload-{i_button}',
                    children=[
                        html.Div(f'{button_info[0]}', style={'margin-top': '-10px'})
                    ],
                    style={
                        'width': '100%',
                        'height': '60px',
                        'lineHeight': '60px',
                        'borderWidth': '1px',
                        'borderStyle': 'dashed',
                        'borderRadius': '5px',
                        'textAlign': 'center',
                        'margin-top': '10px',
                        'margin-bottom': '10px',
                        'margin-right': '10px'
                    },
                    className='w3-button'
                ))
            else:
                if button_info[1] == 'Download':
                    button_func = dcc.Download(id=f'{id_pre}-Download-{i_button}')
                    button_sec = html.Div(
                        children=[
                            html.Button(button_info[0], id=f'{id_pre}-Button-{i_button}'),
                            button_func
                        ],
                        style={'margin-bottom': '10px'}
                    )
                elif button_info[1] == 'Input':
                    element_input = dcc.Input(id=f'{id_pre}-Input-{i_button}',)
                    if len(button_info) > 2:
                        dict_attrs = button_info[2]
                        for key in dict_attrs:

                            element_input.__setattr__(key, dict_attrs[key])
                    button_sec = html.Div(
                        children=[
                            html.Div(button_info[0], style={'margin-top': '3px'}),
                            element_input,
                        ],
                        style={'display': 'flex', 'margin-bottom': '10px'})
                elif button_info[1] in ['Text', 'Div']:
                    button_sec = html.Div(button_info[0], style={'margin-bottom': '10px'})
                else:
                    raise ValueError(f'Not able to identify the type of button function: {button_info[1]}')
        else:
            raise ValueError(f'Type of button_info_list can only be either str or list, recieved type: {type(button_info)}')

        button_sec_children.append(button_sec)
    return button_sec_children


div_search_buttons = html.Div(
    id=f'{APPNAME}-search-button-sec',
    children=generate_button_sections(id_pre=f'{APPNAME}-search-button', button_info_list=dict_content['search-button']),
    style={'margin-top': '10px', 'margin-bottom': '10px'}
)

div_vis_buttons = html.Div(
    id=f'{APPNAME}-vis-button-sec',
    children=generate_button_sections(id_pre=f'{APPNAME}-vis-button', button_info_list=dict_content['vis-button']),
    style={'margin-top': '10px', 'margin-bottom': '10px'}
)


div_query_display_switch = html.Button(
    children=[
        html.A(className='far fa-eye-slash', id=f'{APPNAME}-search-display_switch_icon'),
        html.A(' Hide queries', id=f'{APPNAME}-search-display_switch_text'),
    ],
    style={'width': '150px', 'height': TAB_HEIGHT, 'margin-right': '10px'},
    id=f'{APPNAME}-search-display_switch')


div_main_display = html.Div(id=f'{APPNAME}-div_main_display', children=[])


div_data_visualization_filters = html.Div(
    children=[
        div_search_tabs,
        html.Div(
            children=div_search_buttons,
            className='w3-light-grey',
            style={'padding-left': '15px', 'padding-right': '15px', 'margin-top': '10px'}
        ),
    ]
)

div_3d_model_design = html.Div([
    dcc.Store(id=f'{APPNAME}-data_vis_memory_page', storage_type='memory'),
    dcc.Store(f'{APPNAME}-data_search_memory_data', storage_type='memory', data={'ind': 0}),
    dcc.Store(f'{APPNAME}-data_vis_memory_data', storage_type='memory', data={'ind': 0}),
    dcc.ConfirmDialog(f'{APPNAME}-pop_up_window_data_unavailable', message=''),
    html.Div(id=f'{APPNAME}-div_null'),
    html.Div([
        html.Div(
            id=f'{APPNAME}-query_filter',
            className='w3-col s4',
            children=[
                div_data_visualization_filters,
                dcc.Loading(
                    id=f'{APPNAME}-loading_main_data',
                    children=[
                        dcc.Store(f'{APPNAME}-data_memory_file_upload', storage_type='memory', data={}),
                    ],
                ),
            ], style={'border-right': '8px solid #ffffff'}
        ),
        html.Div(
            id=f'{APPNAME}-main_display',
            className='w3-col s8',
            children=[
                html.Div([
                    div_query_display_switch,
                    div_vis_tabs,
                ], style={'display': 'flex'}),
                div_vis_buttons,
                div_main_display,
        ], style={'padding-left': '10px'}),

    ], className='w3-row'),
])


@app.callback([Output(f'{APPNAME}-query_filter', 'style'), Output(f'{APPNAME}-main_display', 'className'),
               Output(f'{APPNAME}-search-display_switch_icon', 'className'), Output(f'{APPNAME}-search-display_switch_text', 'children')],
               Input(f'{APPNAME}-search-display_switch', 'n_clicks'))
def update_query_display_show_hide(_a):
    if _a is None:
        raise PreventUpdate
    if _a % 2 == 1:
        thisapp_search_display_switch_icon_classname = 'far fa-eye'
        thisapp_search_display_switch_text = ' Show queries'
        thisapp_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'none'}
        thisapp_main_display_classname = 'w3-col '
    else:
        thisapp_search_display_switch_icon_classname = 'far fa-eye-slash'
        thisapp_search_display_switch_text = ' Hide queries'
        thisapp_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'block'}
        thisapp_main_display_classname = 'w3-col s8'
    output = [thisapp_query_filter_style, thisapp_main_display_classname, thisapp_search_display_switch_icon_classname,
              thisapp_search_display_switch_text]
    return output


@app.callback([Output(f'{APPNAME}-data_memory_file_upload', 'data'),
               Output(f'{APPNAME}-pop_up_window_data_unavailable', 'displayed'), Output(f'{APPNAME}-pop_up_window_data_unavailable', 'message')],
              Input(f'{APPNAME}-search-button-Upload-1', 'contents')
              )
def parse_input_xyz_file(content_binary):
    trigger = callback_context.triggered[0]
    if (type(trigger) is dict) & (content_binary is not None):
        _ind = content_binary.index(',')
        content_string = content_binary[_ind + 1:]
        decoded = base64.b64decode(content_string)

        content = decoded.decode('utf-8')

        message = None
        columns_line = content[:100].split('\n')[0]
        if ',' in columns_line:
            sep = ','
        elif '\t' in columns_line:
            sep = '\t'
        elif ';' in columns_line:
            sep = ';'
        else:
            message = 'Not able to identify the seperator of the file.'
            sep = ','

        if message is None:
            if 'x' in columns_line.lower():
                pd_data = pd.read_csv(io.StringIO(content), sep=sep)
                columns = sorted(columns_line.split(sep))
                rename = {columns[0]: 'x', columns[1]: 'y', columns[2]: 'z'}
                pd_data = pd_data.rename(columns=rename)
            else:
                pd_data = pd.read_csv(io.StringIO(content), header=None, sep=sep)
                pd_data.columns = ['x', 'y', 'z']
            pd_data = stl_handle.preprocess_model(pd_data)


            return {'decoded': pd_data.to_dict('record')}, False, ''
        else:
            return {}, True, message
    else:
        return {}, False, ''


@app.callback(Output(f'{APPNAME}-search-button-Download-3', 'data'),
              Input(f'{APPNAME}-search-button-Button-3', 'n_clicks'))
def download_stl_file(_):
    trigger = callback_context.triggered[0]
    if (type(trigger) is dict) & (_ is not None):
        if _ > 0:
            filename = f'{CACHE.DIR}/assets/PMEEC-example.csv'
            return dcc.send_file(filename)
        raise PreventUpdate
    else:
        raise PreventUpdate


@app.callback(Output(f'{APPNAME}-search-button-Download-4', 'data'),
              Input(f'{APPNAME}-search-button-Button-4', 'n_clicks'))
def download_stl_file(_):
    if _ is not None:
        if _ > 0:
            filename = f'{CACHE.DIR}/assets/PMEEC-Example.stl'
            return dcc.send_file(filename)
        raise PreventUpdate
    else:
        raise PreventUpdate


@app.callback(Output(f'{APPNAME}-search-button-Download-5', 'data'),
              Input(f'{APPNAME}-search-button-Button-5', 'n_clicks'),
              State(f'{APPNAME}-data_memory_file_upload', 'data'))
def download_stl_file(_, data_input):
    trigger = callback_context.triggered[0]
    if (type(trigger) is dict) & (len(data_input) > 0):
        filename = f'{CACHE.DIR}/assets/PMEEC-Output.stl'
        return dcc.send_file(filename)
    else:
        raise PreventUpdate


@app.callback(Output(f'{APPNAME}-div_main_display', 'children'),
              [Input(f'{APPNAME}-data_memory_file_upload', 'data'), Input(f'{APPNAME}-div_null', 'n_clicks')],
              State(f'{APPNAME}-search-button-Input-2', 'value')
              )
def generate_stl_model(data_input, _, min_thickness):
    if len(data_input) > 0:
        filename = f'{CACHE.DIR}/assets/PMEEC-Output.stl'

        if min_thickness is None:
            min_thickness = MIN_THICKNESS

        pd_data = pd.DataFrame(data_input['decoded'])
        pd_data['z'] = pd_data['z'] - pd_data['z'].min() + min_thickness
        if min_thickness is None:
            min_thickness = MIN_THICKNESS
        facets = stl_handle.get_stl(pd_data, min_thickness)

        stl_handle.write_stl(facets, filename)
    else:
        filename = f'{CACHE.DIR}/assets/PMEEC-Example.stl'


    my_mesh = mesh.Mesh.from_file(filename)
    vertices, I, J, K = stl2mesh3d(my_mesh)
    x, y, z = vertices.T
    colorscale = [[0, '#e5dee5'], [1, '#e5dee5']]
    mesh3D = go.Mesh3d(x=x, y=y, z=z, i=I, j=J, k=K,
                       flatshading=True, colorscale=colorscale, intensity=z, name='AT&T', showscale=False)

    fig = go.Figure(data=[mesh3D])

    fig.data[0].update(lighting=dict(
        ambient=0.18,
        diffuse=1,
        fresnel=.1,
        specular=1,
        roughness=.1,
        facenormalsepsilon=0))
    fig.data[0].update(lightposition=dict(x=3000, y=3000, z=10000))
    fig.update_layout(margin={'l': 100, 'r': 20, 't': 35, 'b': 55})
    graph = dcc.Graph(figure=fig, style={'margin-bottom': '5px', 'height': '600px', 'width': '100%'})
    return graph