# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com
from dash import html, dcc, callback_context, dash_table
import base64
from app_main.dataiku_apps.lib.main_lib import CACHE, LABEL_SYSTEM

padding_paragraph = '5px'
dict_href_style = {}
DIR = CACHE.DIR

dict_icon = {
    'keychain': f'https://matdbstorage.blob.core.windows.net/yunsong-test/3d_printing-keychain.png?sp=r&st=2022-09-19T18:31:56Z&se=2222-09-20T02:31:56Z&sv=2021-06-08&sr=b&sig=HL%2BhlwW7%2FF%2BBwIX0QZcqBqbAUJ3lWMriO1DE6glboCI%3D',
}

dict_image = {
    i: 'data:image/jpg;base64,{}'.format(base64.b64encode(open(dict_icon[i], 'rb').read()).decode())
    if dict_icon[i][:4] != 'http' else dict_icon[i] for i in dict_icon
}

div_read_me = html.Div(children=[
    html.Div([html.B('Date: '), 'September 16, 2022']),
    html.Div([html.B('Revision: '), '2']),
    html.H5([html.B('Polyolefin Material Experience Enhancement Center')], style={'text-align': 'center'}),
    html.Div([html.B('Management Support: '), 'Ting Chen'],
             style={'text-align': 'center'}),
    html.Div([html.B('Developer: '), 'Yunsong Xie'], style={'text-align': 'center'}),
    html.Br(),
    html.Div([html.B('Executive summary ')], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),
    html.Div([
        "After a year of continuously working with business, technology and public affair collegues to broaden the impact of 3D printing. "
        "It has been found that there is significant internal interest in using 3D printed keychain as a tool to enhance the material experience. "
        "Traditional the way of explaining the visual/functional properties of ExxonMobil materials uses rasins, of course when explaining to "
        "audiance with specific application of interest, fully processed speciman is used e.g. injection molded parts or film. 3D printing, on the "
        "hand, offers a completely different way how illustrate how polyolefin materials could look or feel like. Comparing to rasins, it provides "
        "an actual finished parts that more closely relate to daily life. Comparing to injection molding or filming, it is able process a lot more "
        "materials in a consistant process."
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div([
        'While we will continue to support the 3D-printing market exploration, we proudly repurpose this online tool to be '
        '"Polyolefin Material Experience Enhancement Center (PMEEC)" that focuses on fulfilling both internal and, in the future, external needs of '
        'using 3D printed ExxonMobil material keychain to enhance of material experient. Visitors can simply go to link below to '
        'obtain the keychain shown in the picture.'
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.B(children=[
        html.A('Request PMEEC Keychain', href='')
    ],
        style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph},
        className='w3-center'),

    html.Div(children=[
        html.Img(src=dict_image['keychain'],
                 style={'text-align': 'right', 'margin-right': '5px', 'margin-top': '10px', 'height': '350px'}),
    ], className='w3-center',),

    html.Div([
        "-----------------------------------------------------------------------------------------------------------------------------------"
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div([html.B('Date: '), 'September 1, 2021']),
    html.Div([html.B('Revision: '), '1']),
    html.H5([html.B('Polyolefins for 3D Printing in ExxonMobil')], style={'text-align': 'center'}),
    html.Div([html.B('Management Support: '), 'Robert Li, Jeanne Macdonald, Derek Thurman, Saifudin Abubakar'],
             style={'text-align': 'center'}),
    html.Div([html.B('Developer: '), 'Ru Xie, Peijun Jiang'], style={'text-align': 'center'}),
    html.Br(),
    html.Div([html.B('Executive summary ')], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),
    html.Div([
        "3D printing or additive manufacturing is an emerging manufacturing technology, which allows for "
        "direct transformation of 3D digital data into a three dimensional object. 3D printing presents an attractive "
        "opportunity for ExxonMobil Chemical to both grow its bulk polymer sales and mitigate risk that 3D printing "
        "poses to disrupt traditional plastic product fabrication supply chain. Plastics used in 3D printing will "
        "grow to 49,000 MT by 2025, which is projected to be about $880 million market."
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div([
        "Since 2018, the team established and commissioned the 3D printing capability in both Shanghai "
        "Technology Center (STC) and Baytown Technology & Engineering Complex (BTEC)  through paralleled "
        "developments in material, instruments, and software. We have successfully 3D printed various ExxonMobil "
        "polymer families, including polyethylene (PE), polypropylene (PP), Vistamaxx",
        html.Sup("TM"),
        " performance polymers, Exact",
        html.Sup("TM"),
        " plastomers, specialty elastomers (CoC, Escorene, Exxelor, Vistalon), etc. using "
        "Fused Deposition Modeling technique. As a result, we have also identified existing commercial "
        "ExxonMobil polyolefin grades that are readily to be used in 3D printing market, and created an "
        "IP strategic portfolio to capture all the inventive knowledge learnt from each of the polymer "
        "families. The list of patents and report could be found in the Resource section.  "
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div([
        "On the basis of the completion of all the fundamental proof of concept work, and in support of company’s "
        "commitment to earning growth through rapid technology innovation and efficiency, we organized two business "
        "alignment meetings with Research (including STC and BTEC), New Product Platform, Competitive Intelligence, "
        "Product Development, Customer and Application Development, New Segment ADT, 3D Printing Network, and "
        "Megatrend Strategy Portfolio members. The goals of the business alignment meetings are to understand "
        "ExxonMobil’s business strategy on 3D printing, or additive manufacturing. The specific questions that we "
        "are seeking answers for are “What are our company’s business strategy on 3D printing?” “What product markets "
        "do we want to get in? Is it automotive, constructions, specialty, commodity market or some new markets?” "
        "“Can our current existing ExxonMobil polymers satisfy the specific product and market needs? Or do we need "
        "to invent new polymers for the target markets?” and so on. "
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),


    html.Div([
        "The 1st Business Alignment meeting was organized on August 16, 2019. The goal of this meeting is to (1) "
        "get to know the various internal technical and business efforts that have been done on Polyolefins for "
        "3D printing; (2) understand company’s business strategy on 3D printing if any. The outcomes of this meeting "
        "were to (1) have technical members continue product and application development for ExxonMobil polymer "
        "portfolio and establish patent portfolio; (2) ask business members to scout the outlook of the 3D printing "
        "markets, potential customers/product targets, and establish an understanding of the business strategy. "
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div([
        "The 2nd Business Alignment meeting was organized on October 28, 2019. The goal of this meeting was to catch "
        "up and update the follow-ups from the 1st Business Alignment meeting. The outcome of this meeting was to "
        "organize a “Polymer 3D Printing Workshop” in 1st quarter 2020 to (1) learn about current state-of-the-art "
        "of 3D printing efforts across the company; (2) ask (and hopefully answer) the questions about the "
        "significance of 3D printing for our polyolefins’ current and future. "
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div([
        "In 2021, to promote innovation, develop others, and focus on customers, we are very excited to create this "
        "Additive Manufacturing Customer Development Tool (AM CDT). In this CDT, we summarized the filament fabrication "
        "parameters, 3D printing parameters used in Fused Deposition Modeling, and mechanical properties data measured "
        "from the printed parts. We also showcased comparative data measured from injection molding. We also provide "
        "a list of recommendations for potential applications. "
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div([
        "For all the users of this CDT, please do not hesitate to contact us if you have any feedbacks! Thank you!"
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

], style={'margin-top': '0px', 'margin-left': '60px', 'width': '850px', 'minWidth': '450px'})
