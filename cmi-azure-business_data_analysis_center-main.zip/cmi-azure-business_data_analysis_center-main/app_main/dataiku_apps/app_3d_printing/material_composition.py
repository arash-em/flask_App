# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com
from dash import html, dash_table
import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import pandas as pd

pd.set_option("display.max_row", 25)
pd.set_option("display.max_column", 35)
pd.set_option("display.max_colwidth", 40)
pd.set_option("display.width", 300)


from app_main.dataiku_apps.lib.main_lib import CACHE, DICT_DATA
app = CACHE.app


pd_component = DICT_DATA['material_composition_cleaned'].copy()
component_cols = list(DICT_DATA['material_composition_cleaned'].columns)
component_cols_multi = [('', i) for i in component_cols[:2]] + [(i.split(' ')[0] + ' Component',
                                                                 i.split(' ')[1]) for i in component_cols[2:]]
# pd_component.columns = component_cols_multi
div_material_composition = html.Div(
    id='div_table_component', children=[
        html.Br(),
        dash_table.DataTable(
            id='table_component',
            columns=[{'name': component_cols_multi[i], 'id': component_cols[i]} for i in range(len(component_cols))],
            data=pd_component.to_dict('record'),
            style_table={'overflowX': 'auto', 'minWidth': '650px', 'maxWidth': CACHE.max_width, 'lineHeight': '15px'},
            style_cell={'height': 'auto', 'whiteSpace': 'normal'},
            style_header={'backgroundColor': 'rgb(210, 210, 210)', 'color': 'black', 'fontWeight': 'bold',
                          'border': '1px solid black'},
            style_data_conditional=[{'if': {'row_index': 'odd'}, 'backgroundColor': 'rgb(220, 220, 220)'}],
            style_cell_conditional=[
                {'if': {'column_id': 'Material Type'}, 'width': '120px', 'minWidth': '60px', 'maxWidth': '120px'},
                {'if': {'column_id': '1st Percentage'}, 'width': '100px', 'minWidth': '50px', 'maxWidth': '150px'},
                {'if': {'column_id': '2nd Percentage'}, 'width': '100px', 'minWidth': '50px', 'maxWidth': '150px'},
                {'if': {'column_id': '3rd Percentage'}, 'width': '100px', 'minWidth': '50px', 'maxWidth': '150px'},
                {'if': {'column_id': '1st Polymer'}, 'width': '120px', 'minWidth': '50px', 'maxWidth': '175px'},
                {'if': {'column_id': '2nd Polymer'}, 'width': '120px', 'minWidth': '50px', 'maxWidth': '175px'},
                {'if': {'column_id': '3rd Polymer'}, 'width': '120px', 'minWidth': '50px', 'maxWidth': '175px'},
            ],
            style_data={'border': '1px solid black'},
            editable=True,
            filter_action="native",
            sort_action="native",
            sort_mode='multi',
        )
    ],
    style={'padding-top': '50px', 'padding-left': '60px',
           'maxWidth': '1250px', 'minWidth': '300px'}
)

div_polymer_property = html.Div([
    html.Br(),
    dash_table.DataTable(
        id='table_polymer_property',
        columns=[{'name': i, 'id': i} for i in DICT_DATA['polymer_property'].keys()
                 if i != 'polymer_id'],
        data=DICT_DATA['polymer_property'][[i for i in DICT_DATA['polymer_property'] if i != 'polymer_id']].to_dict('record'),
        style_table={'overflowX': 'auto', 'minWidth': '700px',
                     'maxWidth': '1255px', 'lineHeight': '15px'},
        style_cell={'height': 'auto', 'whiteSpace': 'normal'},
        style_data={'color': 'black', 'backgroundColor': 'white', 'border': '1px solid black'},
        style_data_conditional=[{'if': {'row_index': 'odd'}, 'backgroundColor': 'rgb(220, 220, 220)'}],
        style_header={'backgroundColor': 'rgb(210, 210, 210)', 'color': 'black', 'fontWeight': 'bold',
                      'border': '1px solid black'},
        style_cell_conditional=[{'if': {'column_id': 'Polymer Name'}, 'width': '120px', 'maxwidth': '145px'},
                                {'if': {'column_id': 'Melt Index'}, 'width': '50px', 'minWidth': '50px', 'maxWidth': '75px'},
                                {'if': {'column_id': 'Density'}, 'width': '40px', 'minWidth': '30px', 'maxWidth': '60px'},
                                {'if': {'column_id': 'MFR'}, 'width': '50px', 'minWidth': '50px', 'maxWidth': '75px'},
                                {'if': {'column_id': 'Ethylene Content'}, 'width': '60px', 'minWidth': '50px', 'maxWidth': '65px'},
                                {'if': {'column_id': 'Mooney Viscosity'}, 'width': '60px', 'minWidth': '50px', 'maxWidth': '65px'},
                                {'if': {'column_id': 'Vinyl Acetate Content'}, 'width': '60px', 'minWidth': '50px', 'maxWidth': '65px'},
                                {'if': {'column_id': 'Grafting Level'}, 'width': '60px', 'minWidth': '50px', 'maxWidth': '65px'},
                                {'if': {'column_id': 'Noborene content'}, 'width': '60px', 'minWidth': '50px', 'maxWidth': '65px'},
                                {'if': {'column_id': 'Cv'}, 'width': '35px', 'minWidth': '30px', 'maxWidth': '45px'},
                                {'if': {'column_id': 'Gv'}, 'width': '35px', 'minWidth': '30px', 'maxWidth': '45px'},
                                {'if': {'column_id': 'Tc'}, 'width': '35px', 'minWidth': '30px', 'maxWidth': '45px'},
                                {'if': {'column_id': 'Tm'}, 'width': '35px', 'minWidth': '30px', 'maxWidth': '45px'},
                                {'if': {'column_id': 'Mw'}, 'width': '35px', 'minWidth': '30px', 'maxWidth': '45px'}, ],
        editable=True,
        filter_action="native",
        sort_action="native",
        sort_mode='multi',
    )
],
    id='div_polymer_property',
    style={'padding-top': '50px', 'padding-left': '60px',
           'maxWidth': '1250px', 'minWidth': '300px', 'align-content': 'space-evenly', }
)
