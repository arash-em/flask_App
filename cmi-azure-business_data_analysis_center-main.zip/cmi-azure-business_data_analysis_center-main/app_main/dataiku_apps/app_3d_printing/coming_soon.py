# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from dash import html



padding_paragraph = '5px'
dict_href_style = {}

div_coming_soon = html.Div(
    children=[
        html.Div(
            html.H4(
                html.B("Coming soon. We is actively working on it")
            ), style={'padding-top': padding_paragraph}
        ),
    ],
    style={'margin-top': '40px', 'margin-left': '60px', 'width': '750px', 'minWidth': '450px'}
)

