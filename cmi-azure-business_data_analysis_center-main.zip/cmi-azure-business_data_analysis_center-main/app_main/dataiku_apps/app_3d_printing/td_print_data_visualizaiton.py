# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com
from dash import html, dcc, callback_context, dash_table
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dash.dependencies import Input, Output, State
import numpy as np
import plotly.express as px

#from ...lib.main_lib import CACHE, DICT_DATA
from app_main.dataiku_apps.lib.main_lib import CACHE, DICT_DATA

app = CACHE.app

DROPDOWN_WIDTH = 350
GRAPH_WIDTH_COMBINE = 850
GRAPH_WIDTH_INDIVIDUAL = 1200

CACHE.dict_activity_store['tab_main_material_visual'] = 'button_combined_spider_chart'
pd_unit = DICT_DATA['unit']
properties = ['1%_Secant_Modulus', 'youngs_modulus', 'tensile_stress_at_yield', 'tensile_stress_at_break', 'strain_at_break', 'flex_modulus']
DICT_UNIT = {i: pd_unit.loc[pd_unit['properties'] == i].iloc[0]['Unit'] for i in properties}
DICT_MAX = DICT_DATA['post_manufacturing_property'][properties].quantile(0.935).round(2).to_dict()


DICT_VISUAL = {'button_combined_spider_chart':
                   dcc.Graph(id="chart_material_spider_combine", className='w3-light-grey'),
               'button_individual_spider_chart':
                   dcc.Graph(id="chart_material_spider_individual", className='w3-light-grey'),
               'button_bar_chart':
                   dcc.Graph(id="chart_material_bar", className='w3-light-grey'),
               'button_printing_condition':
                   html.Div([
                       html.A('Note: Only FDM materials are shown in this table',
                              style={'margin-bottom': '5px', 'text-align': 'right', 'font-size': '13px'}),
                       dash_table.DataTable(
                           id='table_printing_condition',
                           columns=[{'name': 'Process Type', 'id': 'Process Type'}, {'name': 'Item', 'id': 'Item'}] +
                                   [{'name': 'TBD', 'id': f'material_{i}'} for i in range(1, 5)],
                           data=[{}],
                           style_table={'overflowX': 'auto', 'minWidth': '500px', 'maxWidth': CACHE.max_width, 'lineHeight': '15px'},
                           style_cell_conditional=[
                               {'if': {'column_id': 'Process Type'}, 'width': '105px', 'minWidth': '75px', 'maxWidth': '115px'},
                               {'if': {'column_id': 'Item'}, 'width': '175px', 'minWidth': '120px', 'maxWidth': '190px'},
                               ],
                           style_cell={'height': 'auto', 'whiteSpace': 'normal'},
                           style_header={'backgroundColor': 'rgb(210, 210, 210)', 'color': 'black', 'fontWeight': 'bold',
                                         'border': '1px solid black', 'whiteSpace': 'normal'},
                           style_data={'border': '1px solid black'}, editable=True
                       ),
                   ]),
               }


div_data_visualization_tabs = html.Div(
    children=[
        html.A(className='w3-bar-item w3-button w3-red w3-mobile',
               children=["Combined Spider Chart"],
               id='button_combined_spider_chart', style={'padding-top': '20px', 'padding-bottom': '20px'},
               ),
        html.A(className='w3-bar-item w3-button w3-mobile', children=[
            "Individual Spider Chart"
        ], id='button_individual_spider_chart', style={'padding-top': '20px', 'padding-bottom': '20px'}),

        html.A(className='w3-bar-item w3-button w3-mobile', children=[
            "Bar Chart"
        ], id='button_bar_chart', style={'padding-top': '20px', 'padding-bottom': '20px'}),
        html.A(className='w3-bar-item w3-button w3-mobile', children=[
            "Printing Condition"
        ], id='button_printing_condition', style={'padding-top': '20px', 'padding-bottom': '20px'}),
    ], className='w3-bar w3-white w3-large',  style={'margin-top': '0px', 'padding-left': '0px'})


div_data_visualization_filters = html.Div(
    children=[
        html.Div(children=[
            html.H5('Select materials of interest', style={}),
            dcc.Dropdown(id='dropdown_material_type',
                         options=[{'label': _, 'value': _} for _ in sorted(DICT_DATA['material']['material_type'].unique())],
                         placeholder='Filter Material Type',
                         style={'width': f'{DROPDOWN_WIDTH}px', 'margin-top': '10px'}, ),
            dcc.Dropdown(id='dropdown_material',
                         options=[{'label': _, 'value': _} for _ in
                                  list(DICT_DATA['post_manufacturing_property']['material_name'].unique())],
                         placeholder='Filter Material',
                         style={'width': f'{DROPDOWN_WIDTH}px', 'margin-top': '10px'}),
            dcc.Dropdown(id='dropdown_process_method',
                         options=[{'label': _, 'value': _} for _ in
                                  ['Both'] + sorted(DICT_DATA['post_manufacturing_property']['process_type'].unique())],
                         placeholder='Filter Process Type',
                         style={'width': f'{DROPDOWN_WIDTH}px', 'margin-top': '10px'}),

            html.Div(children=[
                html.Button(children=['Add Material',
                                      html.I(className='fa fa-arrow-right', style={'margin-left': '10px'})],
                            className='w3-button w3-dark-grey', style={'margin-top': '10px', 'margin-bottom': '10px',
                                                                       'margin-right': '10px'},
                            id='button_add_material'),

                html.Button(children=['Reset Filters',
                                      html.I(className='fas fa-trash', style={'margin-left': '10px'})],
                            className='w3-button w3-dark-grey', style={'margin-top': '10px', 'margin-bottom': '10px'},
                            id='button_reset_filters'),
            ]),
            dcc.Dropdown(id=f'dropdown_material_visual',
                         options=[{'label': _, 'value': _} for _ in
                                  sorted(DICT_DATA['post_manufacturing_property']['material_id_str'].unique())],
                         multi=True, clearable=False,
                         value=[],
                         placeholder='Materials for visualizations',
                         style={'width': f'{DROPDOWN_WIDTH}px', 'height': '125px'}),

            html.Button(children=['Reset Selections',
                                  html.I(className='fas fa-eraser', style={'margin-left': '10px'})],
                        className='w3-button w3-dark-grey', style={'margin-top': '10px', 'margin-bottom': '10px'},
                        id='button_reset_selections'),
            html.Br(),

        ], className='w3-light-grey', style={'width': '385px', 'padding-left': '15px', 'margin-top': '20px'}),
    ])


div_data_visualization = html.Div([
    html.Div(div_data_visualization_tabs),
    html.Div([
        html.Div(
            className='w3-col s3',
            children=div_data_visualization_filters
        ),
        html.Div(
            className='w3-col s6',
            children=[
                html.H5('Visualizations / Table'),
                html.Div(id='div_main_visual_content')
        ])
    ], className='w3-row'),
])


@app.callback(
    Output('div_main_visual_content', 'children'),
    Output('button_combined_spider_chart', 'className'), Output('button_individual_spider_chart', 'className'),
    Output('button_bar_chart', 'className'), Output('button_printing_condition', 'className'),
    Input('button_combined_spider_chart', 'n_clicks'), Input('button_individual_spider_chart', 'n_clicks'),
    Input('button_bar_chart', 'n_clicks'), Input('button_printing_condition', 'n_clicks')
)
def update_main_visual(_1, _2, _3, _4):
    trigger = callback_context.triggered[0]
    button_list = ['button_combined_spider_chart', 'button_individual_spider_chart',
                   'button_bar_chart', 'button_printing_condition']
    output_classname_list = ['w3-bar-item w3-button w3-mobile'] * len(button_list)
    button_pressed = 'Nothing'
    prior = CACHE.dict_activity_store['tab_main_material_visual']

    if type(trigger) is dict:
        if 'prop_id' in trigger:
            button_pressed = trigger['prop_id'].split('.')[0]
            if button_pressed in button_list:
                if CACHE.dict_activity_store['tab_main_material_visual'] != button_pressed:
                    CACHE.dict_activity_store['tab_main_material_visual'] = button_pressed
    button_current = CACHE.dict_activity_store['tab_main_material_visual']
    output_classname_list[button_list.index(button_current)] = 'w3-bar-item w3-button w3-red w3-mobile'
    output = [DICT_VISUAL[button_current]] + output_classname_list
    return output


@app.callback(
    Output('chart_material_spider_combine', 'figure'),
    Input('dropdown_material_visual', 'value'))
def update_material_spider_chart_combine(dropdown_material_visual):
    #dropdown_material_visual = ['90Exceed XP 8656ML/10 Topas E140-FDM', '90Exceed XP 8656ML/10VMX6102-FDM',
    #                            'Exceed XP 8656ML-FDM', '50LLDPE(PE-B5)/50UHMWPE(PE-10.11)-FDM', 'LLDPE(PE-B5)-FDM']
    # derived_virtual_data = [{'Materials': '50PDH025/45VMX6102/5VMX8880-FDM'}, {'Materials': '50PP7033E3/50VMX6102-IM'}, {'Materials': '50PDH025/45VMX6102/5VMX8880-IM'}]
    # derived_virtual_selected_rows = [0, 1]
    dropdown_material_visual = dropdown_material_visual if dropdown_material_visual is not None else []
    _temp = [_.split('-') for _ in dropdown_material_visual]
    dict_material_visual_list = [{'material': '-'.join(i[:-1]), 'process_type': i[-1], 'material_id_str': '-'.join(i)} for i in _temp]
    plot_properties = ['1%_Secant_Modulus', 'youngs_modulus', 'tensile_stress_at_yield',
                       'tensile_stress_at_break', 'strain_at_break', 'flex_modulus'
                       ]
    # 'notched_izod_impact']
    dict_plot_properties_rename = {'1%_Secant_Modulus': '1% Secant<br>Modulus', 'youngs_modulus': "Young's<br>Modulus",
                                   'tensile_stress_at_yield': 'Tensile stress at Yield',
                                   'tensile_stress_at_break': 'Tensile Stress<br>at Break',
                                   'strain_at_break': 'Strain at<br>Break', 'flex_modulus': 'Flex Modulus'}
    plot_properties_show = [dict_plot_properties_rename[i] for i in plot_properties]

    pd_property_ori = DICT_DATA['post_manufacturing_property'].copy()
    pd_property = pd_property_ori.loc[pd_property_ori.material_id_str.isin(dropdown_material_visual)]
    pd_property = pd_property.loc[(~pd_property[plot_properties[0]].isna()) & (pd_property[plot_properties[0]] != '')]
    material_id_str_plot = [i['material_id_str'] for i in dict_material_visual_list]
    material_id_str_plot_show = [i if len(i.split('/')) == 1 else i.split('/')[0] + '/<br>' + '/'.join(i.split('/')[1:])
                                 for i in material_id_str_plot]
    property_ranges = pd_property_ori[plot_properties].quantile(0.935).values
    n_row, n_col = 1, 1
    fig = make_subplots(rows=1, cols=1, vertical_spacing=0.075, horizontal_spacing=0.125,
                        specs=[[{'type': 'polar'}]*1]*1)
    dict_plot_data = {'plot': {}, 'value': {}}

    for material_id_str in material_id_str_plot:
        pd_property_entry = pd_property.loc[pd_property['material_id_str'] == material_id_str]
        dict_plot_data['plot'][material_id_str] = np.asarray([min(i, 1) for i in
                                                              pd_property_entry[plot_properties].iloc[0].values / property_ranges])
        dict_plot_data['value'][material_id_str] = pd_property_entry[plot_properties].iloc[0].values

    if len(dict_plot_data['value']) == 0:
        dict_plot_data = {'plot': {'TBD': [0, 0, 0, 0, 0, 0]},
                          'value': {'TBD': [0, 0, 0, 0, 0, 0]}}
        material_id_str_plot = ['TBD']
    for i_plot, material_id_str in enumerate(material_id_str_plot):
        ind_row, ind_col = 1, 1
        theta_plot = [i for i in plot_properties_show]
        r_plot = list(dict_plot_data['plot'][material_id_str])
        r_show = list(dict_plot_data['value'][material_id_str])
        r_show = [f"{val} {DICT_UNIT[plot_properties[i]]}" for i, val in enumerate(r_show)]
        r_plot = r_plot + [r_plot[0]]

        theta_plot = [f"{val}<br>{DICT_MAX[plot_properties[i]]} {DICT_UNIT[plot_properties[i]]}" for i, val in enumerate(theta_plot)]
        theta_plot = theta_plot + [theta_plot[0]]
        text1 = [material_id_str] * len(theta_plot)
        text2_theta = [i.replace('<br>', ' ') for i in plot_properties_show]
        text2 = text2_theta + [text2_theta[0]]
        text3 = r_show + [r_show[0]]
        hovertext = [f"{text1[i]}<br>{text2[i]}<br>{text3[i]}" for i in range(len(text1))]
        fig.add_trace(go.Scatterpolar(name=material_id_str, r=r_plot, theta=theta_plot, showlegend=True,
                                      hovertext=hovertext, hoverinfo="text"),
                      row=ind_row, col=ind_col)
    if len(material_id_str_plot) > 0:
        fig.update_layout(polar={'radialaxis': {'range': [0, 1], 'showticklabels': False},
                                 'angularaxis': {"rotation": 30, "direction": "clockwise"},
                                 'bgcolor': '#cce6ff',
                                 },)
    fig.update_traces(fill='toself')
    fig.update_layout(height=450 * n_row, width=GRAPH_WIDTH_COMBINE,
                      margin={'l': 40, 'r': 40, 't': 60, 'b': 60},
                      )
    return fig


@app.callback(
    Output('chart_material_spider_individual', 'figure'),
    Input('dropdown_material_visual', 'value'))
def update_material_spider_chart_individual(dropdown_material_visual):
    #dropdown_material_visual = ['90Exceed XP 8656ML/10 Topas E140-FDM', '90Exceed XP 8656ML/10VMX6102-FDM',
    #                            'Exceed XP 8656ML-FDM', '50LLDPE(PE-B5)/50UHMWPE(PE-10.11)-FDM', 'LLDPE(PE-B5)-FDM']
    dropdown_material_visual = dropdown_material_visual if dropdown_material_visual is not None else []
    _temp = [_.split('-') for _ in dropdown_material_visual]
    dict_material_visual_list = [{'material': '-'.join(i[:-1]), 'process_type': i[-1], 'material_id_str': '-'.join(i)} for i in _temp]
    plot_properties = ['1%_Secant_Modulus', 'youngs_modulus', 'tensile_stress_at_yield',
                       'tensile_stress_at_break', 'strain_at_break', 'flex_modulus'
                       ]
    # 'notched_izod_impact']
    dict_plot_properties_rename = {'1%_Secant_Modulus': '1% Secant<br>Modulus', 'youngs_modulus': "Young's<br>Modulus",
                                   'tensile_stress_at_yield': 'Tensile stress at Yield',
                                   'tensile_stress_at_break': 'Tensile Stress<br>at Break',
                                   'strain_at_break': 'Strain at<br>Break', 'flex_modulus': 'Flex Modulus'}
    plot_properties_show = [dict_plot_properties_rename[i] for i in plot_properties]

    pd_property_ori = DICT_DATA['post_manufacturing_property'].copy()
    pd_property = pd_property_ori.loc[pd_property_ori.material_id_str.isin(dropdown_material_visual)]
    pd_property = pd_property.loc[(~pd_property[plot_properties[0]].isna()) & (pd_property[plot_properties[0]] != '')]
    material_id_str_plot = [i['material_id_str'] for i in dict_material_visual_list]
    material_id_str_plot_show = [i if len(i.split('/')) == 1 else i.split('/')[0] + '/<br>' + '/'.join(i.split('/')[1:])
                                 for i in material_id_str_plot]
    property_ranges = pd_property_ori[plot_properties].quantile(0.935).values

    n_col = 3
    n_row = int(np.ceil(max(len(dict_material_visual_list), 1)/n_col))
    if len(material_id_str_plot_show) == 0:
        material_id_str_plot_show = ['TBD']
    fig = make_subplots(rows=n_row, cols=n_col, vertical_spacing=0.075, horizontal_spacing=0.145,
                        subplot_titles=[f"<b>{i}</b>" for i in material_id_str_plot_show],
                        specs=[[{'type': 'polar'}]*n_col]*n_row)
    dict_plot_data = {'plot': {}, 'value': {}}

    for material_id_str in material_id_str_plot:
        pd_property_entry = pd_property.loc[pd_property['material_id_str'] == material_id_str]
        dict_plot_data['plot'][material_id_str] = np.asarray([min(i, 1) for i in
                                                              pd_property_entry[plot_properties].iloc[0].values / property_ranges])
        dict_plot_data['value'][material_id_str] = pd_property_entry[plot_properties].iloc[0].values

    dict_record = set()
    dict_name = {0: 'FDM', 1: 'IM'}
    if len(material_id_str_plot) == 0:
        material_id_str_plot = ['TBD']
        dict_plot_data = {'plot': {'TBD': [0, 0, 0, 0, 0, 0]}, 'value': {'TBD': [0, 0, 0, 0, 0, 0]}}

    for i_plot, material_id_str in enumerate(material_id_str_plot):
        if material_id_str[-2:] in ['IM', 'TBD']:
            i_process_type = 1
        else:
            i_process_type = 0
        if i_process_type not in dict_record:
            bool_legend = True
            dict_record.update({i_process_type})
        else:
            bool_legend = False
        ind_row = i_plot // n_col + 1
        ind_col = i_plot % n_col + 1
        color = px.colors.qualitative.Plotly[i_process_type]

        r_plot = list(dict_plot_data['plot'][material_id_str])
        r_show = list(dict_plot_data['value'][material_id_str])
        theta_plot = [f"{plot_properties_show[i]}<br>{DICT_MAX[plot_properties[i]]} {DICT_UNIT[plot_properties[i]]}"
                      for i, val in enumerate(dict_plot_properties_rename)]
        theta_plot = theta_plot + [theta_plot[0]]
        r_plot = r_plot + [r_plot[0]]

        text_show = [f'{plot_properties_show[i].replace("<br>", " ")}<br>{r_show[i]} {DICT_UNIT[col]}'
                     for i, col in enumerate(dict_plot_properties_rename)]
        hovertext = text_show + [text_show[0]]
        fig.add_trace(go.Scatterpolar(name=dict_name[i_process_type], r=r_plot, theta=theta_plot, showlegend=bool_legend,
                                      marker_color=color, hovertext=hovertext, hoverinfo="text"),
                      row=ind_row, col=ind_col)
        if 'Define radius range' == 'Define radius range':
            if i_plot == 0:
                fig.update_layout(polar={'radialaxis': {'range': [0, 1], 'showticklabels': False}, 'bgcolor': '#cce6ff',
                                         'angularaxis': {"rotation": 30, "direction": "clockwise"}})
            elif i_plot == 1:
                fig.update_layout(polar2={'radialaxis': {'range': [0, 1], 'showticklabels': False}, 'bgcolor': '#cce6ff',
                                         'angularaxis': {"rotation": 30, "direction": "clockwise"}})
            elif i_plot == 2:
                fig.update_layout(polar3={'radialaxis': {'range': [0, 1], 'showticklabels': False}, 'bgcolor': '#cce6ff',
                                         'angularaxis': {"rotation": 30, "direction": "clockwise"}})
            elif i_plot == 3:
                fig.update_layout(polar4={'radialaxis': {'range': [0, 1], 'showticklabels': False}, 'bgcolor': '#cce6ff',
                                         'angularaxis': {"rotation": 30, "direction": "clockwise"}})
            elif i_plot == 4:
                fig.update_layout(polar5={'radialaxis': {'range': [0, 1], 'showticklabels': False}, 'bgcolor': '#cce6ff',
                                         'angularaxis': {"rotation": 30, "direction": "clockwise"}})
            elif i_plot == 5:
                fig.update_layout(polar6={'radialaxis': {'range': [0, 1], 'showticklabels': False}, 'bgcolor': '#cce6ff',
                                         'angularaxis': {"rotation": 30, "direction": "clockwise"}})
            elif i_plot == 6:
                fig.update_layout(polar7={'radialaxis': {'range': [0, 1], 'showticklabels': False}, 'bgcolor': '#cce6ff',
                                         'angularaxis': {"rotation": 30, "direction": "clockwise"}})
            elif i_plot == 7:
                fig.update_layout(polar8={'radialaxis': {'range': [0, 1], 'showticklabels': False}, 'bgcolor': '#cce6ff',
                                         'angularaxis': {"rotation": 30, "direction": "clockwise"}})
        fig.layout.annotations[i_plot].update({'font': {'size': 13}})
    fig.update_traces(fill='toself')
    fig.update_layout(height=375 * n_row, width=GRAPH_WIDTH_INDIVIDUAL, margin={'l': 80, 'r': 40, 't': 40, 'b': 20})
    return fig


@app.callback(
    Output('chart_material_bar', 'figure'),
    Input('dropdown_material_visual', 'value'))
def update_material_bar_chart(dropdown_material_visual):

    dropdown_material_visual = dropdown_material_visual if dropdown_material_visual is not None else []

    _temp = [_.split('-') for _ in dropdown_material_visual]
    dict_material_visual_list = [{'material': '-'.join(i[:-1]), 'process_type': i[-1], 'material_id_str': '-'.join(i)} for i in _temp]
    plot_properties = ['1%_Secant_Modulus', 'youngs_modulus', 'tensile_stress_at_yield',
                       'tensile_stress_at_break', 'strain_at_break', 'flex_modulus'
                       ]
    dict_plot_properties_rename = {'1%_Secant_Modulus': '1% Secant Modulus', 'youngs_modulus': "Young's Modulus",
                                   'tensile_stress_at_yield': 'Tensile stress at Yield',
                                   'tensile_stress_at_break': 'Tensile Stress at Break',
                                   'strain_at_break': 'Strain at Break', 'flex_modulus': 'Flex Modulus'}
    plot_properties_show = [dict_plot_properties_rename[i] for i in plot_properties]

    pd_property_ori = DICT_DATA['post_manufacturing_property'].copy()
    pd_property = pd_property_ori.loc[pd_property_ori.material_id_str.isin(dropdown_material_visual)]
    pd_property = pd_property.loc[(~pd_property[plot_properties[0]].isna()) & (pd_property[plot_properties[0]] != '')]

    process_short_types = sorted([i.split('-')[-1] for i in pd_property_ori.process_type.unique()])

    n_col = 3
    n_row = int(np.ceil(len(plot_properties)/n_col))
    fig = make_subplots(rows=n_row, cols=n_col, shared_xaxes=True, vertical_spacing=0.08,
                        subplot_titles=[f"<b>{val}, {DICT_UNIT[plot_properties[i]]}</b>" for i, val in enumerate(plot_properties_show)])

    dict_plot_data = {i: {j: [] for j in plot_properties} for i in process_short_types}
    for i_row, _property in enumerate(plot_properties):
        for process_type in process_short_types:
            pd_property_sel_1 = pd_property.loc[pd_property['process_type'].str.split('-').str[-1] == process_type]
            for _dict_material in dict_material_visual_list:
                _material = _dict_material['material_id_str']
                pd_property_sel_2 = pd_property_sel_1.loc[pd_property_sel_1.material_id_str == _material]
                if len(pd_property_sel_2) > 0:
                    value = pd_property_sel_2.iloc[0][_property]
                else:
                    value = np.nan
                dict_plot_data[process_type][_property].append(value)

    for i_process_type, process_type in enumerate(process_short_types):
        for i_plot, _property in enumerate(plot_properties):
            names = dict_material_visual_list
            name_new = ['/<br>'.join(i['material'].split('/')) for i in names]
            ind_row = i_plot // n_col + 1
            ind_col = i_plot % n_col + 1
            bool_legend = i_plot == 0
            color = px.colors.qualitative.Plotly[i_process_type]
            y_plot_ori = dict_plot_data[process_type][_property]
            y_plot = [i for i in y_plot_ori if ~np.isnan(i)]
            x_plot = [name_new[i] for i in range(len(y_plot_ori)) if ~np.isnan(y_plot_ori[i])]
            hovertext = [f"{x_plot[i].replace('<br>', '')}, {process_type}<br>{y_plot[i]} {DICT_UNIT[plot_properties[i]]}"
                         for i in range(len(x_plot))]
            fig.add_trace(go.Bar(name=process_type, x=x_plot, y=y_plot, hovertext=hovertext, hoverinfo="text",
                                 showlegend=bool_legend, marker_color=color),
                          row=ind_row, col=ind_col)
    for i_plot in range(len(plot_properties)):
        fig.layout.annotations[i_plot].update({'font': {'size': 13}})
    fig.update_layout({'plot_bgcolor': '#cce6ff'})
    fig.update_layout(height=475, width=GRAPH_WIDTH_INDIVIDUAL, margin={'l': 20, 'r': 20, 't': 20, 'b': 20})
    return fig


@app.callback(
    Output('table_printing_condition', 'data'), Output('table_printing_condition', 'columns'),
    Output('table_printing_condition', 'style_cell_conditional'),
    Input('dropdown_material_visual', 'value'))
def update_printing_table(dropdown_material_visual):
    # dropdown_material_visual = ['90Exceed XP 8656ML/10 Topas E140-FDM', '90Exceed XP 8656ML/10VMX6102-FDM',
    # 'Exceed XP 8656ML-FDM', '50LLDPE(PE-B5)/50UHMWPE(PE-10.11)-FDM', 'LLDPE(PE-B5)-FDM']
    # print(dropdown_material_visual)
    dropdown_material_visual = dropdown_material_visual if dropdown_material_visual is not None else []
    materials_show = ['-'.join(i.split('-')[:-1]) for i in dropdown_material_visual if i[-3:] == 'FDM']
    pd_condition = DICT_DATA['print_condition'].copy()
    pd_condition = pd_condition.loc[pd_condition['material_name'].isin(materials_show)]
    row_info = ['Comment', 'process_feed_rate', 'process_screw_rotation_speed', 'process_torque', 'process_die_t', 'process_zone_8_t',
                'process_zone_7_t', 'process_zone_6_t', 'process_zone_5_t', 'process_zone_4_t', 'process_zone_3_t', 'process_zone_2_t',
                'process_spooler_rotation_speed', 'print_filament_d', 'print_bed_t', 'print_nozzle_t', 'print_nozzle_d', 'print_speed',
                'print_infill_density', 'print_layer_thickness', 'print_fan_speed', 'print_bed_material', 'print_pattern']
    dict_row_show = {i: ' '.join([j[0].upper()+j[1:] if len(j) > 1 else j.upper() for j in i.split('_')]).strip()+' ' for i in row_info}
    dict_row_show = {i: dict_row_show[i].replace(' D ', ' Diameter').replace(' T ', ' Temperature').strip() for i in dict_row_show}
    dict_row_show = {i: dict_row_show[i].replace('Process ', '').replace('Print', '').strip() for i in dict_row_show}
    dict_row_show['print_speed'] = 'Print Speed'
    dict_row_show['print_pattern'] = 'Print Pattern'
    pd_condition_show = pd_condition[['material_name'] + row_info].copy()
    material_names_new = [i for i in pd_condition_show['material_name']]
    pd_condition_show['material_name'] = material_names_new
    pd_condition_show = pd_condition_show.T.reset_index()
    pd_condition_show.columns = ['Item'] + list(pd_condition_show.iloc[0])[1:]
    pd_condition_show = pd_condition_show.iloc[1:].copy()
    dict_process_type = {'Comment': '', 'process': 'Extrusion', 'print': 'Printing'}
    pd_condition_show['Process Type'] = [dict_process_type[i.split('_')[0]] for i in pd_condition_show['Item']]
    cols_head = ['Process Type', 'Item']
    pd_condition_show = pd_condition_show[cols_head + [i for i in pd_condition_show if i not in cols_head]]
    pd_condition_show['Item'] = pd_condition_show['Item'].replace(dict_row_show)
    columns_show = [{'id': i, 'name': ' /'.join(i.split('/'))} for i in cols_head + material_names_new]
    n_col_add = CACHE.table_print_cols - len(material_names_new)
    columns_show += [{'id': f'_{i}', 'name': ''} for i in range(n_col_add)]

    dict_data_show = pd_condition_show.to_dict('records')

    for i in range(len(dict_data_show)):
        dict_data_show[i].update({'id': i})

    cell_conditional = [{'if': {'column_id': 'Process Type'}, 'width': '105px', 'minWidth': '75px', 'maxWidth': '115px'},
                        {'if': {'column_id': 'Item'}, 'width': '175px', 'minWidth': '120px', 'maxWidth': '190px'}] + \
                       [{'if': {'column_id': f'_{i}'}, 'minWidth': '30px', 'Width': '70px'} for i in range(n_col_add)] + \
                       [{'if': {'column_id': i}, 'width': '130px',
                         'minWidth': '100px', 'maxWidth': '150px'} for i in material_names_new]
    # print(columns_show)
    return dict_data_show, columns_show, cell_conditional


@app.callback(
    Output('dropdown_material_visual', 'options'), #Output('dropdown_material', 'options'),
Input('dropdown_material_type', 'value'), Input('dropdown_process_method', 'value'),
    Input('dropdown_material', 'value'), Input('button_reset_filters', 'n_clicks'),
    State('dropdown_material_visual', 'value')
)
def update_dropdown_material_visual_options(dropdown_material_type, dropdown_process_method, dropdown_material, _,
                                            dropdown_material_visual_current):
    # print(dropdown_material_type)
    pd_material = DICT_DATA['material']
    pd_data = DICT_DATA['post_manufacturing_property']
    if dropdown_material_type is not None:
        material_list = list(pd_material.loc[pd_material['material_type'] == dropdown_material_type]['material_name'])
        pd_data = pd_data.loc[pd_data['material_name'].isin(material_list)]
    if (dropdown_process_method is not None) & (dropdown_process_method != 'Both'):
        pd_data = pd_data.loc[pd_data['process_type'] == dropdown_process_method]
    if (dropdown_material is not None) & (dropdown_material != 'Both'):
        pd_data = pd_data.loc[pd_data['material_name'] == dropdown_material]
    materials_visual_options = [{'label': _, 'value': _} for _ in sorted(pd_data['material_id_str'].unique())]
    if dropdown_material_visual_current is not None:
        materials_visual_options += [{'label': _, 'value': _} for _ in dropdown_material_visual_current
                                      if _ not in materials_visual_options]

    return materials_visual_options


@app.callback(
    Output('dropdown_material', 'options'), Output('dropdown_material', 'value'),
    Input('dropdown_material_type', 'value'), Input('button_reset_filters', 'n_clicks'),
    State('dropdown_material', 'value'))
def update_dropdown_material_options(dropdown_material_type, _, dropdown_material_current):
    # print(dropdown_material_type)
    pd_material = DICT_DATA['material']
    pd_data = DICT_DATA['post_manufacturing_property']
    trigger = callback_context.triggered[0]
    bool_reset = False
    if type(trigger) is dict:
        if 'prop_id' in trigger:
            if trigger['prop_id'] == 'button_reset_filters.n_clicks':
                dropdown_material_type = None
                bool_reset = True
    if dropdown_material_type is not None:
        material_list = list(pd_material.loc[pd_material['material_type'] == dropdown_material_type]['material_name'])
        pd_data = pd_data.loc[pd_data['material_name'].isin(material_list)]
        if dropdown_material_current is not None:
            pd_data_test = pd_data.loc[pd_data['material_name'] == dropdown_material_current]
            if len(pd_data_test) == 0:
                dropdown_material_output = None
            else:
                pd_data = pd_data_test
                dropdown_material_output = dropdown_material_current
        else:
            dropdown_material_output = dropdown_material_current
    else:
        if bool_reset:
            dropdown_material_output = None
        else:
            dropdown_material_output = dropdown_material_current
    materials_options = [{'label': _, 'value': _} for _ in sorted(pd_data['material_name'].unique())]

    return materials_options, dropdown_material_output


@app.callback(
    Output('dropdown_material_visual', 'value'),
    State('dropdown_material', 'value'), State('dropdown_process_method', 'value'),
    State('dropdown_material_visual', 'value'),
    Input('button_add_material', 'n_clicks'), Input('button_reset_selections', 'n_clicks'))
def update_dropdown_material_visual(materia_select, process_method_select, material_list, _1, _2):
    if material_list is None:
        material_list = []
    trigger = callback_context.triggered[0]
    if type(trigger) is dict:
        if 'prop_id' in trigger:
            if material_list is None:
                material_list = []
            if trigger['prop_id'] == 'button_add_material.n_clicks':
                if (process_method_select is not None) & (materia_select is not None):
                    if process_method_select[-3:] == 'FDM':
                        process_method_output = ['FDM']
                    elif process_method_select[-3:] == '-IM':
                        process_method_output = ['IM']
                    elif process_method_select == 'Both':
                        process_method_output = ['FDM', 'IM']
                    else:
                        raise ValueError(f'Not able to identify process type. Recieved input: "{process_method_select}"')
                    for process_method_entry in process_method_output:
                        val = f'{materia_select}-{process_method_entry}'
                        if val not in material_list:
                            material_list.append(val)
            elif trigger['prop_id'] == 'button_reset_selections.n_clicks':
                return []
    return material_list


@app.callback(
    Output('dropdown_process_method', 'value'),
    Output('dropdown_material_type', 'value'), State('dropdown_process_method', 'value'),
    State('dropdown_material_type', 'value'), Input('button_reset_filters', 'n_clicks'))
def update_dropdown_filters(dropdown_process_method, dropdown_material_type, _):
    trigger = callback_context.triggered[0]
    if type(trigger) is dict:
        if 'prop_id' in trigger:
            if trigger['prop_id'] == 'button_reset_filters.n_clicks':
                return None, None
    return dropdown_process_method, dropdown_material_type

