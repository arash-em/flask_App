# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from dash import html
import base64
from dash.dependencies import Input, Output

from app_main.dataiku_apps.lib.main_lib import CACHE

app = CACHE.app
padding_paragraph = '5px'
media_padding_left = '200px'

div_experimental_session = html.Div(children=[
    html.Div(id='td_print_null_experimental_methods'),
    html.Div([html.B('Date: '), 'August 26, 2021']),
    html.Div([html.B('Revision: '), '1']),
    html.H5([html.B('Experimental Methods')], style={'text-align': 'center'}),

    html.Br(),
    html.Div(['In this Customer Devleopment Tool, below experimental methods were used for material fabrication and '
              'data collection.']),
    html.Div([html.B('1. Filament Fabrcation Decription')],
             style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),
    html.Div(
        html.Video(controls=True, id='td_print_experimental_methods_media_1',
                   style={'width': '600px', 'display': 'flex', 'justify-content': 'center', }),
        style={'display': 'flex', 'justify-content': 'center', 'width': '600px', 'padding-left': media_padding_left,
               'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}
    ),

    html.Div([
        "Filaments of all examples were prepared using ThermoFisher Process 11 Parallel Twin-Screw Extruder, and spooler "
        "(Equipment # 10548151). The extrusion and the spooler conditions used are tabulated in the Customer Development "
        "Tool. Extrusion is a process used to create objects for a fixed cross-sectional profile. In a typical extrusion "
        "process, a material is pushed through a die of the desired cross-section. For each filament, 200 g weight of the "
        "example resins in pellet form were fed into the exrruder hopper, and then extruded out from a circular die with 3 mm "
        "diameter. By controlling the take-off speed of the spooler, the diameter of the fialment is adjusted to be "
        "2.85 mm ± 0.1 mm measured by Neiko 01407A Electronic Digital Caliper. "
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div([
        html.I('Table 1: Specifications for ThermoFisher Process 11 Twin-Screw Exruder')
    ], style={'text-align': 'center', 'padding-bottom': padding_paragraph}),
    html.Div(
        html.Table([
            html.Tr([html.Th(html.B('Technical Data'), colSpan='2',
                             style={'backgroundColor': '#cce2ff', 'text-align': 'center'})]),
            html.Tr([
                html.Th(html.B('Make')),
                html.Th('Thermo Fisher Scientific Inc. ')
            ]),
            html.Tr([
                html.Th(html.B('Model')),
                html.Th('Process 11 (Twin Screw Extruder)')
            ]),
            html.Tr([
                html.Th(html.B('Barrel Diameter')),
                html.Th('11 mm')
            ]),
            html.Tr([
                html.Th(html.B('Barrel Length')),
                html.Th('40 L/D (440 mm)')
            ]),
            html.Tr([
                html.Th(html.B('Screw Center Line Distance')),
                html.Th('8.6 mm')
            ]),
            html.Tr([
                html.Th(html.B('Barrel Segments')),
                html.Th('8')
            ]),
            html.Tr([
                html.Th(html.B('Independent Heating Zone')),
                html.Th('7 internal + 1 externals for die')
            ]),
            html.Tr([
                html.Th(html.B('Heating Capacity')),
                html.Th('1750 W ( 7 x 250 W)')
            ]),
            html.Tr([
                html.Th(html.B('Temperature')),
                html.Th('RT… 350 °C (optional 450 °C)')
            ]),
            html.Tr([
                html.Th(html.B('Pressure')),
                html.Th('100 bar, safety monitored')
            ]),
            html.Tr([
                html.Th(html.B('Typical Throughput')),
                html.Th('20 -2500 g/h')
            ]),
            html.Tr([
                html.Th(html.B('Minimum Required Material')),
                html.Th('30 g')
            ]),
            html.Tr([
                html.Th(html.B('Barrel Material')),
                html.Th('Nitriding steel 1.7365 (EN40B)')
            ]),
            html.Tr([
                html.Th(html.B('Screw Speed')),
                html.Th('10…1000 rpm')
            ]),
            html.Tr([
                html.Th(html.B('Torque per shaft')),
                html.Th('6 Nm, constant torque, safety monitored')
            ]),
            html.Tr([
                html.Th(html.B('Feed Zone')),
                html.Th('Permanently water cooled')
            ]),
            html.Tr([
                html.Th(html.B('Heating zones')),
                html.Th('7 X 5 L/D electrical heated (optional water cooled)')
            ]),
            html.Tr([
                html.Th(html.B('Dimensions')),
                html.Th('820 x 480 x 410 mm (L  x W x H)')
            ]),
            html.Tr([
                html.Th(html.B('Weight')),
                html.Th('55 Kg')
            ]),
            html.Tr([
                html.Th(html.B('Power Supply')),
                html.Th('230 V, 16 A, 50/60 Hz')
            ]),

        ], style={'border-collapse': 'collapse', 'border': '1px solid', 'text-align': 'left'}),
        style={'text-align': 'center', 'display': 'flex', 'justify-content': 'center', 'padding-bottom': padding_paragraph},
        className='w3-center'),

    html.Div([html.B('2. Fused Deposition Modeling printed parts preparation and 3D Printing Process Description')],
             style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div(
        html.Video(controls=True, id='td_print_experimental_methods_media_2',
                   style={'width': '600px', 'display': 'flex', 'justify-content': 'center', }),
        style={'text-align': 'center', 'display': 'flex', 'justify-content': 'center', 'width': '600px',
               'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph, 'padding-left': media_padding_left}
    ),

    html.Div([
        "All Fused Deposition Modeling (FDM) specimens were fabrciated with an Airwolf3D® Axiom Single Head 3-D Printer "
        "(Figure 1). Specifications of Axiom single head 3D printer with direct drive is shown in Table 2. The geometry "
        "for the specimens investigated in this patent were ISO 37 Type 3 tensile bars and notch bars with dimension of "
        "2.5 in x 0.125 in x 0.5 in (LxTxW) (shown in Figure 2). Dassault Systems SolidWorks software, which is a computer-aided "
        "design (CAD) package, was first used to create 3D printable model with the dimension of ISO 37 Type 3 tensile bar. "
        "Then, the CAD model is tessellated and exported in STL format. The STL file was then sliced using Repetier Host "
        "software from Hot-World GmbH & Co. KG to convert the STL file into G-code, which is the standard language for 3D "
        "printers. G-code is a numerically controlled programming language that contains commands to move parts within the "
        "printer. After filament is loaded to the 3D printer, and 3D printer is set up following printing conditions tabulated "
        "in Customer Development Tool, the FDM specimens were be able to be produced."
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div([
        html.Img(id='td_print_experimental_methods_figure_1', style={'width': '700px'}),
    ],
        style={'text-align': 'center', 'display': 'flex', 'justify-content': 'center',
               'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph},
        className='w3-center'),
    html.Div([
        html.I("Figure 1: Axiom single head 3D printer with direct drive.")
    ], style={'text-align': 'center', 'padding-bottom': padding_paragraph}),


    html.Div([
        html.I("Table 2: Specifications of Axiom single head 3D printer with direct drive.")
    ], style={'text-align': 'center', 'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div(
        html.Table([
            html.Tr([html.Th(html.B('Printing Performance'), colSpan='2',
                             style={'backgroundColor': '#cce2ff', 'text-align': 'center'})]),
            html.Tr([
                html.Th(html.B('Make')),
                html.Th('Airwolf 3D')
            ]),
            html.Tr([
                html.Th(html.B('Model')),
                html.Th('Axiom Single Direct Drive Desktop 3D Printer')
            ]),
            html.Tr([
                html.Th(html.B('Build Volume')),
                html.Th('12.5" x 8" x 10"; 317 mm x 203 mm x 254 mm')
            ]),
            html.Tr([
                html.Th(html.B('Recommended Max. Print Speed')),
                html.Th('100 mm/sec')
            ]),
            html.Tr([
                html.Th(html.B('Travel Speed')),
                html.Th('125+ mm/sec')
            ]),
            html.Tr([
                html.Th(html.B('Max. Extruder Temp.')),
                html.Th('315 °C')
            ]),
            html.Tr([
                html.Th(html.B('Max. Bed Temp.')),
                html.Th('140 °C')
            ]),
            html.Tr([
                html.Th(html.B('Minimum Layer Height')),
                html.Th('40 microns')
            ]),
            html.Tr([
                html.Th(html.B('Recommended Layer Height')),
                html.Th('200 microns')
            ]),
            html.Tr([
                html.Th(html.B('Calibration')),
                html.Th('Auto-Leveling')
            ]),
            html.Tr([html.Th(html.B('Filament Compatibility'), colSpan='2',
                             style={'backgroundColor': '#cce2ff', 'text-align': 'center'})]),
            html.Tr([
                html.Th(html.B('Materials')),
                html.Th('Over 40, incl. ABS, PC, PP, Nylons, TPE, TPU')
            ]),
            html.Tr([
                html.Th(html.B('Filament Size')),
                html.Th('2.85mm +/-0.10')
            ]),
            html.Tr([html.Th(html.B('Printer Design'), colSpan='2',
                             style={'backgroundColor': '#cce2ff', 'text-align': 'center'})]),
            html.Tr([
                html.Th(html.B('Weight (lbs)')),
                html.Th('61 lbs.')
            ]),
            html.Tr([
                html.Th(html.B('Height (in)')),
                html.Th('23.5"')
            ]),
            html.Tr([
                html.Th(html.B('Width (in)')),
                html.Th('23.5"')
            ]),
            html.Tr([
                html.Th(html.B('Depth (in)')),
                html.Th('19.5"')
            ]),
            html.Tr([
                html.Th(html.B('Power Supply')),
                html.Th([
                    'Voltage: auto switch from 110 V to 220 V', html.Br(),
                    'Power: 500 W', html.Br(),
                    'Amperage draw with all heaters on full: 12 A',
                ])
            ]),
            html.Tr([
                html.Th(html.B('Frame Construction')),
                html.Th('Aluminum, Polycarbonate')
            ]),
            html.Tr([
                html.Th(html.B('Motion System')),
                html.Th('Amperage draw with all heaters on full: 12 A')
            ]),
            html.Tr([
                html.Th(html.B('Motion System')),
                html.Th([
                    'Core XY', html.Br(),
                    'XY axis – 0.01 mm', html.Br(),
                    'Z axis – 0.05 mm'
                ])
            ]),
            html.Tr([
                html.Th(html.B('Enclosed Print Chamber')),
                html.Th('Yes')
            ]),
            html.Tr([
                html.Th(html.B('Heated Bed')),
                html.Th('Yes')
            ]),
            html.Tr([
                html.Th(html.B('Print Plate Material')),
                html.Th('Borosilicate Glass')
            ]),
            html.Tr([
                html.Th(html.B('Cooling Fans')),
                html.Th('Tri-fan')
            ]),
            html.Tr([html.Th(html.B('Connectivity & Accessories'), colSpan='2',
                             style={'backgroundColor': '#cce2ff', 'text-align': 'center'})]),
            html.Tr([
                html.Th(html.B('Provided Software')),
                html.Th('APEX')
            ]),
            html.Tr([
                html.Th(html.B('Connectivity')),
                html.Th('Ethernet, Micro SD, USB Cable, Wi-Fi')
            ]),
            html.Tr([
                html.Th(html.B('Print via Removable Device')),
                html.Th('SD Card')
            ]),

        ], style={'border-collapse': 'collapse', 'border': '1px solid', 'text-align': 'left'}),
        style={'display': 'flex', 'justify-content': 'center', 'padding-bottom': padding_paragraph}),

    html.Div([
        html.Img(id='td_print_experimental_methods_figure_2', style={'width': '700px'}),
    ],
        style={'text-align': 'center', 'display': 'flex', 'justify-content': 'center',
               'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph},
        className='w3-center'),
    html.Div([
        html.I('Figure 2: 3D drawing of (a) ISO Type 3 Tensile bar, (b) Notch bar with dimension of 2.5" x 0.125" x 0.5": (LxTxW).')
    ], style={'text-align': 'center', 'padding-bottom': padding_paragraph}),

    html.Div([html.B('3. Injection molding description')],
             style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),
    html.Div([
        "In order to measure the reference strength and behavior of the filament materials, for comparisons with FDM, additional "
        "specimens were fabricated by injection molding. Mold cavity dimensions were the same as those described for the FDM "
        "specimens, which is the ISO 37 Type 3 Tensile bar. All molded specimens were fabricated from the same FDM example resin "
        "pellets. The pellets were then fed into the hopper of a BOY XS injection molding machine. Molding parameters were set "
        "to the recommended values for example resins. Five replicate specimens were molded for each of the five tests."
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div([html.B('4. Test Methods')],
             style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),
    html.Div([
        html.Div([
            html.B("(1) Tensile test and flexural test "),
            "were performed on an Instron Autox750 Automatic Contacting Extensometer For tensile "
            "tests, the load cell is 1KN with 1% accuracy. For flexural tests, the load cell is 10kN with 1% accuarcy. Instron "
            "Bluehill software was used to record the data. "
        ]),
        html.Div([
            html.B("(2) The Izod impact strength tests "),
            "were studied on an Instron Ceast 9050 Impact Pendulum to determine the "
            "impact resistance of specimens. The specimens for impact test were first notched in a notch cutter "
            "(TMI Group of Companies Testing Machine Inc.). Then, the samples were tested under both -25 °C and "
            "room temperature (23 °C). Instron Bluehill software was used to record the data. "
        ]),
        html.Div(
            html.B("(3) Environmental stress crack resistance (ESCR) "),
            "Bent Strop ESCR test is one of the original and best-known "
            "ESCR tests. Ten rectangular-shaped specimens are cut from a molded plaque prepared with standard methods. "
            "A controlled notch is cut horizontally across each specimen, which serves as a crack initiation point. The "
            "specimens are bent and inserted into a “C” shaped bracket, creating a stress in the specimen. The specimens "
            "and bracket are inserted into a tube filled with IGEPAL solution. The tube is then placed into a heated "
            "environment and inspected periodically for cracking (failures). Solution concentration, environment temperature "
            "and sample dimensions vary with the test condition specified.  These various test conditions introduce "
            "different stresses and strains and allow testing of different polymers and still obtain results in a timely "
            "manner."),
    ], style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),

    html.Div([html.B('References: ')],
             style={'padding-top': padding_paragraph, 'padding-bottom': padding_paragraph}),
    html.Div([
        '[1] ',
        html.A('Process 11 Parallel Twin-Screw Exruder. Last accessed on August 26, 2021.',
               href="https://www.thermofisher.com/order/catalog/product/567-7600", target='_blank')]),
    html.Div([
        '[2] ',
        html.A('Axiom single head 3D printer with direct drive.  Last accessed on August 26, 2021.',
               href="https://airwolf3d.com/product/aw3d-axiom-dd/", target='_blank'),
        ])

], style={'margin-top': '40px', 'margin-left': '60px', 'width': '850px', 'minWidth': '450px'})


@app.callback(Output('td_print_experimental_methods_figure_1', 'src'),
              Output('td_print_experimental_methods_figure_2', 'src'),
              Output('td_print_experimental_methods_media_1', 'src'),
              Output('td_print_experimental_methods_media_2', 'src'),
              Input('td_print_null_experimental_methods', 'n_clicks'))
def update_image(_a):
    # path_image_1 = f'{CACHE.DIR_DATA}/image/3d printing figure 1.jpg'
    # encoded_image_1 = base64.b64encode(open(path_image_1, 'rb').read())
    # output_1 = 'data:image/jpg;base64,{}'.format(encoded_image_1.decode())
    output_1 = 'https://matdbstorage.blob.core.windows.net/yunsong-test/3d%20printing%20figure%201.png?sp=r&st=2022-09-19T18:28:43Z&se=2222-09-20T02:28:43Z&sv=2021-06-08&sr=b&sig=LTQBHXaGeRRADSrqIpvjEes85os4YP6WCfl%2FeynvVMQ%3D'

    # path_image_2 = f'{CACHE.DIR_DATA}/image/3d printing figure 2.png'
    # encoded_image_2 = base64.b64encode(open(path_image_2, 'rb').read())
    # output_2 = 'data:image/png;base64,{}'.format(encoded_image_2.decode())
    output_2 = 'https://matdbstorage.blob.core.windows.net/yunsong-test/3d%20printing%20figure%202.png?sp=r&st=2022-09-19T18:29:09Z&se=2222-09-20T02:29:09Z&sv=2021-06-08&sr=b&sig=PrSbi0w0eBMjXasNYEeWLfgI5ZUHfkYkuFgBzxRxoGI%3D'

    # path_media_1 = f'{CACHE.DIR_DATA}/media/3d printing media 1.mp4'
    # encoded_media_1 = base64.b64encode(open(path_media_1, 'rb').read())
    # output_3 = 'data:video/mp4;base64,{}'.format(encoded_media_1.decode())
    output_3 = 'https://matdbstorage.blob.core.windows.net/yunsong-test/3d%20printing%20media%201.mp4?sp=r&st=2022-09-19T18:09:40Z&se=2222-09-20T02:09:40Z&sv=2021-06-08&sr=b&sig=rJt%2Bo2pJAUCHgocMVWCuEAbSfzLNgQxqNvTXsTKwZDE%3D'

    # path_media_2 = f'{CACHE.DIR_DATA}/media/3d printing media 2.mp4'
    # encoded_media_2 = base64.b64encode(open(path_media_2, 'rb').read())
    # output_4 = 'data:video/mp4;base64,{}'.format(encoded_media_2.decode())
    output_4 = 'https://matdbstorage.blob.core.windows.net/yunsong-test/3d%20printing%20media%202.mp4?sp=r&st=2022-09-19T18:11:42Z&se=2222-09-20T02:11:42Z&sv=2021-06-08&sr=b&sig=AbEEWRhIzqmZ2RdhDNJ8wemRSW%2FQ4LQubDbNyYr93HM%3D'

    return output_1, output_2, output_3, output_4

