# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from dash import html, dcc, callback_context
from dash.dependencies import Input, Output, State

from app_main.dataiku_apps.lib.main_lib import CACHE, LABEL_SYSTEM

if LABEL_SYSTEM == 'LINUX':
    pass

app = CACHE.app
memory_global = 'root_memory_global'

dict_cc_dropdown_options = {
    'webapp': ['3D Printing Material Hub', 'Functional Equivalency Test Analysis Dashboard'],
    'category': ["New service opportunity", "Problem with current service", "Encouragement to us"],
    'current_service_sub_category':
        ["New feature", "Layout improvement", "Data visualization improvement", "Website response speed",
         "Other"],
}

section_seperate = '20px'
minwidth = '450px'
width = '850px'
maxwidth = '1150px'

boxwidth = '400px'
boxheight = '350px'


div_communication_center = html.Div(
    children=[
        dcc.ConfirmDialog(id='cc_confirm'),
        html.H5(html.B('Our mission: ')),
        html.Div(
            [
                html.P([
                    "We, as Chemical Modeling and Informatics (CMI) team, are speciailized in providing solutions in ",
                    html.B("data storage, processing, analysis and visualization"),
                    ". Not only we will provide tools for visualizing and analyzing your data, "
                    "but also we will make sure that this data will be shared the entities "
                    "you are most comfortable with in ExxonMobil corporation."
                ]),
            ]
        ),

        html.Div(
            html.P(
                "We look foward to working with everyone in ExxonMobil to generate business value via"
                " facilitate fast information processing, digesting and exchanging.",
            )
        ),

        html.Hr(style={'color': 'black', 'border-style': 'inset', 'border-width': '1px'}),

        html.H5(html.B('Let us know your thoughts:')),

        html.Div([
            html.Div("Name:", style={'margin-top': section_seperate}),
            html.Div(html.B("...Development...", id='cc_username'), style={'margin-bottom': section_seperate})
        ]),

        html.Div([
            html.Div("Email:", style={'margin-top': section_seperate}),
            html.Div(html.B("...Development...", id='cc_email'), style={'margin-bottom': section_seperate})
        ]),

        html.Div([
            html.Div("Feedback category", style={'margin-top': section_seperate}),
            dcc.Dropdown(id='cc_dropdown_feedback_category', value=None,
                         options=[{'label': _, 'value': _} for _ in dict_cc_dropdown_options['category']],
                         placeholder='Please select',
                         style={'width': width, 'minWidth': minwidth, 'maxWidth': maxwidth,
                                'margin-bottom': section_seperate}),
        ]),

        html.Div(id='cc_div_webapp', className='w3-hide', children=[
            html.Div("Webapp", style={'margin-top': section_seperate}),
            dcc.Dropdown(id='cc_dropdown_feedback_webapp', value=None,
                         options=[{'label': _, 'value': _} for _ in dict_cc_dropdown_options['webapp']],
                         placeholder='Please select',
                         style={'width': width, 'minWidth': minwidth, 'maxWidth': maxwidth,
                                'margin-bottom': section_seperate}),
        ]),

        html.Div(id='cc_div_sub_category', className='w3-hide', children=[
            html.Div("Feedback sub-category", style={'margin-top': section_seperate}),
            dcc.Dropdown(id='cc_dropdown_feedback_sub_category',
                         value=None,
                         options=[{'label': _, 'value': _} for _ in dict_cc_dropdown_options['current_service_sub_category']],
                         placeholder='Please select',
                         style={'width': width, 'minWidth': minwidth, 'maxWidth': maxwidth,
                                'margin-bottom': section_seperate}),
        ]),

        html.Div([
            html.Div("Description", style={'margin-top': section_seperate}),
            dcc.Textarea(id='cc_text_feedback_description',
                         placeholder='Please enter description',
                         style={'width': width, 'minWidth': minwidth, 'maxWidth': maxwidth, 'height': '150px',
                                'margin-bottom': section_seperate}),
        ]),
        html.Button(children=['Submit'], id='cc_button_feedback_submit'),

        html.Hr(style={'color': 'black', 'border-style': 'inset', 'border-width': '1px',
                       'margin-top': section_seperate}),

        html.Div(
            children=[
                html.Div([
                    html.H5(html.B('Leadership team')),
                    html.P([
                        html.B('Chen, Ting'),
                        ' - Manager',
                        html.Div(
                            html.A([
                                html.Div(className='fa fa-envelope'),
                                ' ting.chen@exxonmobil.com'
                            ], style={'font-size': '12px'}, href='mailto:ting.chen@exxonmobil.com')
                        )
                    ]),
                    html.P([
                        html.B('Rodriguez, George'),
                        ' - Chief Scientist',
                        html.Div(
                            html.A([
                                html.Div(className='fa fa-envelope'),
                                ' george.rodriguez@exxonmobil.com'
                            ], style={'font-size': '12px'}, href='mailto:george.rodriguez@exxonmobil.com')
                        )
                    ]),

                ], style={'width': boxwidth,  'border-style': 'solid', 'border-width': '1px',
                          'padding-left': '15px', 'padding-right': '15px'}),

                html.Div([
                    html.H5(html.B('Execution team')),
                    html.P([
                        html.B('Cecen, ahmet'),
                        ' - Advanced Research Data Scientist',
                        html.Div(
                            html.A([
                                html.Div(className='fa fa-envelope'),
                                ' ahmet.cecen@exxonmobil.com'
                            ], style={'font-size': '12px'}, href='mailto:ahmet.cecen@exxonmobil.com')
                        )
                    ]),
                    html.P([
                        html.B('Moebus, Joseph'),
                        ' - Advanced Research Data Scientist',
                        html.Div(
                            html.A([
                                html.Div(className='fa fa-envelope'),
                                ' joseph.moebus@exxonmobil.com'
                            ], style={'font-size': '12px'}, href='mailto:joseph.moebus@exxonmobil.com')
                        )
                    ]),

                    html.P([
                        html.B('Sarhangi Fard, Arash'),
                        ' - Senior Staff Engineer',
                        html.Div(
                            html.A([
                                html.Div(className='fa fa-envelope'),
                                ' arash.sarhangifard@exxonmobil.com'
                            ], style={'font-size': '12px'}, href='mailto:arash.sarhangifard@exxonmobil.com')
                        )
                    ]),
                    html.P([
                        html.B('Xie, Yunsong'),
                        ' - Data Scientist',
                        html.Div(
                            html.A([
                                html.Div(className='fa fa-envelope'),
                                ' yunsong.xie@exxonmobil.com'
                            ], style={'font-size': '12px'}, href='mailto:yunsong.xie@exxonmobil.com')
                        )
                    ])
                ], style={'width': boxwidth, 'border-style': 'solid', 'border-width': '1px',
                          'padding-left': '15px', 'padding-right': '15px'}),
            ],
            style={'flex-wrap': 'wrap', 'flex-direction': 'row', 'justify-content': 'space-evenly', 'display': 'flex'}
        ),

        html.Hr(style={'color': 'black', 'border-style': 'inset', 'border-width': '1px',
                       'margin-top': section_seperate}),

    ],
    style={'margin-top': '40px', 'margin-left': '60px', 'width': width, 'minWidth': minwidth, 'maxWidth': maxwidth}
)


@app.callback(Output('cc_username', 'children'),
              Input(memory_global, 'data'))
def update_user_info(data):
    if data is None:
        return '...'
    else:
        # return data['userinfo']['display_name']
        return 'Yunsong Xie'


@app.callback(Output('cc_email', 'children'),
              Input(memory_global, 'data'))
def update_user_info(data):
    if data is None:
        return '...'
    else:
        # return data['userinfo']['email']
        return 'yunsong.xie@exxonmobil.com'


@app.callback(Output('cc_dropdown_feedback_category', 'value'),
              Output('cc_dropdown_feedback_webapp', 'value'),
              Output('cc_dropdown_feedback_sub_category', 'value'),
              Output('cc_text_feedback_description', 'value'),
              Output('cc_confirm', 'displayed'),
              Output('cc_confirm', 'message'),
              State('cc_dropdown_feedback_category', 'value'),
              State('cc_dropdown_feedback_webapp', 'value'),
              State('cc_dropdown_feedback_sub_category', 'value'),
              State('cc_text_feedback_description', 'value'),
              State(memory_global, 'data'),
              Input('cc_button_feedback_submit', 'n_clicks'))
def update_user_info(cc_dropdown_feedback_category, cc_dropdown_feedback_webapp,
                     cc_dropdown_feedback_sub_category, cc_text_feedback_description, memory_data, _):
    ctx = callback_context
    _button_id_detected = ctx.triggered[0]['prop_id'].split('.')[0]
    if _button_id_detected == 'cc_button_feedback_submit':
        message = "Thank you for the feedback, we will carefully review and get back to you."
        bool_valid = False

        if cc_text_feedback_description is None:
            message = 'Please enter more than 50 characters in the description'
        elif len(cc_text_feedback_description) < 50:
            message = "Please enter more than 50 characters in the description."
        elif cc_dropdown_feedback_category is None:
            message = "Please appropriately select the feedback category"
        elif cc_dropdown_feedback_category == 'Problem with current service':
            if (cc_dropdown_feedback_webapp is None) & (cc_dropdown_feedback_sub_category is None):
                message = "Please appropriately select the webapp and sub-category"
            elif cc_dropdown_feedback_webapp is None:
                message = "Please appropriately select the webapp"
            elif cc_dropdown_feedback_sub_category is None:
                message = "Please appropriately select the sub-category"
            else:
                bool_valid = True
        else:
            bool_valid = True
        if bool_valid:
            username = memory_data['userinfo']['username']
            CACHE.exe_log_feedback(username, cc_dropdown_feedback_category, cc_dropdown_feedback_webapp,
                                   cc_dropdown_feedback_sub_category, cc_text_feedback_description)
            return None, None, None, '', True, message
        else:
            return cc_dropdown_feedback_category, cc_dropdown_feedback_webapp, \
                   cc_dropdown_feedback_sub_category, cc_text_feedback_description, True, message
    else:
        return cc_dropdown_feedback_category, cc_dropdown_feedback_webapp, \
               cc_dropdown_feedback_sub_category, cc_text_feedback_description, False, ''


@app.callback(Output('cc_div_webapp', 'className'),
              Output('cc_div_sub_category', 'className'),
              Input('cc_dropdown_feedback_category', 'value'))
def update_user_info(cc_dropdown_feedback_category):
    if cc_dropdown_feedback_category is None:
        return 'w3-hide', 'w3-hide'
    elif cc_dropdown_feedback_category == 'Problem with current service':
        return 'w3-show', 'w3-show'
    else:
        return 'w3-hide', 'w3-hide'

