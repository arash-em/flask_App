# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from dash import html

padding_paragraph = '5px'
dict_href_style = {}

report_info_list = [
    ['Polyolefins for Additive Manufacturing White Paper.', ' 2016-01-05',
     'https://spworkflowapps.na.xom.com/sites/eMemory/lists/ememoryrctechnicalreportslist/Attachments/127506/46008.pdf'],
    ['Consultant study: Additive Manufacturing (3D Printing) Competitive Intelligence Briefing.',  ' 2019-04-30',
     'https://ishareteam9.na.xom.com/sites/cticsite/default.aspx?path_info=/sites/cticsite/cs/details-ci+216'],
    ['2019 Additive Manufacturing Conference and Expo Conference Report.',  ' 2019-11-26',
     'https://spworkflowapps.na.xom.com/sites/eMemory/lists/ememoryrccorrespondencesralist/Attachments/84126/2019CORR13433.pdf'],
    ['Setting Up 3D Printing Capabilities: 3D Printer Selection Criteria and 3D Printing Network.', ' 2019-12-19',
     'https://spworkflowapps.na.xom.com/sites/eMemory/lists/ememoryrctechnicalreportslist/Attachments/162510/2019REPT10339.pdf'],
    ['STO report out: Polyolefins for Additive Manufacturing and Structure-property Relationship Modeling.', ' 2019-12-26',
     'https://spworkflowapps.na.xom.com/sites/eMemory/lists/ememoryrctechnicalreportslist/Attachments/162511/2019REPT10342.pdf'],
    ['Business Alignment: Polyolefins for 3D printing.', ' 2020-01-01',
     'https://spworkflowapps.na.xom.com/sites/eMemory/lists/ememoryrctechnicalreportslist/Attachments/162512/2020REPT10001.pdf'],
    ['An Overview of 3D Printing Technologies and Processes.', ' 2020-01-02',
     'https://spworkflowapps.na.xom.com/sites/eMemory/lists/ememoryrctechnicalreportslist/Attachments/162513/2020REPT10002.pdf'],
    ['3D Printing Efforts in ExxonMobil.', ' 2021-09-20',
     'https://spworkflowapps.na.xom.com/sites/eMemory/Lists/eMemoryRCTechnicalReportsList/Attachments/163324/2021REPT10224a.pdf'],
    ['ExxonMobil Polyolefins for 3D Printing – filament fabrication, parts printing & characterization, and database.',
     ' Coming in March 2022',
     ''],]

patent_info_list = [
    ['Processes for Making 3-D Objects from Polypropylene.', ' ip.com, 2021-03-29',
     'https://priorart.ip.com/IPCOM/000265332'],
    ['Processes for Making 3-D Objects from Blends of Polyethylene and Semi-Amorphous Polymers.', ' ip.com, 2021-03-29',
     'https://priorart.ip.com/IPCOM/000265333'],
    ['Processes for Making 3-D Objects from Ethylene Based Semi-Amorphous Polymers.', ' ip.com, 2021-03-30',
     'https://priorart.ip.com/IPCOM/000265343'],
    ['Processes for Making 3-D Objects from Polyethylenes.', ' ip.com, 2021-03-30',
     'https://priorart.ip.com/IPCOM/000265347'],
    ['Processes For Making 3-D Objects From Blends Of Polypropylene And Semi-Amorphous Polymers.', ' WO2021195070A1, 2021-09-30',
     'https://patents.google.com/patent/WO2021195070A1/'],
    ['Processes for Making 3-D Objects from Blends of Polyethylene and Polar Polymers.', ' WO2022010622A1, 2022-01-13',
     'https://patents.google.com/patent/WO2022010623A1/'],
    ['Processes for Making 3-D Objects from Blends of Polyethylenes and Cyclic-Olefin Copolymers.', ' WO2022010623A1, 2022-01-13',
     'https://patents.google.com/patent/WO2022010623A1/'],
]

training_info_list = [
    ['3D Printing Efforts in ExxonMobil slide deck: 3D Printing Presentation PVA Fundamentals Training.pdf', ' ',
     'https://careerconnect.edcast.com/pathways/presentations-pva-technical-fundamentals/cards/12991309'],
    ['3D Printing Efforts in ExxonMobil Training mp4', '',
     'https://careerconnect.edcast.com/pathways/videos-pva-technical-fundamentals/cards/12991308'],
]

def build_content_list(report_info_list):
    content_report_list = []
    for i, report_info in enumerate(report_info_list):
        style = {'padding-bottom': padding_paragraph} if i == (len(report_info_list) - 1) else None
        if len(report_info[2]) > 1:
            target = '_blank'
            href = report_info[2]
        else:
            target = None
            href = None
        content_report_entry = html.Div([
            html.A(f'({i + 1}) '),
            html.A([report_info[0],
                    html.I(report_info[1])], href=href, target=target)
        ], style=style)
        content_report_list.append(content_report_entry)
    return content_report_list

content_reports = build_content_list(report_info_list)
content_patents = build_content_list(patent_info_list)
content_trainings = build_content_list(training_info_list)

contents = ([html.Div(html.B("1. Company reports"), style={'padding-top': padding_paragraph})] +
            content_reports +
            [html.Div(html.B("2. Patent publications"), style={'padding-top': padding_paragraph})] +
            content_patents +
            [html.Div(html.B("3. Training at Accelerated Learning"), style={'padding-top': padding_paragraph})] +
            content_trainings)

div_ip = html.Div(
    children=(
        [html.Div(html.B("1. Company reports"), style={'padding-top': padding_paragraph})] +
        content_reports +
        [html.Div(html.B("2. Patent publications"), style={'padding-top': padding_paragraph})] +
        content_patents +
        [html.Div(html.B("3. Training at Accelerated Learning"), style={'padding-top': padding_paragraph})] +
        content_trainings
    ),
    style={'margin-top': '40px', 'margin-left': '60px', 'width': '950px', 'minWidth': '450px'})

div_company_report = html.Div(
    children=(
        content_reports
    ),
    style={'margin-top': '40px', 'margin-left': '60px', 'width': '950px', 'minWidth': '450px'})

div_patent = html.Div(
    children=(
        content_patents
    ),
    style={'margin-top': '40px', 'margin-left': '60px', 'width': '950px', 'minWidth': '450px'})

div_training = html.Div(
    children=(
        content_trainings
    ),
    style={'margin-top': '40px', 'margin-left': '60px', 'width': '950px', 'minWidth': '450px'})
