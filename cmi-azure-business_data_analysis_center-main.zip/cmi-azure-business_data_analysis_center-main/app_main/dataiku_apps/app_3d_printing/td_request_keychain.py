# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com
from app_main.dataiku_apps.lib.main_lib import CACHE
from dash.dependencies import Input, Output, State
from dash import html, dcc, callback_context, dash_table
from dash.exceptions import PreventUpdate
import base64, io, datetime
import pandas as pd
import numpy as np
from stl import mesh
import plotly.graph_objects as go


app = CACHE.app

APPNAME = '3d_print-request_keychain'

DROPDOWN_WIDTH = 350
PAGE_SIZE = 25
TAB_HEIGHT = '46px'

padding_paragraph = '5px'
dict_href_style = {}

DIR = CACHE.DIR

dict_icon = {
    'keychain': 'https://matdbstorage.blob.core.windows.net/yunsong-test/3d_printing-keychain.png?sp=r&st=2022-09-19T18:31:56Z&se=2222-09-20T02:31:56Z&sv=2021-06-08&sr=b&sig=HL%2BhlwW7%2FF%2BBwIX0QZcqBqbAUJ3lWMriO1DE6glboCI%3D',
}

dict_image = {
    i: 'data:image/jpg;base64,{}'.format(base64.b64encode(open(dict_icon[i], 'rb').read()).decode())
    if dict_icon[i][:4] != 'http' else dict_icon[i] for i in dict_icon
}

dict_content = {
    'search-tab': ['Request'],
    'vis-tab': {'Request': ['Welcome', 'Request Status'],},
}

MATERIAL_SELECTIONS = ['ABS ExxonMobil Logo', 'ABS Name Tag', 'Exact 4160', 'PP6302E1', 'PP6302E1 Foam',
                       '50PP6302E1/50VMX6102', 'Exceed XP 8656ML', 'Exceed 1018', 'LLDPE(PE-B5)']


tab_pad_top, tab_pad_bottom = 13, 13
tab_style = {'padding-top': f'{tab_pad_top}px', 'padding-bottom': f'{tab_pad_bottom}px'}
tab_classname_default = 'w3-bar-item w3-button w3-mobile'
tab_classname_highlight = 'w3-bar-item w3-button w3-red w3-mobile'

search_tabs = dict_content['search-tab']
div_search_tabs = html.Div(
    children=[
                 html.A(className=tab_classname_highlight, children=search_tabs[0], id=f'{APPNAME}-search-tab-0', style=tab_style),
             ] + [
                 html.A(className=tab_classname_default, children=search_tabs[i + 1], id=f'{APPNAME}-search-tab-{i + 1}', style=tab_style)
                 for i in range(len(search_tabs) - 1)
             ],
    id=f'{APPNAME}-search-tabs', className='w3-white',
    style={'margin-top': '0px', 'padding-left': '0px', 'margin-right': '10px', 'margin-left': '10px'}
)


search_tab_0 = dict_content['search-tab'][0]
vis_tabs = dict_content['vis-tab'][search_tab_0]
div_vis_tabs = html.Div(
    children=[
                 html.A(className=tab_classname_highlight, children=vis_tabs[0], id=f'{APPNAME}-vis-tab-0', style=tab_style),
             ] + [
                 html.A(className=tab_classname_default, children=vis_tabs[i + 1], id=f'{APPNAME}-vis-tab-{i + 1}', style=tab_style)
                 for i in range(len(vis_tabs) - 1)
             ],
    id=f'{APPNAME}-tab_vis', className='w3-bar w3-white',
    style={'margin-top': '0px', 'padding-left': '0px'}
)


div_search_buttons = html.Div(children=[
    html.B('Material selections', id=f'{APPNAME}-text_line-1'),
    dcc.Dropdown(id=f'{APPNAME}-dropdown_material_selections',
                 options=[],
                 multi=True, clearable=False,
                 value=[],
                 placeholder='',
                 style={'width': '100%', 'height': 'auto', 'margin-bottom': '10px'}),

    html.B('Business Justification (optional): '),
    dcc.Textarea(
        id=f'{APPNAME}-business_justification',
        placeholder='Please input the business justification',
        value='',
        style={'width': '100%', 'height': '150px'},
    ),

    html.B('Additional comments/requests'),
    dcc.Textarea(
        id=f'{APPNAME}-additional_comments',
        placeholder='',
        value='',
        style={'width': '100%', 'height': '150px'},
    ),

    html.Button('Submit', id=f'{APPNAME}-Button-submit')
])


table_columns = ['Username', 'Materials', 'Status', 'Request Time', 'Complete Time']
div_vis_buttons = dcc.Loading(
    children=html.Div(
        children=[
            html.Div(id=f'{APPNAME}-vis-content-0', children=[
                'Just tell us a little bit about the purpose of requesting the 3D printed keychain. From Exceed ',
                html.Sup("TM"),
                ' (polyethylene), PP',
                html.Sup("TM"),
                ', Achieve',
                html.Sup("TM"),
                ' (polypropylene), HDPE, LLDPE to Vistamaxx',
                html.Sup("TM"),
                ' and Exact',
                html.Sup("TM"),
                ', We will do everything to 3D print a keychain with variety of materials of interest to enhance your and our customers\' '
                'experience of ExxonMobil polyolefin materials.',
                html.Br(),
                html.Div(children=[
                    html.Img(src=dict_image['keychain'],
                             style={'text-align': 'right', 'margin-right': '5px', 'margin-top': '10px', 'height': '350px'}),
                ], className='w3-center',),
            ]),
            html.Div(id=f'{APPNAME}-vis-content-1', children=[
                dash_table.DataTable(
                    id=f'{APPNAME}-vis-table-submit',
                    columns=[{'name': table_columns[i], 'id': table_columns[i]} for i in range(len(table_columns))],
                    data=[],
                    style_table={'padding-right': '5px', 'padding-left': '5px', 'margin-bottom': '5px',
                                 'width': '100%', 'height': '100%', 'overflow-y': 'scroll', 'overflow-x': 'scroll'},
                    style_cell={'whiteSpace': 'normal', 'fontSize': 13},
                    style_header={'backgroundColor': 'rgb(210, 210, 210)', 'color': 'black', 'fontWeight': 'bold',
                                  'border': '1px solid black'},
                    style_data={'border': '1px solid black', 'overflowX': 'auto'},
                    editable=True,
                    sort_action="native", filter_action='native',
                    sort_mode='multi',
                    page_current=0,
                    page_size=PAGE_SIZE,
                ),
            ])
        ], style={'margin-top': '10px'}
    )
)

div_query_display_switch = html.Button(
    children=[
        html.A(className='far fa-eye-slash', id=f'{APPNAME}-search-display_switch_icon'),
        html.A(' Hide queries', id=f'{APPNAME}-search-display_switch_text'),
    ],
    style={'width': '150px', 'height': TAB_HEIGHT, 'margin-right': '10px'},
    id=f'{APPNAME}-search-display_switch')


div_main_display = html.Div(id=f'{APPNAME}-div_main_display', children=[])


div_data_visualization_filters = html.Div(
    children=[
        div_search_tabs,
        html.Div(
            children=div_search_buttons,
            className='w3-light-grey',
            style={'padding-left': '15px', 'padding-right': '15px', 'margin-top': '10px'}
        ),
    ]
)

div_request_keychain = html.Div([
    dcc.Store(id=f'{APPNAME}-data_vis_memory_page', storage_type='memory'),
    dcc.Store(f'{APPNAME}-data_search_memory_data', storage_type='memory', data={'ind': 0}),
    dcc.Store(f'{APPNAME}-Store-vis_tab', storage_type='memory', data={'ind': 0}),
    dcc.ConfirmDialog(f'{APPNAME}-pop_up_window_submit_confirmation', message=''),
    html.Div(id=f'{APPNAME}-div_null'),
    html.Div([
        html.Div(
            id=f'{APPNAME}-query_filter',
            className='w3-col s5',
            children=[
                div_data_visualization_filters,
                dcc.Loading(
                    id=f'{APPNAME}-loading_main_data',
                    children=[
                        dcc.Store(f'{APPNAME}-data_memory_file_upload', storage_type='memory', data={}),
                    ],
                ),
            ], style={'border-right': '8px solid #ffffff'}
        ),
        html.Div(
            id=f'{APPNAME}-main_display',
            className='w3-col s7',
            children=[
                html.Div([
                    div_query_display_switch,
                    div_vis_tabs,
                ], style={'display': 'flex'}),
                div_vis_buttons,
                div_main_display,
        ], style={'padding-left': '10px'}),

    ], className='w3-row'),
])


@app.callback([Output(f'{APPNAME}-query_filter', 'style'), Output(f'{APPNAME}-main_display', 'className'),
               Output(f'{APPNAME}-search-display_switch_icon', 'className'), Output(f'{APPNAME}-search-display_switch_text', 'children')],
               Input(f'{APPNAME}-search-display_switch', 'n_clicks'))
def update_query_display_show_hide(_a):
    if _a is None:
        raise PreventUpdate
    if _a % 2 == 1:
        thisapp_search_display_switch_icon_classname = 'far fa-eye'
        thisapp_search_display_switch_text = ' Show queries'
        thisapp_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'none'}
        thisapp_main_display_classname = 'w3-col '
    else:
        thisapp_search_display_switch_icon_classname = 'far fa-eye-slash'
        thisapp_search_display_switch_text = ' Hide queries'
        thisapp_query_filter_style = {'border-right': '8px solid #ffffff', 'display': 'block'}
        thisapp_main_display_classname = 'w3-col s7'
    output = [thisapp_query_filter_style, thisapp_main_display_classname, thisapp_search_display_switch_icon_classname,
              thisapp_search_display_switch_text]
    return output


@app.callback([Output(f'{APPNAME}-dropdown_material_selections', 'options'), Output(f'{APPNAME}-dropdown_material_selections', 'value')],
               Input(f'{APPNAME}-div_null', 'n_clicks'))
def update_query_display_show_hide(_):
    if _ is None:
        command = f"""
            select Material from [dbo].[App3DprintMaterial] order by Category
            """
        pd_material = CACHE.exe_cloud_sql(command)
        options = ['ABS ExxonMobil Logo', 'ABS Name Tag'] + list(pd_material['Material'])
        values = [i for i in MATERIAL_SELECTIONS if i in options]
        return options, values
    else:
        return PreventUpdate


@app.callback(Output(f'{APPNAME}-pop_up_window_submit_confirmation', 'displayed'),
              Output(f'{APPNAME}-pop_up_window_submit_confirmation', 'message'),
              Output(f'{APPNAME}-business_justification', 'value'),
              Output(f'{APPNAME}-additional_comments', 'value'),
              Input(f'{APPNAME}-Button-submit', 'n_clicks'),
              State(f'{APPNAME}-dropdown_material_selections', 'value'),
              State(f'{APPNAME}-business_justification', 'value'), State(f'{APPNAME}-additional_comments', 'value'),
              State('root_memory_global', 'data'))
def submit_request(_, materials, justification, comment, glob_data):
    if _ is not None:
        if glob_data is None:
            user_info = glob_data['userinfo']
        else:
            user_info = CACHE.get_user_info()

        firstname = user_info['first_name']
        email = user_info['email']
        username = user_info['username']
        materials_str = ', '.join(materials)
        now_str = str(datetime.datetime.now())[:19]
        command = f"""
        insert into AppPMEECRequest (email, [username], [firstname], items, justification, comments, status, request_time) 
        values
        ('{email}', '{username}', '{firstname}', '{materials_str}', '{justification}', '{comment}', 'Submited', '{now_str}')"""
        CACHE.exe_cloud_sql(command)
        message = 'Your PMEEC keychain request has been submited. We will actively work on it. ' \
                  'Feel free to contact Yunsong Xie for any quesitons or concerns.'
        return True, message, '', ''
    else:
        return False, '', justification, comment


if len(vis_tabs) > 1:
    inputs_vis_tabs = [Input(f'{APPNAME}-vis-tab-{i}', 'n_clicks') for i in range(len(vis_tabs))]
    outputs_vis_tabs = [Output(f'{APPNAME}-Store-vis_tab', 'data')] + [Output(f'{APPNAME}-vis-tab-{i}', 'className') for i in range(len(vis_tabs))]
    states_vis_tabs = [Input(f'{APPNAME}-vis-tab-{i}', 'className') for i in range(len(vis_tabs))]

    @app.callback(outputs_vis_tabs, inputs_vis_tabs, states_vis_tabs)
    def update_vis_tab_classname(*args):
        trigger = callback_context.triggered[0]

        n_tabs = int(len(args) / 2)
        n_clicks = args[:n_tabs]
        bool_not_init = any([i is not None for i in n_clicks])
        if (type(trigger) is dict) & bool_not_init:
            item_click = trigger['prop_id'].split('.')[0].split('.')[0]
            ind_click = int(item_click.split('-')[-1])
            outputs_classname = [tab_classname_default] * n_tabs
            outputs_classname[ind_click] = tab_classname_highlight
            data_output = {'ind': ind_click}
        else:
            outputs_classname = [tab_classname_highlight] + [tab_classname_default] * (n_tabs - 1)
            data_output = {'ind': 0}

        outputs = [data_output] + outputs_classname
        return outputs


@app.callback(Output(f'{APPNAME}-vis-content-0', 'style'), Output(f'{APPNAME}-vis-content-1', 'style'),
              Output(f'{APPNAME}-vis-table-submit', 'data'),
              Input(f'{APPNAME}-Store-vis_tab', 'data'), State('root_memory_global', 'data'))
def update_vis_content(data_input, glob_data):
    if data_input['ind'] == 0:
        return {'display': 'block'}, {'display': 'None'}, []
    else:
        if glob_data is None:
            user_info = glob_data['userinfo']
        else:
            user_info = CACHE.get_user_info()

        email = user_info['email']
        command = f"""select [username], [items], status, request_time, complete_time from AppPMEECRequest where [email] = '{email}'"""
        pd_data = CACHE.exe_cloud_sql(command)
        dict_rename = {'username': 'Username', 'items': 'Materials', 'status': 'Status', 'request_time': 'Request Time', 'complete_time': 'Complete Time'}
        pd_data_query = pd_data.rename(columns=dict_rename)
        pd_data_query['Complete Time'] = pd_data_query['Complete Time'].fillna('')
        pd_data_query['Request Time'] = pd_data_query['Request Time'].astype('str')
        pd_data_query['Complete Time'] = pd_data_query['Complete Time'].astype('str')
        dict_data_query = pd_data_query.to_dict('record')
        return {'display': 'None'}, {'display': 'block'}, dict_data_query
