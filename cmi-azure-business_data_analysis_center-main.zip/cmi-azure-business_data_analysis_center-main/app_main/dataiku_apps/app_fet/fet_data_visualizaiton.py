# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

from dash import html, dcc, callback_context, dash_table
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dash.dependencies import Input, Output, State
import pandas as pd
import numpy as np
from math import floor, log10

from app_main.dataiku_apps.lib.main_lib import CACHE
#from dataiku_apps.lib.main_lib import CACHE

app = CACHE.app

DROPDOWN_WIDTH = 350

def smart_round(sig):
    def rounder(x):
        offset = sig - floor(log10(abs(x)))
        initial_result = round(x, offset)
        if str(initial_result)[-1] == '5' and initial_result == x:
            return round(x, offset - 2)
        else:
            return round(x, offset - 1)
    return rounder


CACHE.dict_activity_store['tab_main_material_visual'] = 'button_combined_spider_chart'

dict_filters = {'Product Family': 'product_family', 'Grade': 'grade',  'MFG Site': 'mfg_site',
                'MFG Line': 'mfg_line', 'Test Facility': 'test_facility', 'Test Method': 'test_method',
                'Test Standard': 'test_standard'}

tab_pad_top, tab_pad_bottom = 10, 10
#tab_style = {'padding-top': f'{tab_pad_top}px', 'padding-bottom': f'{tab_pad_bottom}px'}
tab_style = {'padding-top': f'{tab_pad_top}px', 'padding-bottom': f'{tab_pad_bottom}px'}
tab_classname_default = 'w3-bar-item w3-button w3-mobile'
tab_classname_highlight = 'w3-bar-item w3-button w3-red w3-mobile'
div_data_visualization_tabs = html.Div(
    children=[
        html.A(className=tab_classname_highlight,
               children=["Query Data to Proceed"],
               id='fet_tab_vis_0',
               style=tab_style),
        html.A(id='fet_tab_vis_1', style=tab_style, className=tab_classname_default),
        html.A(id='fet_tab_vis_2', style=tab_style, className=tab_classname_default),
        html.A(id='fet_tab_vis_3', style=tab_style, className=tab_classname_default),
        html.A(id='fet_tab_vis_4', style=tab_style, className=tab_classname_default),
        html.A(id='fet_tab_vis_5', style=tab_style, className=tab_classname_default),
        html.A(id='fet_tab_vis_6', style=tab_style, className=tab_classname_default),
        html.A(id='fet_tab_vis_7', style=tab_style, className=tab_classname_default),
        html.A(id='fet_tab_vis_8', style=tab_style, className=tab_classname_default)
    ], id='fet_tab_vis', className='w3-bar w3-white',  style={'margin-top': '0px', 'padding-left': '0px'})

DICT_PD_RENAME = {'productfamily': 'product_family', 'method': 'test_method', 'plotid': 'plot_id', 'PLOTID': 'plot_id',
                  'mfgsite': 'mfg_site', 'METHOD': 'test_method', 'GRADE': 'grade', 'MFGSITE': 'mfg_site',
                  'TESTSTANDARD': 'test_standard', 'TYPICALVALUE': 'typical_value',
                  'mfgline': 'mfg_line', 'testfacility': 'test_facility', 'teststandard': 'test_standard', 'sampleid': 'sample_id',
                  'lotid': 'lot_id', 'typicalvalue': 'typical_value', 'SALESSPEC': 'sales_spec', 'MFGTARGET': 'mfg_target',
                  'MFGLSL': 'mfg_lsl', 'MFGUSL': 'mfg_usl', 'TITLE': 'title', 'UNIT': 'unit', 'YLABEL': 'ylabel',
                  'LASTUPDATETIME': 'lastupdatetime'
                  }

dict_div_filters = {}
for key_filter in dict_filters:
    dcc_container = dcc.RadioItems if key_filter == 'Test Method' else dcc.Checklist
    dict_div_filters[key_filter] = html.Div([
        html.Div([
            key_filter,
            html.Button('Clear',
                        id=f'fet_button_clear_{dict_filters[key_filter]}',
                        style={'margin-right': '15px'},
                        className='w3-right')
        ], style={'width': '100%'}),
        dcc_container(
            options=[],
            labelStyle={'display': 'block', },
            inputStyle={"margin-right": "3px"},
            inline=False,
            labelClassName='Xchecklist',
            style={'height': '150px', 'width': '100%',
                   'overflow-y': 'scroll', 'background-color': 'white', 'hover-background-color': '#555555'},
            id=f'filter_{dict_filters[key_filter]}'
        )
    ], className='w3-col s6 w3-light-grey', style={'height': '150px', 'width': '50%', 'display': 'flex'}
    )

dict_div_filters['buttons'] = html.Div(
    children=[
        html.Div('Executions', style={'width': '150px'}),
        html.Div(children=[
            html.Button('Refresh Filters', id='fet_button_refresh'),
            html.Button('Query Data', id='fet_button_query_data')
        ],
            style={'height': '150px', 'width': '100%'}
    ),
], className='w3-col s6 w3-light-grey', style={'height': '150px', 'width': '50%', 'display': 'flex'}
)

n_col_filter = 2
n_row_filter = int(np.ceil(len(dict_div_filters) / n_col_filter))
dict_div_filters_keys = list(dict_div_filters.keys())
div_data_vis_filters_children = []
for row in range(n_row_filter):
    filters = dict_div_filters_keys[(row * n_col_filter): ((1 + row) * n_col_filter)]

    padding_top, padding_bottom = '5px', '5px'
    if row == 0:
        padding_top = '0px'
    if row == (n_row_filter - 1):
        padding_bottom = '0px'
    div_split = html.Div(
        children=[], className='w3-light-grey w3-row',
        style={'padding-left': '15px', 'padding-right': '15px', 'padding-top': padding_top, 'padding-bottom': padding_bottom})

    for col, filter in enumerate(filters):
        padding_left, padding_right = '5px', '5px'
        if col == 0:
            padding_left = '0px'
        if col == (n_col_filter - 1):
            padding_right = '0px'
        dict_div_filters[filter].style = {'padding-left': padding_left, 'padding-right': padding_right}
        div_split.children.append(dict_div_filters[filter])
    div_data_vis_filters_children.append(div_split)


div_data_visualization_filters = html.Div(
    children=[
        html.Div(children=div_data_vis_filters_children,
                 className='w3-light-grey',
                 style={'padding-left': '0px', 'padding-right': '5px', 'margin-top': '10px'}),
    ])


_column_names = ['Data Type', 'Product Family', 'Grade', 'Test Method', 'MFG Site', 'MFG Line', 'Test Facility', 'Test Standard', 'AVG',
                 'STD', 'Num']
_column_ids = ['data_type', 'product_family', 'grade', 'test_method', 'mfg_site', 'mfg_line', 'test_facility', 'test_standard', 'avg',
               'std', 'num', ]


div_show_visual = html.Div(
    id='div_main_visual',
    children=[
        dash_table.DataTable(
            id='fet_table_data_type',
            columns=([{'name': 'Data Type', 'id': 'data_type', 'presentation': 'dropdown'}] +
                     [{'name': _column_names[i], 'id': _column_ids[i]} for i in range(len(_column_names)) if _column_ids[i] != 'data_type']
                     ),
            data=[],
            style_table={'padding-right': '5px', 'padding-left': '5px', 'margin-bottom': '5px'},
            style_cell={'whiteSpace': 'normal'},
            style_header={'backgroundColor': 'rgb(210, 210, 210)', 'color': 'black', 'fontWeight': 'bold',
                          'border': '1px solid black'},
            style_cell_conditional=[
                {'if': {'column_id': 'product_family'}, 'width': '70px', 'minWidth': '70px', 'maxWidth': '70px'},
                {'if': {'column_id': 'grade'}, 'width': '135px', 'minWidth': '135px', 'maxWidth': '135px'},
                {'if': {'column_id': 'test_method'}, 'width': '120px', 'minWidth': '120px', 'maxWidth': '120px'},
                {'if': {'column_id': 'mfg_site'}, 'width': '50px', 'minWidth': '50px', 'maxWidth': '50px'},
                {'if': {'column_id': 'mfg_line'}, 'width': '50px', 'minWidth': '50px', 'maxWidth': '50px'},
                {'if': {'column_id': 'test_facility'}, 'width': '70px', 'minWidth': '70px', 'maxWidth': '70px'},
                {'if': {'column_id': 'test_standard'}, 'width': '70px', 'minWidth': '70px', 'maxWidth': '70px'},
                {'if': {'column_id': 'avg'}, 'width': '90px', 'minWidth': '90px', 'maxWidth': '90px'},
                {'if': {'column_id': 'std'}, 'width': '90px', 'minWidth': '90px', 'maxWidth': '90px'},
                {'if': {'column_id': 'num'}, 'width': '60px', 'minWidth': '60px', 'maxWidth': '60px'},
                {'if': {'column_id': 'data_type'}, 'width': '100px', 'minWidth': '100px', 'maxWidth': '100px', },
            ],
            style_data={'border': '1px solid black'},
            editable=True,
            dropdown={'data_type': {
                'options': [{'label': i, 'value': i} for i in ['Control', 'Experiment', 'Show', 'Ignore']],
                'clearable': False,
            }},
            sort_action="native",
            sort_mode='multi',
        ),
        dcc.Graph(id="fet_graph_main_vis", className='w3-light-grey')
    ]
)

_column_id_raw = ['product_family', 'grade', 'test_method', 'mfg_site', 'mfg_line', 'test_facility',
                  'test_standard', 'sample_id', 'lot_id', 'value', 'lastupdatetime']
_column_names_raw = ['Product Family', 'Grade', 'Test Method', 'MFG Site', 'MFG Line', 'Test Facility', 'Test Standard', 'Sample ID',
                     'Lot ID', 'Value', 'Date']
div_show_table = html.Div(
    id='div_main_data_raw',
    children=[
        dash_table.DataTable(
            id='fet_table_data_raw',
            columns=([{'name': _column_names_raw[i], 'id': _column_id_raw[i]} for i in range(len(_column_id_raw))]
                     ),
            data=[],
            style_table={'padding-right': '5px', 'padding-left': '5px'},
            style_cell={'whiteSpace': 'normal'},
            style_header={'backgroundColor': 'rgb(210, 210, 210)', 'color': 'black', 'fontWeight': 'bold',
                          'border': '1px solid black'},
            style_cell_conditional=[
                {'if': {'column_id': 'product_family'}, 'width': '70px', 'minWidth': '70px', 'maxWidth': '70px'},
                {'if': {'column_id': 'grade'}, 'width': '135px', 'minWidth': '135px', 'maxWidth': '135px'},
                {'if': {'column_id': 'test_method'}, 'width': '120px', 'minWidth': '120px', 'maxWidth': '120px'},
                {'if': {'column_id': 'mfg_site'}, 'width': '50px', 'minWidth': '50px', 'maxWidth': '50px'},
                {'if': {'column_id': 'mfg_line'}, 'width': '50px', 'minWidth': '50px', 'maxWidth': '50px'},
                {'if': {'column_id': 'test_facility'}, 'width': '70px', 'minWidth': '70px', 'maxWidth': '70px'},
                {'if': {'column_id': 'test_standard'}, 'width': '70px', 'minWidth': '70px', 'maxWidth': '70px'},
                {'if': {'column_id': 'sample_id'}, 'width': '90px', 'minWidth': '90px', 'maxWidth': '90px'},
                {'if': {'column_id': 'lot_id'}, 'width': '90px', 'minWidth': '90px', 'maxWidth': '90px'},
                {'if': {'column_id': 'value'}, 'width': '90px', 'minWidth': '90px', 'maxWidth': '90px'},
                {'if': {'column_id': 'lastupdatetime'}, 'width': '90px', 'minWidth': '90px', 'maxWidth': '90px'},
            ],
            style_data={'border': '1px solid black'},
            editable=True,
            sort_action="native",
            sort_mode='multi',
        )
    ],
    style={'display': 'none'}
)

div_data_visualization = html.Div([
    dcc.Store(id='fet_data_vis_memory_page', storage_type='memory'),
    dcc.Store(id='fet_data_vis_memory_data', storage_type='memory'),
    dcc.Store(id='fet_data_vis_memory_tabs', storage_type='memory', data={}),
    dcc.Store(id='fet_data_vis_memory_figure', storage_type='memory', data={'plot_type': 'scatter'}),
    dcc.ConfirmDialog(id='fet_pop_up_window', message=''),
    html.Div(id='fet_data_vis_div_null'),
    html.Div([
        html.Div(
            className='w3-col s4',
            children=[
                div_data_visualization_filters
            ], style={'border-right': '8px solid #ffffff'}
        ),
        html.Div(
            className='w3-col s8',
            children=[
                html.Div(div_data_visualization_tabs),
                html.H6([
                    'Experiment/Control specification - ',
                    html.Button('Generate Scatter Plot', id='fet_button_plot_figure_scatter', style={'margin-left': '10px'}),
                    html.Button('Generate Box Plot', id='fet_button_plot_figure_box', style={'margin-left': '10px'}),
                    html.Button('Show Data Table', id='fet_button_show_table', style={'margin-left': '10px'}),
                ]),
                div_show_visual,
                div_show_table

        ], style={'padding-left': '10px'}),

    ], className='w3-row'),
])


def parse_filter(value_list):
    if value_list is None:
        value_list_parsed = []
    elif type(value_list) is str:
        value_list_parsed = [value_list]
    elif len(value_list) == 0:
        value_list_parsed = []
    else:
        value_list_parsed = value_list
    return value_list_parsed


@app.callback(Output('div_main_visual', 'style'),
              Output('div_main_data_raw', 'style'),
              Input('fet_button_plot_figure_scatter', 'n_clicks'),
              Input('fet_button_plot_figure_box', 'n_clicks'),
              Input('fet_button_show_table', 'n_clicks'), )
def update_main_content(_a, _b, _c):
    trigger = callback_context.triggered[0]
    if type(trigger) is dict:
        if 'prop_id' in trigger:
            if 'fet_button_show_table' in trigger['prop_id']:
                return {'display': 'none'}, {'display': 'block'}
    return {'display': 'block'}, {'display': 'none'}


@app.callback(Output('fet_table_data_raw', 'data'),
              Input('fet_button_show_table', 'n_clicks'),
              State('fet_data_vis_memory_data', 'data'),
              State('fet_data_vis_memory_tabs', 'data'),
              )
def update_graph_main_vis(_a, vis_memory_data, tab_selection_data):
    if (vis_memory_data is None) | (tab_selection_data is None):
        bool_null = True
    elif (len(vis_memory_data) == 0) | (len(tab_selection_data) == 0):
        bool_null = True
    elif 'index' not in tab_selection_data:
        bool_null = True
    else:
        bool_null = False
    if bool_null:
        return []
    else:
        tab_selection = int(tab_selection_data['index'])
        pd_plot_data_raw = pd.DataFrame(vis_memory_data['pd_plot_data'])
        pd_plot_data = pd_plot_data_raw.loc[(pd_plot_data_raw.plot_id == tab_selection)].copy()
        pd_plot_data['lastupdatetime'] = pd_plot_data['lastupdatetime'].astype(str).str[:10]
        pd_plot_data['value'] = pd_plot_data['value'].apply(smart_round(5))
        return pd_plot_data.to_dict('record')


@app.callback(Output('fet_data_vis_memory_page', 'data'),
              Output('filter_product_family', 'options'),Output('filter_grade', 'options'),
              Output('filter_mfg_site', 'options'), Output('filter_mfg_line', 'options'),
              Output('filter_test_facility', 'options'), Output('filter_test_method', 'options'),
              Output('filter_test_standard', 'options'),
              Input('fet_data_vis_div_null', 'n_clicks'),
              Input('fet_button_refresh', 'n_clicks'),
              State('filter_product_family', 'options'))
def update_product_family(_a, _b, data_input):
    bool_pull = False
    if len(data_input) == 0:
        bool_pull = True
    else:
        trigger = callback_context.triggered[0]
        if type(trigger) is dict:
            if 'prop_id' in trigger:
                if 'fet_button_refresh' in trigger['prop_id']:
                    bool_pull = True
    if bool_pull:
        query = """select distinct productfamily as product_family, grade, method as test_method, 
        mfgsite as mfg_site, mfgline as mfg_line, testfacility as test_facility, teststandard as test_standard from FETPlotData"""
        pd_filter = CACHE.exe_cloud_sql('CMIDataikuYunsongTest', query)
        dict_pd_filter = pd_filter.to_dict('list')
        data = {'pd_filters': dict_pd_filter}
    else:
        data = data_input
    option_product_familiy = [{'label': i, 'value': i} for i in sorted(set(data['pd_filters']['product_family']))]
    option_grade = [{'label': i, 'value': i} for i in sorted(set(data['pd_filters']['grade']))]
    option_mfg_site = [{'label': i, 'value': i} for i in sorted(set(data['pd_filters']['mfg_site']))]
    option_mfg_line = [{'label': i, 'value': i} for i in sorted(set(data['pd_filters']['mfg_line']))]
    option_test_facility = [{'label': i, 'value': i} for i in sorted(set(data['pd_filters']['test_facility']))]
    option_test_method = [{'label': i, 'value': i} for i in sorted(set(data['pd_filters']['test_method']))]
    option_test_standard = [{'label': i, 'value': i} for i in sorted(set(data['pd_filters']['test_standard']))]

    return data, option_product_familiy, option_grade, option_mfg_site, option_mfg_line, option_test_facility, \
           option_test_method, option_test_standard


def update_filter_values(_a, options, values, output_type='list'):
    trigger = callback_context.triggered[0]
    if type(trigger) is dict:
        if 'prop_id' in trigger:
            if 'fet_button_clear' in trigger['prop_id']:
                return [] if output_type == 'list' else None
    if (options is None) | (values is None):
        return [] if output_type == 'list' else None
    values_option = [i['value'] for i in options]
    if output_type == 'list':
        values_output = [i for i in values if i in values_option]
        return values_output
    else:
        values_output = values if values in values_option else None
        return values_output


list_filter_list = {'product_family', 'grade', 'mfg_site', 'mfg_line', 'test_facility', 'test_standard'}
for key in list_filter_list:
    @app.callback(Output(f'filter_{key}', 'value'),
                  Input(f'fet_button_clear_{key}', 'n_clicks'),
                  Input(f'filter_{key}', 'options'),
                  State(f'filter_{key}', 'value'))
    def clear_filter(_a, options, values):
        result = update_filter_values(_a, options, values, 'list')
        return result
entry_filter_list = {'test_method'}
for key in entry_filter_list:
    @app.callback(Output(f'filter_{key}', 'value'),
                  Input(f'fet_button_clear_{key}', 'n_clicks'),
                  Input(f'filter_{key}', 'options'),
                  State(f'filter_{key}', 'value'))
    def clear_filter(_a, options, values):
        result = update_filter_values(_a, options, values, 'str')
        return result


@app.callback(Output('fet_data_vis_memory_data', 'data'),
              Output('fet_pop_up_window', 'displayed'),
              Output('fet_pop_up_window', 'message'),
              Input('fet_button_query_data', 'n_clicks'),
              State('filter_product_family', 'value'),
              State('filter_grade', 'value'),
              State('filter_mfg_site', 'value'),
              State('filter_mfg_line', 'value'),
              State('filter_test_facility', 'value'),
              State('filter_test_method', 'value'),
              State('filter_test_standard', 'value'),
              )
def query_plot_data(_a, product_families, grades, mfg_sites, mfg_lines, test_facilities, test_method, test_standards):
    if ((product_families is None) & (grades is None) & (mfg_sites is None) & (mfg_lines is None)
            & (test_facilities is None) & (test_standards is None)):
        return {}, False, ''

    if ((product_families is None) | (grades is None) | (mfg_sites is None) | (mfg_lines is None)
            | (test_facilities is None) | (test_standards is None)):
        return {}, True, f'This query returns zero data entry, please check filter selections'

    if ((len(product_families) == 0) | (len(grades) == 0) | (len(mfg_sites) == 0) | (len(mfg_lines) == 0) |
            (len(test_facilities) == 0) | (len(test_standards) == 0)):
        return {}, True, f'This query returns zero data entry, please check filter selections'
    if test_method is None:
        return {}, True, f'This query returns zero data entry, please check filter selections'

    if 'test' == 'test1':
        product_families, grades = ['PP'], ['APO3B']
        mfg_sites, mfg_lines = ['BTPP', 'SPP'], [1, 8]
        test_facilities, test_method = ['BTEC'], 'Flex A'
        test_standards = ['ISO']

    test_methods = [test_method]
    mfg_lines = [str(i) for i in mfg_lines]
    _ = "', '".join(product_families)
    query_1 = f"(productfamily in ('{_}'))"
    _ = "', '".join(grades)
    query_2 = f"(grade in ('{_}'))"
    _ = "', '".join(mfg_sites)
    query_3 = f"(mfgsite in ('{_}'))"
    _ = ", ".join(mfg_lines)
    query_4 = f"(mfgline in ({_}))"
    _ = "', '".join(test_facilities)
    query_5 = f"(testfacility in ('{_}'))"
    _ = "', '".join(test_methods)
    query_6 = f"(method in ('{_}'))"
    _ = "', '".join(test_standards)
    query_7 = f"(teststandard in ('{_}'))"
    command_data = f'''select productfamily, grade, method, plotid, mfgsite, mfgline, testfacility, teststandard, 
sampleid, lotid, avg(value) as value, max(lastupdatetime) as lastupdatetime from FETPlotData 
where {query_1} and {query_2} and {query_3} and {query_4} and {query_5} and {query_6} and {query_7} 
group by 
productfamily, grade, method, plotid, mfgsite, mfgline, testfacility, teststandard, sampleid, lotid'''
    pd_plot_data = CACHE.exe_cloud_sql('CMIDataikuYunsongTest', command_data).rename(columns=DICT_PD_RENAME)

    if len(pd_plot_data) == 0:
        return {}, True, f'This query returns zero data entry'

    command_spec = f'''select * from FETSpec where {query_2} and {query_3} and {query_6} and {query_7}'''
    pd_spec = CACHE.exe_cloud_sql('CMIDataikuYunsongTest', command_spec).rename(columns=DICT_PD_RENAME)
    command_figure_info = f'''select * from FETFigureInfo where {query_6}'''

    pd_figure_info = CACHE.exe_cloud_sql('CMIDataikuYunsongTest', command_figure_info).rename(columns=DICT_PD_RENAME)
    output_data = {'pd_plot_data': pd_plot_data.to_dict('list'),
                   'pd_spec': pd_spec.to_dict('list'),
                   'pd_figure_info': pd_figure_info.to_dict('list')}

    pd_figure_info_in_data = pd_plot_data[['test_method', 'plot_id']].drop_duplicates()
    pd_figure_info_miss = pd_figure_info.merge(pd_figure_info_in_data, on=['test_method', 'plot_id'], how='right')

    pd_figure_info_miss = pd_figure_info_miss.loc[pd_figure_info_miss.title.isna()]


    if len(pd_figure_info_miss) > 1:
        info_miss = pd_figure_info_miss[['test_method', 'plot_id']].to_dict('record')
        return {}, True, f'There is missing figure info in FETFigureInfo for {info_miss}'
    else:
        return output_data, False, ''


@app.callback(Output('fet_tab_vis_0', 'children'), Output('fet_tab_vis_1', 'children'), Output('fet_tab_vis_2', 'children'),
              Output('fet_tab_vis_3', 'children'), Output('fet_tab_vis_4', 'children'), Output('fet_tab_vis_5', 'children'),
              Output('fet_tab_vis_6', 'children'), Output('fet_tab_vis_7', 'children'), Output('fet_tab_vis_8', 'children'),
              Input('fet_data_vis_memory_data', 'data'))
def update_tab_vis(vis_memory_data):
    if vis_memory_data is None:
        bool_null = True
    elif len(vis_memory_data) == 0:
        bool_null = True
    else:
        bool_null = False
    if bool_null:
        return 'Query Data to Proceed', None, None, None, None, None, None, None, None
    else:
        titles = list(vis_memory_data['pd_figure_info']['title'])

        if len(titles) < 9:
            titles = titles + [None] * (9 - len(titles))
        return titles


@app.callback(Output('fet_tab_vis_0', 'className'), Output('fet_tab_vis_1', 'className'), Output('fet_tab_vis_2', 'className'),
              Output('fet_tab_vis_3', 'className'), Output('fet_tab_vis_4', 'className'), Output('fet_tab_vis_5', 'className'),
              Output('fet_tab_vis_6', 'className'), Output('fet_tab_vis_7', 'className'), Output('fet_tab_vis_8', 'className'),
              Output('fet_data_vis_memory_tabs', 'data'),
              Input('fet_tab_vis_0', 'n_clicks'), Input('fet_tab_vis_1', 'n_clicks'), Input('fet_tab_vis_2', 'n_clicks'),
              Input('fet_tab_vis_3', 'n_clicks'), Input('fet_tab_vis_4', 'n_clicks'), Input('fet_tab_vis_5', 'n_clicks'),
              Input('fet_tab_vis_6', 'n_clicks'), Input('fet_tab_vis_7', 'n_clicks'), Input('fet_tab_vis_8', 'n_clicks'),
              Input('fet_data_vis_memory_data', 'data'))
def update_tab_vis_classname(_0, _1, _2, _3, _4, _5, _6, _7, _8, vis_memory_data):
    if vis_memory_data is None:
        bool_null = True
    elif len(vis_memory_data) == 0:
        bool_null = True
    else:
        bool_null = False
    classnames = [tab_classname_default] * 9
    index_pressed = 0
    if bool_null:
        classnames[0] = tab_classname_highlight
    else:
        trigger = callback_context.triggered[0]
        if type(trigger) is dict:
            if 'prop_id' in trigger:
                if 'fet_tab_vis_' in trigger['prop_id']:
                    index_pressed = int(trigger['prop_id'].split('.')[0][-1])
    classnames[index_pressed] = 'w3-bar-item w3-button w3-red w3-mobile'
    output = classnames + [{'index': str(index_pressed)}]
    return output


@app.callback(Output('fet_table_data_type', 'data'),
              Input('fet_data_vis_memory_tabs', 'data'),
              Input('fet_data_vis_memory_data', 'data'),
              State('fet_table_data_type', 'data'),)
def update_table_data_type(tab_selection_data, vis_memory_data, last_data):
    if (vis_memory_data is None) | (tab_selection_data is None):
        bool_null = True
    elif (len(vis_memory_data) == 0) | (len(tab_selection_data) == 0):
        bool_null = True
    else:
        bool_null = False
    if bool_null:
        return last_data
    else:
        tab_selection = int(tab_selection_data['index'])
        pd_plot_data_raw = pd.DataFrame(vis_memory_data['pd_plot_data'])
        pd_plot_data = pd_plot_data_raw.loc[pd_plot_data_raw.plot_id == tab_selection]
        group_cols = ['product_family', 'grade', 'test_method', 'plot_id', 'mfg_site', 'mfg_line', 'test_facility', 'test_standard']
        pd_data_show = pd_plot_data.groupby(group_cols)['value'].agg(['mean', 'std', 'size']).reset_index()
        pd_data_show['mean'] = pd_data_show['mean'].apply(smart_round(5))
        pd_data_show['std'] = pd_data_show['std'].apply(smart_round(5))
        pd_data_show = pd_data_show.rename(columns={'mean': 'avg', 'size': 'num'})
        pd_data_show['data_type'] = 'Control'
        return pd_data_show.to_dict('record')


@app.callback(Output('fet_graph_main_vis', 'figure'),
              Input('fet_button_plot_figure_scatter', 'n_clicks'),
              Input('fet_button_plot_figure_box', 'n_clicks'),
              State('fet_data_vis_memory_data', 'data'),
              State('fet_data_vis_memory_tabs', 'data'),
              State('fet_table_data_type', 'data'),
              )
def update_graph_main_vis(_a, _b, vis_memory_data, tab_selection_data, display_table_data):
    if (vis_memory_data is None) | (tab_selection_data is None):
        bool_null = True
    elif (len(vis_memory_data) == 0) | (len(tab_selection_data) == 0):
        bool_null = True
    elif 'index' not in tab_selection_data:
        bool_null = True
    else:
        bool_null = False
    if bool_null:
        return make_subplots(rows=1, cols=1, vertical_spacing=0.075, horizontal_spacing=0.125, subplot_titles=[''])
    else:
        trigger = callback_context.triggered[0]
        if type(trigger) is dict:
            if 'prop_id' in trigger:
                if 'fet_button_plot_figure_scatter' in trigger['prop_id']:
                    plot_type = 'scatter'
                elif 'fet_button_plot_figure_box' in trigger['prop_id']:
                    plot_type = 'box'
                else:
                    _button = trigger['prop_id']
                    raise ValueError(f'Not able to recognize input button {_button}')
        tab_selection = int(tab_selection_data['index'])
        pd_plot_data_raw = pd.DataFrame(vis_memory_data['pd_plot_data'])
        pd_plot_data = pd_plot_data_raw.loc[(pd_plot_data_raw.plot_id == tab_selection)]

        pd_spec = pd.DataFrame(vis_memory_data['pd_spec'])
        pd_spec = pd_spec.loc[pd_spec.plot_id == tab_selection]
        pd_figure_info = pd.DataFrame(vis_memory_data['pd_figure_info'])

        pd_display_data = pd.DataFrame(display_table_data)


        pd_display_data = pd_display_data.loc[pd_display_data.data_type != 'Ignore']
        merge_cols = ['grade', 'test_method', 'plot_id', 'mfg_site', 'mfg_line', 'test_facility', 'test_standard']
        pd_plot_data = pd_plot_data.merge(pd_display_data, on=merge_cols, how='inner')
        pd_plot_data['value'] = pd_plot_data['value'].apply(smart_round(5))

        unit = pd_figure_info.iloc[0]['unit']

        n_row, n_col = 1, 1
        title, ylabel = pd_figure_info.loc[pd_figure_info.plot_id == tab_selection].iloc[0][['title', 'ylabel']]
        fig = make_subplots(rows=n_row, cols=n_col, vertical_spacing=0.075, horizontal_spacing=0.125,
                            subplot_titles=[f"<b>{title}</b>"])

        merge_cols = ['grade', 'mfg_site', 'mfg_line', 'test_facility', 'test_standard']
        show_cols = merge_cols + ['data_type']
        pd_display_data['label'] = [', '.join([str(i) for i in pd_display_data.iloc[j][show_cols].values])
                                    for j in range(len(pd_display_data))]
        pd_control = pd_display_data.loc[pd_display_data.data_type == 'Control']
        points = np.asarray(pd_plot_data.merge(pd_control, on=merge_cols, how='inner')['value'])
        y_sigma_p = smart_round(5)(points.mean() + 3 * points.std())
        y_sigma_n = smart_round(5)(points.mean() - 3 * points.std())
        if plot_type == 'box':
            for i_label, plot_label in enumerate(list(pd_display_data['label'])):
                pd_entry = pd_display_data.iloc[[i_label]]
                points = list(pd_plot_data.merge(pd_entry, on=merge_cols, how='inner')['value'])
                label_front = ', '.join(plot_label.split(', ')[:-1])
                label_back = plot_label.split(', ')[-1]
                plot_label_final = f'{label_front}<br>{label_back}'
                #plot_label_final = plot_label
                fig.add_trace(go.Box(
                    y=points,
                    name=plot_label_final,
                    jitter=0.3,
                    pointpos=0,
                    boxpoints='all',
                ))
        else:
            i_start = 0
            symbols = ['circle', 'square', 'diamond', 'cross', 'x', 'triangle-up', 'triangle-down', 'triangle-left', 'triangle-right']
            symbols = symbols * 5
            for i_label, plot_label in enumerate(list(pd_display_data['label'])):
                pd_entry = pd_display_data.iloc[[i_label]]
                pd_points = pd_plot_data.merge(pd_entry, on=merge_cols, how='inner')
                points = list(pd_points['value'])
                x = np.arange(len(points)) + i_start
                label_front = ', '.join(plot_label.split(', ')[:-1])
                label_back = plot_label.split(', ')[-1]
                plot_label_final = f'{label_front}<br>{label_back}'
                # text_show = [f'{plot_properties_show[i].replace("<br>", " ")}<br>{r_show[i]} {DICT_UNIT[col]}'
                #              for i, col in enumerate(dict_plot_properties_rename)]
                # hovertext = text_show + [text_show[0]]
                # fig.add_trace(go.Scatterpolar(name=dict_name[i_process_type], r=r_plot, theta=theta_plot, showlegend=bool_legend,
                #                               marker_color=color, hovertext=hovertext, hoverinfo="text"),
                #               row=ind_row, col=ind_col)
                hovertext = [f"{label_front}<br>Sample ID: {pd_points.iloc[i]['sample_id']}<br>" \
                             f"Lot ID: {pd_points.iloc[i]['lot_id']}<br>{points[i]} {unit}"
                             for i in range(len(x))]
                fig.add_scatter(x=x, y=points, name=plot_label_final, showlegend=True, mode='markers', hoverinfo="text",
                                hovertext=hovertext,
                                marker={'size': 15, 'line': {'width': 1, 'color': 'DarkSlateGrey'}, 'symbol': symbols[i_label]})
                i_start += len(points)
            fig.update_xaxes(showticklabels=False)

        fig.layout.xaxis2 = go.layout.XAxis(overlaying='x', range=[0, 2], showticklabels=False)
        x_line = np.linspace(0, 2, 20)
        hovertext_3sigma_p = [f'+3σ: {y_sigma_p} {unit}'] * len(x_line)
        fig.add_scatter(x=x_line, y=[y_sigma_p] * 20, mode='lines', xaxis='x2', name=r'+3σ', hoverinfo="text",
                        hovertext=hovertext_3sigma_p,
                        showlegend=True, line=dict(dash='dash', color="#636EFA", width=2))
        hovertext_3sigma_n = [f'-3σ: {y_sigma_n} {unit}'] * len(x_line)
        fig.add_scatter(x=x_line, y=[y_sigma_n] * 20, mode='lines', xaxis='x2', name=r'-3σ', hoverinfo="text",
                        hovertext=hovertext_3sigma_n,
                        showlegend=True, line=dict(dash='dash', color="#636EFA", width=2))

        merge_cols_1 = ['grade', 'mfg_site', 'test_standard']
        pd_spec = pd_spec.merge(pd_display_data[merge_cols_1].drop_duplicates(), on=merge_cols_1, how='inner')
        plot_cols = ['typical_value', 'sales_spec', 'mfg_target', 'mfg_lsl', 'mfg_usl']
        dict_rename = {'typical_value': 'Typical Value', 'sales_spec': 'Sales Spec', 'mfg_target': 'MFG Target',
                       'mfg_lsl': 'MFG LSL', 'mfg_usl': 'MFG USL'}
        for i in range(len(pd_spec)):
            pd_entry = pd_spec.iloc[i]
            for plot_col in plot_cols:
                if pd_entry[plot_col] is not None:
                    label = ', '.join(pd_entry[merge_cols_1].values)
                    label = label + ' - ' + dict_rename[plot_col]
                    value = pd_entry[plot_col]
                    if ('Target' in dict_rename[plot_col]) | ('Typical Value' in dict_rename[plot_col]):
                        color = '#636EFA'
                    else:
                        color = '#D62728'
                    hovertext = [f'{label}: {value} {unit}'] * len(x_line)
                    fig.add_scatter(x=x_line, y=[value] * 20, mode='lines', xaxis='x2', name=label, hovertext=hovertext,
                                    hoverinfo="text", showlegend=True, line=dict(color=color, width=2))
        fig.update_layout(yaxis_title=ylabel)
        fig.update_layout(margin={'l': 40, 'r': 40, 't': 40, 'b': 20})
        return fig
