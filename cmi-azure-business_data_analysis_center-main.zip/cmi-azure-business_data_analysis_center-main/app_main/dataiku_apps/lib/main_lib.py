# Email: yunsong.xie@exxonmobil.com
# Author: Yunsong Xie
import os, xlrd, sqlite3, datetime, time, traceback, sys, queue, datetime, requests
import pandas as pd
import numpy as np
from flask import request, url_for
from itertools import product
import struct, os
from scipy import interpolate
from flask import redirect, url_for

from app_main.create_instance import app_flask
from app_main import aad_auth

from ..glob_env import DIR, DIR_DATA, DICT_PATH_EXCEL, DICT_PATH_DB, LABEL_SYSTEM, DIR_ROOT, DIR_DOWNLOAD
from app_main.config import isProd, ODBC_STR_TEMP
import flask
import jwt
from flask_dance.contrib.azure import azure

pd.set_option("display.max_columns", None)
pd.set_option("display.max_row", 25)
pd.set_option("display.max_colwidth", 40)
pd.set_option("display.width", 3000)

from sqlalchemy import create_engine
from sqlalchemy.engine import URL

DBNAME = 'CMIDataikuYunsongTest'

def get_date(days):
    _date = pd.to_datetime(datetime.datetime.now()) + pd.Timedelta(f'{days} days')
    return str(_date)[:10]


class TdPrintDataProcess:
    def __int__(self):
        return None

    @staticmethod
    def get_excel_data(path_excel):
        """
        Main file to get data from original excel file.
        Args:
            path_excel: Path of the excel file.

        Returns:
            (dict): Keys include ['polymer', 'material', 'material_composition', 'print_condition', 'unit',
                                  'post_manufacturing_property', 'polymer_property', 'material_composition_cleaned']
                    Each key include a pandas dataframe that correspond to the data in the excel file.

        """
        wb = xlrd.open_workbook(path_excel)
        DICT_DATA = {}
        for sheet in wb.sheets():
            ncols = sheet.ncols
            dict_sheet = {}
            for i_col in range(ncols):
                col_values = sheet.col_values(i_col)
                dict_sheet[col_values[0]] = col_values[1:]
            pd_sheet = pd.DataFrame(dict_sheet)
            DICT_DATA[sheet.name] = pd_sheet
        pd_property_temp = DICT_DATA['post_manufacturing_property'].copy()
        pd_temp_1 = pd_property_temp['process_type'].replace({'Injection Molding-IM': 'IM',
                                                              'Fused Deposition Manufacturing-FDM': 'FDM'})
        DICT_DATA['post_manufacturing_property']['material_id_str'] = pd_property_temp['material_name'] + '-' + pd_temp_1
        pd_temp_2 = DICT_DATA['post_manufacturing_property'].copy()
        for key in pd_temp_2.columns:
            if 'float' not in str(pd_temp_2[key].dtype):
                pd_temp_2[key] = pd_temp_2[key].replace({'': np.nan, ' ': np.nan})
        DICT_DATA['post_manufacturing_property'] = pd_temp_2.loc[~pd_temp_2['youngs_modulus'].isna()].copy()
        DICT_DATA['print_condition'].columns = [i.strip() for i in DICT_DATA['print_condition'].columns]
        DICT_DATA['polymer_property'] = DICT_DATA['polymer_property'].rename(columns={'polymer_name': 'Polymer Name',
                                                                                      'Ethylene content': 'Ethylene Content'})
        DICT_DATA['polymer_property'].columns = [i.strip() for i in DICT_DATA['polymer_property'].columns]
        DICT_DATA['unit'] = DICT_DATA['unit'].rename(columns={'properties ': 'properties'})

        pd_component = DICT_DATA['material_composition'].rename(
            columns={'material_name': 'Material Name', 'material_type': 'Material Type',
                     'percentage': 'Percentage', 'polymer_name': 'Polymer'})
        pd_component = pd_component.drop_duplicates()
        pd_component['Percentage'] = pd_component['Percentage'].astype(int)
        merge_cols = ['Material Name', 'Material Type']
        pd_component['rank'] = pd_component.groupby('Material Name')['Percentage'].rank(ascending=False, method='first')
        N_component_max = int(pd_component['N_component'].max())

        pd_base = pd_component[['Material Name', 'Material Type']].drop_duplicates()
        for i in range(N_component_max):
            pd_add = pd_component.loc[pd_component['rank'] == (i + 1)][merge_cols + ['Percentage', 'Polymer']]
            dict_seq_text = {0: '1st', 1: '2nd', 2: '3rd', 3: '4th', 4: '5th', 5: '6th', 6: '7th'}
            pd_add = pd_add.rename(columns={'Percentage': f'{dict_seq_text[i]} Percentage',
                                            'Polymer': f'{dict_seq_text[i]} Polymer'})
            pd_base = pd_base.merge(pd_add, on=merge_cols, how='outer').fillna('')
        DICT_DATA['material_composition_cleaned'] = pd_base

        return DICT_DATA


DICT_DATA = TdPrintDataProcess().get_excel_data(DICT_PATH_EXCEL['3d_printing'])


def make_cloud_con_windows(db_name):
    connection_url = URL.create("mssql+pyodbc", query={"odbc_connect": ODBC_STR_TEMP})
    con = create_engine(connection_url)
    return con

dict_image = {
    'main_page-chemical_site': 'https://matdbstorage.blob.core.windows.net/yunsong-test/Main-Singapore_Chemical_Plant_Expansion_photo.jpg?sp=r&st=2022-09-21T03:50:59Z&se=2222-09-21T11:50:59Z&sv=2021-06-08&sr=b&sig=%2BJGMfvySbpb85CLPEfzKuhKlbxJncsp9eix9cHUYvtI%3D',
    'main_page-Axiom_3d_printing': 'https://matdbstorage.blob.core.windows.net/yunsong-test/Main-Axiom_3d_printer.png?sp=r&st=2022-09-21T04:04:45Z&se=2222-09-21T12:04:45Z&sv=2021-06-08&sr=b&sig=7hXDcxk9KYcYvlnR1w0Eo6SESrDT6f0NYzr%2BpBYRTgo%3D',
    'main_page-fet': 'https://matdbstorage.blob.core.windows.net/yunsong-test/Main-fet.jpg?sp=r&st=2022-09-21T03:54:16Z&se=2222-09-21T11:54:16Z&sv=2021-06-08&sr=b&sig=7YsuZGoFardJZewvxIqETDnvnWfj2D0zXDBeqvlIlUc%3D',
    'main_page-matdb': 'https://matdbstorage.blob.core.windows.net/yunsong-test/Main-MatDB.png?sp=r&st=2022-09-21T03:53:59Z&se=2222-09-21T11:53:59Z&sv=2021-06-08&sr=b&sig=Sf1%2FSaFllFA5qewdvu%2B8oJMs4s7ID0ohlFS%2Blef1TOc%3D',
    'main_page-sales_vis': 'https://matdbstorage.blob.core.windows.net/yunsong-test/Main-sales_vis.jpg?sp=r&st=2022-09-21T03:53:41Z&se=2222-09-21T11:53:41Z&sv=2021-06-08&sr=b&sig=UujFYtl1Bdwje4lKIj6YNCnojlb%2FYgtLZwe0ob3aygI%3D',
    'main_page-cadi': 'https://matdbstorage.blob.core.windows.net/yunsong-test/Main-cadi.jpg?sp=r&st=2022-09-21T03:53:24Z&se=2222-09-21T11:53:24Z&sv=2021-06-08&sr=b&sig=EToDdiPirNbWb3a%2BkrCw1Z%2Bxi0NdrhHoESWuWHWhF9c%3D',
    'matdb-logo-1x': 'https://matdbstorage.blob.core.windows.net/yunsong-test/logo-color-small-1x.png?sp=r&st=2022-09-21T03:52:28Z&se=2222-09-21T11:52:28Z&sv=2021-06-08&sr=b&sig=RdqKQNWJkzajy16CaAEkwWLHlToOoMfiqZqz9PmXLFc%3D',
    'matdb-logo-2x': 'https://matdbstorage.blob.core.windows.net/yunsong-test/logo-color-small-2x.png?sp=r&st=2022-09-21T03:52:56Z&se=2222-09-21T11:52:56Z&sv=2021-06-08&sr=b&sig=R%2FzzLd06Q6CvkS%2F0fZySO5F%2F34R%2FgvK7gtegx0iiK40%3D',
    'fet-BRPO-L2': 'https://matdbstorage.blob.core.windows.net/yunsong-test/BRPO-L2.PNG?sp=r&st=2022-09-21T04:04:21Z&se=2222-09-21T12:04:21Z&sv=2021-06-08&sr=b&sig=6Ei4e5TvrFa6AqeC0cwL5TWChcTBlrFZwQPvNUxPahw%3D'
}

class Cache:
    def __init__(self):
        self.bool_global = False
        self.dict_path_db = DICT_PATH_DB
        self.table_print_cols = 7
        self.max_width_int = 1100
        self.max_width = f'{self.max_width_int}px'
        self.backgroundColor = '#ffffff'
        self.login_time_sep = 5
        self.dict_activity_store = {'tab_main_material_visual': 'button_combined_spider_chart'}
        self.dict_state = {'button_tabulated_buttons': False}
        self.time_interval = 2500  # Upload to activity database every 2.5 second
        self.queue = queue.Queue()
        self.DIR, self.DIR_DATA = DIR, DIR_DATA
        self.DIR_ROOT, self.DIR_DOWNLOAD = DIR_ROOT, DIR_DOWNLOAD
        self.app = None
        self.dict_cloud_sql = {}
        self.appname = None
        self.count_link_to_root = 0
        self.font = 'sans-serif'
        self.dict_image = dict_image
        self.sidebar_width = 235

    def establish_cloud_con(self, db_name_list):
        if type(db_name_list) is str:
            db_name_list = [db_name_list]
        for db_name in db_name_list:
            self.dict_cloud_sql[db_name] = make_cloud_con_windows(db_name)

    def get_cloud_con(self, db_name):
        # con = make_cloud_con_windows(db_name)
        if db_name in self.dict_cloud_sql:
            con = self.dict_cloud_sql[db_name]
        else:
            self.establish_cloud_con(db_name)
            con = self.dict_cloud_sql[db_name]
        return con

    def exe_cloud_sql(self, command, db_name=DBNAME, max_try=3, time_delay=0.25):
        command_head = command.strip().split(' ')[0].split('\n')[0].lower()
        if command_head in ['select', 'with']:
            exe_type = 'read'
        elif command_head in ['insert', 'update', 'delete']:
            exe_type = 'write'
        else:
            raise ValueError(f'Not able to identify the SQL command type: \n{command}')

        def _exe_(_exe_con, _exe_type, _command):
            if _exe_type.lower() in ['read', 'r']:
                _pd_result = pd.read_sql_query(_command, _exe_con)
                return _pd_result
            elif _exe_type.lower() in ['write', 'w']:
                _exe_con.execute(_command)
                return '200'
            else:
                raise ValueError(f"Not able to recognize exexution type {exe_type}. It has to be in ['read', 'r', 'write', 'w']")

        bool_success, pd_result = False, None
        exc_type, exc_value, exc_traceback = [None] * 3
        _e = ''
        for i in range(max_try):
            try:
                # First trial to see if the conneciton is valid
                pd_result = _exe_(self.dict_cloud_sql[db_name], exe_type, command)
                bool_success = True
                break
            except Exception as _e:
                exc_type, exc_value, exc_traceback = sys.exc_info()
                # If fail, rebuild the connection and try again
                self.establish_cloud_con(db_name)
            time.sleep(time_delay)
        if bool_success:
            return pd_result
        else:
            traceback.print_exception(exc_type, exc_value, exc_traceback,
                                      limit=2, file=sys.stdout)
            return f'400 - {_e}'

    @staticmethod
    def get_user_info():
        # print(azure.token)
        try:
            dict_login = jwt.decode(azure.token.get("access_token"), options={"verify_signature": False})
            dict_info = {'email': dict_login['unique_name'], 'username': dict_login['unique_name'].split('@')[0],
                         'display_name': dict_login['name'], 'first_name': dict_login['given_name']}
        except:
            dict_info = {'email': '', 'username': '',
                         'display_name': '', 'first_name': ''}


        return dict_info

    def exe_log_login(self, username, max_try=3, time_delay=0.25):
        """
        Record user login
        Args:
            username (str): username
            max_try (int): max times of the commiting trial
            time_delay (float): time delay of each commiting trial

        """
        now_str = str(datetime.datetime.now())[:19]
        command = f"""insert into login (username, webapp, time) values
        ('{username}', 'TBD', '{now_str}')"""
        self.exe_cloud_sql(command)

    def exe_log_activity(self, username, webapp, item, subitem, value, max_try=3, time_delay=0.1):
        """
        Record user behavior activity
        Args:
            username (str): username
            item (str): item
            subitem (str): subitem
            value (str): value
            max_try (int): max times of the commiting trial
            time_delay (float): time delay of each commiting trial
        """
        if isProd & (username not in ['In progress', '']):
            now_str = str(datetime.datetime.now())[:19]
            now_hr_str = str(datetime.datetime.now())[:14] + '00:00'
            command = f"""insert into AppActivity (username, webapp, item, subitem, [value], [time], [time_hr]) values
                    ('{username}', '{webapp}', '{item}', '{subitem}', '{value}', '{now_str}', '{now_hr_str}')"""
            self.exe_cloud_sql(command)

    def exe_log_feedback(self, username, category, webapp, sub_category, description, max_try=3, time_delay=0.1):
        """
        Record user input feedback information
        Args:
            username (str): username
            category (str): category
            webapp (str): webapp
            sub_category (str): sub_category
            description (str): description
            max_try (int): max times of the commiting trial
            time_delay (float): time delay of each commiting trial
        """
        now_str = str(datetime.datetime.now())[:19]
        command = f"""insert into AppFeedback (username, category, webapp, sub_category, description, [time]) values
                ('{username}', '{category}', '{webapp}', '{sub_category}', '{description}', '{now_str}')"""
        self.exe_cloud_sql(command)

    def get_visit_info(self):
        command = "select distinct [username], [time_hr] as time from AppActivity"
        pd_visit = self.exe_cloud_sql(command)
        pd_visit['time'] = pd_visit['time'].astype(str)

        return pd_visit


CACHE = Cache()
CACHE.establish_cloud_con([DBNAME])
# self = CACHE


class ProcessStl:
    def __init__(self):
        self.binary_header = "80sI"
        self.binary_facet = "12fH"

    @staticmethod
    def roll2d(image, shifts):
        return np.roll(np.roll(image, shifts[0], axis=0), shifts[1], axis=1)

    def _build_binary_stl(self, facets):
        """returns a string of binary binary data for the stl file"""

        lines = [struct.pack(self.binary_header, b'Binary STL Writer', len(facets)), ]
        for facet in facets:
            facet = list(facet)
            facet.append(0)  # need to pad the end with a unsigned short byte
            lines.append(struct.pack(self.binary_facet, *facet))
        return lines

    def write_stl(self, facets, file_name):
        """writes an ASCII or binary STL file"""

        f = open(file_name, 'wb')
        data = self._build_binary_stl(facets)
        data = b"".join(data)
        f.write(data)

        f.close()

    @staticmethod
    def preprocess_model(pd_data_input):
        pd_data = pd_data_input.dropna().copy()
        pd_data.columns = ['x', 'y', 'z']
        x_array, y_array = sorted(pd_data['x'].unique()), sorted(pd_data['y'].unique())
        x_grid, y_grid = np.meshgrid(x_array, y_array)
        pd_xy = pd.DataFrame({'x': x_grid.flatten(), 'y': y_grid.flatten()})
        merge_cols = ['x', 'y']
        pd_xy_merge = pd_data[merge_cols].merge(pd_xy, on=merge_cols, how='inner')
        n_points_good = len(pd_xy)
        if len(pd_xy_merge) != len(pd_data):
            if len(pd_data[merge_cols].drop_duplicates()) < n_points_good:
                print('There repeated coordinates in the input data')
            if len(pd_xy_merge) < n_points_good:
                print('There missing coordinates in the input data')
            pd_data_output_temp = pd_data.groupby(merge_cols)['z'].mean().reset_index()
            new_back_z = interpolate.griddata(pd_data_output_temp[['x', 'y']], pd_data_output_temp['z'], pd_xy[['x', 'y']], method='linear')
            pd_data_output = pd_xy.copy()
            pd_data_output['z'] = new_back_z
        else:
            pd_data_output = pd_data
        return pd_data_output

    @staticmethod
    def pd_data_to_2d_data(pd_data_input):
        _n_x = len(pd_data_input.x.unique())
        _n_y = len(pd_data_input.y.unique())
        _data_x = np.asarray(pd_data_input['x']).reshape(_n_x, _n_y)
        _data_y = np.asarray(pd_data_input['y']).reshape(_n_x, _n_y)
        _data_z = np.asarray(pd_data_input['z']).reshape(_n_x, _n_y)
        return _data_x, _data_y, _data_z

    @staticmethod
    def get_2d_data(plot_bool=False):
        noise = 0.05
        n_x = 100
        n_y = 100
        center_x, center_y = 5, 7
        _x = np.linspace(0, 10, n_x)
        _y = np.linspace(0, 14, n_y)
        x, y = np.meshgrid(_x, _y)
        y_peak = 5
        decay = 0.6
        period = 3
        # z = (x - 1) * (x - 9) * (y - 1) * (y - 9) / 100 + np.random.randn(n_y, n_x) * noise + 2
        r2 = ((x - center_x) ** 2 + (y - center_y) ** 2)
        r = r2 ** 0.5
        z = y_peak * ((r + 0.5) ** (-decay)) * np.cos(2 * np.pi * r / period)
        #z = y_peak * np.exp(r * (-decay))
        if plot_bool:
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(1, 1)
            ax = fig.add_subplot(111, projection='3d')
            ax.plot_surface(x, y, z)
            ax.set_xlabel('X Label')
            ax.set_ylabel('Y Label')
            ax.set_zlabel('Z Label')

        pd_data_2d = pd.DataFrame({'x': x.flatten(), 'y': y.flatten(), 'z': z.flatten()})
        return pd_data_2d

    @staticmethod
    def constract_facets(data_x, data_y, data_z, mask_val, mask, surface='top'):
        _facets = []
        x_size, y_size = data_z.shape
        for i, j in product(range(x_size - 1), range(y_size - 1)):
            this_pt = np.array([data_x[i, j], data_y[i, j], data_z[i, j]])
            top_right = np.array([data_x[i, j], data_y[i, j + 1], data_z[i, j + 1]])
            bottom_left = np.array([data_x[i + 1, j], data_y[i, j], data_z[i + 1, j]])
            bottom_right = np.array([data_x[i + 1, j + 1], data_y[i + 1, j + 1], data_z[i + 1, j + 1]])

            n1, n2 = np.zeros(3), np.zeros(3)

            if (this_pt[-1] > mask_val and top_right[-1] > mask_val and bottom_left[-1] > mask_val):
                if surface == 'top':
                    facet = np.concatenate([n1, top_right, this_pt, bottom_right])
                else: #surface == 'bottom'
                    facet = np.concatenate([n2, this_pt, bottom_right, bottom_left])
                _facets.append(facet)
                mask[i, j] = 1
                mask[i, j + 1] = 1
                mask[i + 1, j] = 1

            if (this_pt[-1] > mask_val and bottom_right[-1] > mask_val and bottom_left[-1] > mask_val):
                if surface == 'top':
                    facet = np.concatenate([n2, bottom_right, this_pt, bottom_left])
                else:  # surface == 'bottom'
                    facet = np.concatenate([n1, this_pt, top_right, bottom_right])
                _facets.append(facet)
                mask[i, j] = 1
                mask[i + 1, j + 1] = 1
                mask[i + 1, j] = 1
        facets_output = np.array(_facets)
        return facets_output, mask

    def get_stl(self, pd_data, min_thickness):

        pd_data = pd_data.sort_values(by=['x', 'y'])
        data_x, data_y, data_z = self.pd_data_to_2d_data(pd_data)

        mask_val = data_z.min() - 1.
        x_size, y_size = data_z.shape
        mask = np.zeros((x_size, y_size))

        print("Creating top mesh...")
        facets_top, mask = self.constract_facets(data_x, data_y, data_z, mask_val, mask, surface='top')

        #######################################################################
        # construct the bottom facets
        #######################################################################

        pd_data_back = pd_data.copy()
        pd_data_back['z'] = pd_data_back['z'].min() - min_thickness

        data_x, data_y, data_z = self.pd_data_to_2d_data(pd_data_back)
        mask_val = data_z.min() - 1.

        print("Creating bottom mesh...")
        facets_bottom, mask = self.constract_facets(data_x, data_y, data_z, mask_val, mask, surface='bottom')

        facets = np.concatenate([facets_top, facets_bottom])

        #######################################################################
        # construct the edge facets
        #######################################################################
        print("Computed edges...")
        edge_mask = np.sum([self.roll2d(mask, (i, j)) for i, j in product([-1, 0, 1], repeat=2)], axis=0)
        edge_mask[np.where(edge_mask == 9.)] = 0.
        edge_mask[np.where(edge_mask != 0.)] = 1.
        edge_mask[0::x_size - 1, :] = 1.
        edge_mask[:, 0::y_size - 1] = 1.

        data_x, data_y, data_z = self.pd_data_to_2d_data(pd_data)

        print("Construct edge facets...")
        data_ex = data_x[edge_mask == 1]
        data_ey = data_y[edge_mask == 1]
        data_ez = data_z[edge_mask == 1]

        pd_data_edge = pd.DataFrame({'x': data_ex, 'y': data_ey, 'z': data_ez, })

        pd_data_edge_asc = pd_data_edge.sort_values(by=['x', 'y', 'z'], ascending=True)
        pd_data_edge_des = pd_data_edge.sort_values(by=['x', 'y', 'z'], ascending=False)

        pd_data_edge_1 = pd.concat([pd_data_edge_asc.loc[pd_data_edge_asc.x == pd_data_edge_asc.x.min()],
                                    pd_data_edge_asc.loc[pd_data_edge_asc.y == pd_data_edge_asc.y.max()]]).drop_duplicates()

        pd_data_edge_2 = pd.concat([pd_data_edge_des.loc[pd_data_edge_des.x == pd_data_edge_des.x.max()],
                                    pd_data_edge_des.loc[pd_data_edge_des.y == pd_data_edge_des.y.min()]]).drop_duplicates()

        pd_data_edge = pd.concat([pd_data_edge_1, pd_data_edge_2]).drop_duplicates()

        pd_data_edge = pd.concat([pd_data_edge_1, pd_data_edge_2, pd_data_edge.iloc[[0]]])

        edge_facets = []
        zeros_3 = np.zeros(3)

        for i in range(len(pd_data_edge) - 1):
            point_1 = pd_data_edge.iloc[i]
            point_2 = pd_data_edge.iloc[i + 1]
            point_3 = [pd_data_edge.iloc[i]['x'], pd_data_edge.iloc[i]['y'], -min_thickness]
            point_4 = [pd_data_edge.iloc[i + 1]['x'], pd_data_edge.iloc[i + 1]['y'], -min_thickness]

            edge_facet_1 = np.concatenate([zeros_3, point_1, point_2, point_4])
            edge_facet_2 = np.concatenate([zeros_3, point_4, point_3, point_1])

            edge_facets.append(edge_facet_1)
            edge_facets.append(edge_facet_2)

        facets = np.concatenate([facets, edge_facets])
        return facets
