# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com

import os, re, datetime, sqlite3
from uuid import uuid4

from flask import Flask, session, redirect
from flask_session import Session

import pandas as pd

# UDF imports
from app_main import aad_auth, config

from werkzeug.middleware.proxy_fix import ProxyFix

from flask_dance.contrib.azure import make_azure_blueprint


DIR_CURRENT = os.path.dirname(__file__)

isProd = config.isProd

# Configuration
pd.set_option('display.max_column', 75)
pd.set_option('display.max_colwidth', 2400)
pd.set_option('display.width', 25000)
app_flask = Flask(__name__)

if not os.path.isfile(f'{DIR_CURRENT}/sessions.db'):
    con = sqlite3.connect(f'{DIR_CURRENT}/sessions.db')
    con.execute("""
    CREATE TABLE sessions ( id INTEGER NOT NULL, session_id VARCHAR(255), data BLOB, expiry DATETIME, PRIMARY KEY (id), UNIQUE (session_id) )
    """)
    con.commit()
    con.close()


if os.getenv('ORYX_ENV_TYPE') or os.getenv('WEBSITE_SLOT_NAME') or os.getenv('WEBSITE_SITE_NAME'):
    app_flask.config.from_object(config.prodConfig)
    isProd = True
else:
    app_flask.config.from_object(config.devConfig)
    isProd = False

sess = Session(app_flask)
app_flask.config["SECRET_KEY"] = app_flask.config['SECRET_KEY']
app_flask.wsgi_app = ProxyFix(app_flask.wsgi_app, x_proto=1, x_host=1)

bp_azure = make_azure_blueprint(
    client_id=app_flask.config['CLIENT_ID'],
    client_secret=app_flask.config['CLIENT_SECRET'],
    tenant=app_flask.config['AD_TENANT_ID'],
    scope=app_flask.config['APPLICATION_PERMISSIONS'],
)

with app_flask.app_context():

    # register blueprints
    app_flask.register_blueprint(bp_azure, url_prefix='/login')

    from app_main.dataiku_apps import bp as bp_dashapps
    app_flask.register_blueprint(bp_dashapps, name='bp_dashapps')

    # dash app 1
    from app_main.dataiku_apps import server_dataiku_2 as server_dataiku
    app_flask = server_dataiku.add_dash_bizcenter(app_flask)

