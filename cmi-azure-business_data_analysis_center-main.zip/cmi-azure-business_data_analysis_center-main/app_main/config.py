from datetime import timedelta
import os
import json

# SECRET_KEY_TEMP = os.getenv(
#     'SECRET_KEY') or "\x85?\xb4y\x81\xfb\xbb|\x88\x1e\x8d\x1f\x9a\xc9\x8e\xd0\x9c\xbf\xe4[\x8c\xba\xc3}\xcb\xdd\xd5\xdc\xd4\xaf&\x01"
SECRET_KEY_TEMP = os.urandom(48)

# SESSION_TYPE_TEMP = 'sqlalchemy'


if os.getenv('ORYX_ENV_TYPE') or os.getenv('WEBSITE_SLOT_NAME') or os.getenv('WEBSITE_SITE_NAME'):
    isProd = True
else:
    isProd = False

AUTH_REDIRECT_PATH_TEMP = os.getenv('AUTH_REDIRECT_PATH') or "/getAToken"
AD_TENANT_ID_TEMP = os.getenv('AD_TENANT_ID') or 'd1ee1acd-bc7a-4bc4-a787-938c49a83906'
CLIENT_ID_TEMP = os.getenv('CLIENT_ID') or 'c0ea78cf-159c-430d-ba08-98c03a93ea10'
CLIENT_SECRET_TEMP = os.getenv('CLIENT_SECRET') or "2~FL0zL4K.5_XJ-QjYG0Dm_x.nnf239ozz"

AD_AUTHORITY_TEMP = "https://login.microsoftonline.com/{0:s}".format(AD_TENANT_ID_TEMP)
API_DELEGATED_PERMISSONS_TEMP = ["api://c0ea78cf-159c-430d-ba08-98c03a93ea10/Employees.Read.All"]
DELEGATED_PERMISSONS_TEMP = ["User.Read"]
APPLICATION_PERMISSIONS_TEMP = ["api://c0ea78cf-159c-430d-ba08-98c03a93ea10/Employees.Read.All"]
API_ENDPOINT_TEMP = os.getenv('API_ENDPOINT') or 'https://apim.cmi.xom.cloud/prs-adr-api'

DOWNLOADS_FOLDER_TEMP = os.path.join(os.path.dirname(__file__), '../downloads')
if os.path.isdir(DOWNLOADS_FOLDER_TEMP):
    pass
else:
    os.mkdir(DOWNLOADS_FOLDER_TEMP)

DICT_CHEMIDP_INFO_ALL = {
    'apim': {
        'prod': 'https://dsna-chem-prd-apim.dsna.xom.cloud',
        'acc': 'https://dsna-chem-acc-apim.dsna.xom.cloud',
        'dev': 'https://dsna-chem-dev-apim.dsna.xom.cloud',
    },
    'subscription_key': {
        'prod': 'e390db02108d4546bbefbbe72172be6e',
        'acc': '02f2d1a595ec4c3c813146300fd71171',
        'dev': '8d562248d2dc470cbcb22e50121f5d7c',
    },
    'scope_odata':{
        'prod': 'b365a313-0212-446a-b423-a10eb59030fe/.default',
        'acc': '6631b228-751c-4ec7-a02e-ef637c6ea8ce/.default',
        'dev': 'cb98a17a-4415-4a5e-a9c9-7fc1e3236564/.default',
    },
    'scope_blob': {
        'prod': '9b348afc-a289-4d5b-b0d8-60b32c7e6baa/.default',
        'acc': '5eed4027-9895-4a93-99e5-09c0e6db4fb6/.default',
        'dev': 'dea3a15c-41ec-4deb-a03a-6ab68412548c/.default',
    }
}

CHEMIDP_ENV = 'prod'
DICT_CHEMIDP_INFO_TEMP = {i: DICT_CHEMIDP_INFO_ALL[i][CHEMIDP_ENV] for i in DICT_CHEMIDP_INFO_ALL}

if os.environ['COMPUTERNAME'] and os.environ['COMPUTERNAME'].startswith('BTN'):
    # ODBC_STR_TEMP = "Driver={ODBC Driver 17 for SQL Server};Server=hoesql4300.na.xom.com,1433;Database=LIMSACCREP;Trusted_Connection=yes;" # environ.get('ODBC_STR')
    # ODBC_STR_TEMP = "Driver={ODBC Driver 17 for SQL Server};Server=tcp:cmistaging.database.windows.net,1433;Database=LIMSADR_Staging;Authentication=ActiveDirectoryIntegrated" # environ.get('ODBC_STR')
    usr = os.getenv('cmistaging_name')
    pwd = os.getenv('cmistaging_pwd')
    # ODBC_STR_TEMP = "Driver={ODBC Driver 17 for SQL Server};Server=tcp:cmistaging.database.windows.net,1433;Database=LIMSADR_PROD;UID=%s;PWD=%s"%(usr,pwd) # environ.get('ODBC_STR')
    ODBC_STR_TEMP = "Driver={ODBC Driver 17 for SQL Server};Server=tcp:cmistaging.database.windows.net,1433;Database=CMIDataikuYunsongTest;UID=%s;PWD=%s" % (
        usr, pwd)  # environ.get('ODBC_STR')
else:
    # ODBC_STR_TEMP = "Driver={ODBC Driver 17 for SQL Server};Server=tcp:cmistaging.database.windows.net,1433;Database=LIMSADR_PROD;Authentication=ActiveDirectoryMsi" # environ.get('ODBC_STR')
    ODBC_STR_TEMP = "Driver={ODBC Driver 17 for SQL Server};Server=tcp:cmistaging.database.windows.net,1433;Database=CMIDataikuYunsongTest;Authentication=ActiveDirectoryMsi"  # environ.get('ODBC_STR')


class devConfig:
    # Flask env vars
    DEBUG = True
    TESTING = True
    ENV = 'development'
    SECRET_KEY = SECRET_KEY_TEMP
    ODBC_STR = ODBC_STR_TEMP
    HOST = "localhost"
    PORT = 8080

    # FLASK-SESSION
    if os.environ['COMPUTERNAME'] and os.environ['COMPUTERNAME'].startswith('BTN'):
        SESSION_TYPE_TEMP = 'filesystem'
        # SESSION_TYPE_TEMP = 'sqlalchemy'
    else:
        SESSION_TYPE_TEMP = 'redis'

    SESSION_TYPE = SESSION_TYPE_TEMP
    SESSION_PERMANENT = False
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=1)

    # AAD Stuff
    AUTH_REDIRECT_PATH = AUTH_REDIRECT_PATH_TEMP
    AD_TENANT_ID = AD_TENANT_ID_TEMP
    CLIENT_ID = CLIENT_ID_TEMP
    CLIENT_SECRET = CLIENT_SECRET_TEMP
    AD_AUTHORITY = AD_AUTHORITY_TEMP
    API_DELEGATED_PERMISSONS = API_DELEGATED_PERMISSONS_TEMP
    DELEGATED_PERMISSONS = DELEGATED_PERMISSONS_TEMP
    APPLICATION_PERMISSIONS = APPLICATION_PERMISSIONS_TEMP
    API_ENDPOINT = API_ENDPOINT_TEMP
    SSL_VERIFY = False
    AAD_AUTHENTICATE = True

    SESSION_FILE_THRESHOLD = 10
    SESSION_FILE_MODE = 0o777

    SQLALCHEMY_DATABASE_URI = 'sqlite:///sessions.db'
    SESSION_SQLALCHEMY_TABLE = 'sessions'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # SESSION_REDIS = '127.0.0.1:6379'

    DOWNLOADS_FOLDER = DOWNLOADS_FOLDER_TEMP
    VERBOSE = True
    ENFORCE_SECURITY = True
    DICT_CHEMIDP_INFO = DICT_CHEMIDP_INFO_TEMP


class prodConfig:
    # Flask env vars
    DEBUG = False
    TESTING = False
    ENV = 'production'
    SECRET_KEY = SECRET_KEY_TEMP
    ODBC_STR = ODBC_STR_TEMP
    HOST = "0.0.0.0"
    PORT = 80

    # FLASK-SESSION
    SESSION_TYPE_TEMP = 'filesystem'
    SESSION_TYPE = SESSION_TYPE_TEMP
    SESSION_PERMANENT = True
    PERMANENT_SESSION_LIFETIME = timedelta(hours=24)

    # AAD Stuff
    AUTH_REDIRECT_PATH = AUTH_REDIRECT_PATH_TEMP
    AD_TENANT_ID = AD_TENANT_ID_TEMP
    CLIENT_ID = CLIENT_ID_TEMP
    CLIENT_SECRET = CLIENT_SECRET_TEMP
    AD_AUTHORITY = AD_AUTHORITY_TEMP
    API_DELEGATED_PERMISSONS = API_DELEGATED_PERMISSONS_TEMP
    DELEGATED_PERMISSONS = DELEGATED_PERMISSONS_TEMP
    APPLICATION_PERMISSIONS = APPLICATION_PERMISSIONS_TEMP
    API_ENDPOINT = API_ENDPOINT_TEMP
    SSL_VERIFY = False
    AAD_AUTHENTICATE = True

    SESSION_FILE_THRESHOLD = 10
    SESSION_FILE_MODE = 0o777

    DOWNLOADS_FOLDER = DOWNLOADS_FOLDER_TEMP
    VERBOSE = True
    ENFORCE_SECURITY = True
    DICT_CHEMIDP_INFO = DICT_CHEMIDP_INFO_TEMP