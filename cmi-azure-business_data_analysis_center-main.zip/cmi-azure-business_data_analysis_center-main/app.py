# Author: Yunsong Xie
# Email: yunsong.xie@exxonmobil.com
import os, re, datetime
from uuid import uuid4
from flask import Flask, request, render_template, redirect, url_for, session, Blueprint, make_response
import pandas as pd

from app_main.create_instance import isProd, app_flask as app

if not isProd:
    from app_main.dataiku_apps.lib.main_lib import CACHE



if not isProd:
    os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

# Configuration
pd.set_option('display.max_column', 75)
pd.set_option('display.max_colwidth', 2400)
pd.set_option('display.width', 25000)


# Routes

@app.route('/', methods=["GET"])
def index_1():
    return redirect('/bizcenter')


if __name__ == '__main__':

    if isProd:
        app.run()
    else:
        # app_dash = CACHE.app
        # app_dash.run_server(port=app.config['PORT'], host=app.config['HOST'])
        app.run(host=app.config['HOST'], port=app.config['PORT'])

